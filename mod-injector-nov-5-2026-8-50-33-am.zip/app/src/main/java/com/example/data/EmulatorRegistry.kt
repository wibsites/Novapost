package com.example.data

import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.net.Uri
import java.util.Locale

enum class EmulatorArchitecture {
  SWITCH_YUZU_ENGINE,
  PSP_PPSSPP_ENGINE,
  PS2_AETHERSX2_ENGINE,
  DOLPHIN_GC_WII_ENGINE,
  CITRA_3DS_ENGINE,
  WINLATOR_PC_ENGINE,
}

data class InstalledAppInfo(
  val packageName: String,
  val appLabel: String,
  val icon: Drawable? = null,
  val detectedArchitecture: EmulatorArchitecture,
  val isLikelyEmulatorOrGame: Boolean,
)

data class EmulatorProfile(
  val id: String,
  val nameEn: String,
  val nameAr: String,
  val platformBadgeEn: String,
  val platformBadgeAr: String,
  val packageName: String,
  val architecture: EmulatorArchitecture,
  val defaultDataSubPath: String,
  val protocolSummaryAr: String,
  val protocolSummaryEn: String,
  val configFilesPathsSummary: String,
  val isInstalledOnDevice: Boolean = true,
  val detectedPackageName: String? = packageName,
) {
  fun buildSafTreeUriString(): String {
    val activePkg = detectedPackageName ?: packageName
    val path = defaultDataSubPath.replace("{pkg}", activePkg)
    val encoded = Uri.encode(path)
    return "content://com.android.externalstorage.documents/tree/primary%3A$encoded"
  }

  fun buildSafDocumentUriString(context: Context? = null): String {
    val activePkg = detectedPackageName ?: packageName
    if (context != null && architecture != EmulatorArchitecture.PSP_PPSSPP_ENGINE) {
      val rootUri = EmulatorRegistry.resolveEmulatorInitialSafUri(context, activePkg)
      if (!rootUri.isNullOrBlank()) {
        return rootUri
      }
    }
    val path = defaultDataSubPath.replace("{pkg}", activePkg)
    val encoded = Uri.encode(path)
    return "content://com.android.externalstorage.documents/document/primary%3A$encoded"
  }
}

object EmulatorRegistry {

  /**
   * Resolves the exported `DocumentsProvider` authority owned by the target emulator package
   * (e.g. `dev.eden.eden_emulator.user`, `org.yuzu.yuzu_emu.user`, `org.citron.citron_emu.user`,
   * `org.sudachi.sudachi_emu.user`, `org.dolphinemu.dolphinemu.user`).
   */
  fun resolveEmulatorDocumentsProviderAuthority(
    context: Context,
    packageName: String,
  ): String? {
    return try {
      val pm = context.packageManager
      val docIntent = Intent("android.content.action.DOCUMENTS_PROVIDER")
      val providers = pm.queryIntentContentProviders(docIntent, 0)
      val matchedAuthority = providers
        .mapNotNull { it.providerInfo }
        .firstOrNull { it.packageName.equals(packageName, ignoreCase = true) && !it.authority.isNullOrBlank() }
        ?.authority
      if (!matchedAuthority.isNullOrBlank()) {
        return matchedAuthority
      }
      val fallbackAuth = "$packageName.user"
      val providerInfo = pm.resolveContentProvider(fallbackAuth, 0)
      if (providerInfo != null) fallbackAuth else null
    } catch (_: Throwable) {
      null
    }
  }

  /**
   * Queries the emulator's exported `DocumentsProvider` root cursor to obtain its exact
   * `COLUMN_DOCUMENT_ID` / `COLUMN_ROOT_ID` so `ACTION_OPEN_DOCUMENT_TREE` opens straight inside
   * the selected app's internal data directory (`config/`, `load/`, `nand/`).
   */
  fun resolveEmulatorInitialSafUri(
    context: Context,
    packageName: String,
  ): String? {
    val authority = resolveEmulatorDocumentsProviderAuthority(context, packageName) ?: return null
    try {
      val rootsUri = android.provider.DocumentsContract.buildRootsUri(authority)
      context.contentResolver.query(rootsUri, null, null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) {
          val docIdIdx = cursor.getColumnIndex(android.provider.DocumentsContract.Root.COLUMN_DOCUMENT_ID)
          val rootIdIdx = cursor.getColumnIndex(android.provider.DocumentsContract.Root.COLUMN_ROOT_ID)
          val docId = if (docIdIdx >= 0) cursor.getString(docIdIdx) else null
          val rootId = if (rootIdIdx >= 0) cursor.getString(rootIdIdx) else null
          if (!docId.isNullOrBlank()) {
            return android.provider.DocumentsContract.buildDocumentUri(authority, docId).toString()
          }
          if (!rootId.isNullOrBlank()) {
            return android.provider.DocumentsContract.buildRootUri(authority, rootId).toString()
          }
        }
      }
    } catch (_: Throwable) {
      // Fallback below
    }
    return "content://$authority/document/root"
  }

  private const val APP_QUERY_CACHE_TTL_MS = 15_000L

  @Volatile
  private var cachedChooserApps: List<InstalledAppInfo>? = null

  @Volatile
  private var cachedChooserAppsTimestampMs: Long = 0L

  @Volatile
  private var cachedAllLaunchableApps: List<InstalledAppInfo>? = null

  @Volatile
  private var cachedAllLaunchableAppsTimestampMs: Long = 0L

  @Volatile
  private var cachedEmulatorProfiles: List<EmulatorProfile>? = null

  @Volatile
  private var cachedEmulatorProfilesTimestampMs: Long = 0L

  /**
   * Scans the device and returns ONLY installed emulators (never general phone apps).
   * Combines Launcher activity inspection and exported DocumentsProvider inspection so
   * any installed Switch (Eden, Yuzu, Citron, Sudachi, Suyu, Uzuy, Skyline...), PSP (PPSSPP),
   * PS2 (AetherSX2, NetherSX2), Dolphin, 3DS (Citra, Lime3DS, Azahar), or PC (Winlator, Mobox, GameHub)
   * emulator is automatically recognized.
   */
  fun queryInstalledAppsForChooser(context: Context): List<InstalledAppInfo> {
    val now = android.os.SystemClock.elapsedRealtime()
    val cached = cachedChooserApps
    if (cached != null && (now - cachedChooserAppsTimestampMs) < APP_QUERY_CACHE_TTL_MS) {
      return cached
    }
    return try {
      val pm = context.packageManager
      val ownPkg = context.packageName
      val discovered = linkedMapOf<String, InstalledAppInfo>()

      // 1. Check all exported DocumentsProviders (Eden, Yuzu, Citron, Sudachi, Dolphin, Citra, Lime3DS, etc.)
      val docProviderPackages = mutableSetOf<String>()
      try {
        val docIntent = Intent("android.content.action.DOCUMENTS_PROVIDER")
        val providers = pm.queryIntentContentProviders(docIntent, 0)
        for (res in providers) {
          val pInfo = res.providerInfo ?: continue
          val pkg = pInfo.packageName ?: continue
          val auth = pInfo.authority.orEmpty().lowercase(Locale.ROOT)
          if (pkg != ownPkg && !isSystemOrNonEmulatorPackage(pkg) &&
            (auth.endsWith(".user") || auth.contains("yuzu") || auth.contains("eden") || isKnownEmulatorToken(pkg, auth))
          ) {
            docProviderPackages.add(pkg)
          }
        }
      } catch (_: Throwable) {
      }

      // 2. Query launchable apps and keep ONLY recognized emulators
      val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
        addCategory(Intent.CATEGORY_LAUNCHER)
      }
      val resolveInfos = pm.queryIntentActivities(mainIntent, 0)
      for (info in resolveInfos) {
        val pkg = info.activityInfo?.packageName ?: continue
        if (pkg == ownPkg || isSystemOrNonEmulatorPackage(pkg)) continue
        val label = info.loadLabel(pm)?.toString()?.takeIf { it.isNotBlank() } ?: pkg
        val isEmu = docProviderPackages.contains(pkg) || isKnownEmulatorToken(pkg, label)
        if (!isEmu) continue

        val icon = try {
          info.loadIcon(pm)
        } catch (_: Throwable) {
          null
        }
        val arch = detectArchitectureForPackage(pkg, label)
        discovered[pkg] = InstalledAppInfo(
          packageName = pkg,
          appLabel = label,
          icon = icon,
          detectedArchitecture = arch,
          isLikelyEmulatorOrGame = true,
        )
      }

      // 3. Also check known emulator package IDs directly in case any package doesn't declare standard launcher category
      for (knownPkg in KNOWN_EMULATOR_PACKAGES) {
        if (discovered.containsKey(knownPkg)) continue
        try {
          val appInfo = pm.getApplicationInfo(knownPkg, 0)
          val label = pm.getApplicationLabel(appInfo)?.toString()?.takeIf { it.isNotBlank() } ?: knownPkg
          val icon = try {
            pm.getApplicationIcon(appInfo)
          } catch (_: Throwable) {
            null
          }
          val arch = detectArchitectureForPackage(knownPkg, label)
          discovered[knownPkg] = InstalledAppInfo(
            packageName = knownPkg,
            appLabel = label,
            icon = icon,
            detectedArchitecture = arch,
            isLikelyEmulatorOrGame = true,
          )
        } catch (_: Throwable) {
          // Package not installed on device
        }
      }

      val sorted = discovered.values.sortedBy { it.appLabel.lowercase(Locale.ROOT) }
      cachedChooserApps = sorted
      cachedChooserAppsTimestampMs = now
      sorted
    } catch (_: Throwable) {
      emptyList()
    }
  }

  fun queryAllLaunchablePhoneApps(context: Context): List<InstalledAppInfo> {
    val now = android.os.SystemClock.elapsedRealtime()
    val cached = cachedAllLaunchableApps
    if (cached != null && (now - cachedAllLaunchableAppsTimestampMs) < APP_QUERY_CACHE_TTL_MS) {
      return cached
    }
    return try {
      val pm = context.packageManager
      val ownPkg = context.packageName
      val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
        addCategory(Intent.CATEGORY_LAUNCHER)
      }
      val resolveInfos = pm.queryIntentActivities(mainIntent, 0)
      val sorted = resolveInfos.mapNotNull { info ->
        val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
        if (pkg == ownPkg) return@mapNotNull null
        val label = info.loadLabel(pm)?.toString()?.takeIf { it.isNotBlank() } ?: pkg
        val icon = try { info.loadIcon(pm) } catch (_: Throwable) { null }
        val arch = detectArchitectureForPackage(pkg, label)
        InstalledAppInfo(
          packageName = pkg,
          appLabel = label,
          icon = icon,
          detectedArchitecture = arch,
          isLikelyEmulatorOrGame = isKnownEmulatorToken(pkg, label),
        )
      }.sortedBy { it.appLabel.lowercase(Locale.ROOT) }
      cachedAllLaunchableApps = sorted
      cachedAllLaunchableAppsTimestampMs = now
      sorted
    } catch (_: Throwable) {
      emptyList()
    }
  }

  /**
   * Checks whether the user has granted Usage Access (`PACKAGE_USAGE_STATS`) so `UsageStatsManager`
   * can detect the last entered application in real time.
   */
  fun hasUsageStatsPermission(context: Context): Boolean {
    return try {
      val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? android.app.AppOpsManager
        ?: return false
      val mode = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
        appOps.unsafeCheckOpNoThrow(
          android.app.AppOpsManager.OPSTR_GET_USAGE_STATS,
          android.os.Process.myUid(),
          context.packageName,
        )
      } else {
        @Suppress("DEPRECATION")
        appOps.checkOpNoThrow(
          android.app.AppOpsManager.OPSTR_GET_USAGE_STATS,
          android.os.Process.myUid(),
          context.packageName,
        )
      }
      mode == android.app.AppOpsManager.MODE_ALLOWED
    } catch (_: Throwable) {
      false
    }
  }

  /**
   * Detects the most recently opened app (excluding NovaBoost, System UI, Settings, and Launchers)
   * using `UsageStatsManager`, falling back to the first installed emulator on the device.
   */
  fun detectLastOpenedApp(context: Context): InstalledAppInfo? {
    val ownPkg = context.packageName
    val pm = context.packageManager

    // Identify default home launcher package to exclude it
    val launcherPkg = try {
      val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
      pm.resolveActivity(homeIntent, 0)?.activityInfo?.packageName
    } catch (_: Throwable) {
      null
    }

    val excludedPackages = setOfNotNull(
      ownPkg,
      launcherPkg,
      "android",
      "com.android.systemui",
      "com.android.settings",
      "com.android.documentsui",
      "com.google.android.documentsui",
      "com.google.android.permissioncontroller",
      "com.android.permissioncontroller",
      "com.google.android.apps.nexuslauncher",
      "com.sec.android.app.launcher",
      "com.miui.home",
      "com.android.launcher",
      "com.android.launcher3",
    )

    try {
      val usageStatsManager =
        context.getSystemService(Context.USAGE_STATS_SERVICE) as? android.app.usage.UsageStatsManager
      if (usageStatsManager != null) {
        val now = System.currentTimeMillis()
        val start = now - 24L * 60L * 60L * 1000L
        val stats = usageStatsManager.queryUsageStats(
          android.app.usage.UsageStatsManager.INTERVAL_DAILY,
          start,
          now,
        ).orEmpty()

        val sortedRecent = stats
          .filter { it.packageName != null && it.lastTimeUsed > 0L && it.packageName !in excludedPackages }
          .sortedByDescending { it.lastTimeUsed }

        // First look for the most recently opened emulator or game
        for (usage in sortedRecent) {
          val pkg = usage.packageName ?: continue
          if (isSystemOrNonEmulatorPackage(pkg)) continue
          try {
            val appInfo = pm.getApplicationInfo(pkg, 0)
            val label = pm.getApplicationLabel(appInfo)?.toString()?.takeIf { it.isNotBlank() } ?: pkg
            if (isKnownEmulatorToken(pkg, label)) {
              val icon = try { pm.getApplicationIcon(appInfo) } catch (_: Throwable) { null }
              return InstalledAppInfo(
                packageName = pkg,
                appLabel = label,
                icon = icon,
                detectedArchitecture = detectArchitectureForPackage(pkg, label),
                isLikelyEmulatorOrGame = true,
              )
            }
          } catch (_: Throwable) {
            continue
          }
        }

        // Otherwise return the very last opened user application
        for (usage in sortedRecent) {
          val pkg = usage.packageName ?: continue
          if (pkg in excludedPackages) continue
          try {
            val appInfo = pm.getApplicationInfo(pkg, 0)
            val label = pm.getApplicationLabel(appInfo)?.toString()?.takeIf { it.isNotBlank() } ?: pkg
            val icon = try { pm.getApplicationIcon(appInfo) } catch (_: Throwable) { null }
            return InstalledAppInfo(
              packageName = pkg,
              appLabel = label,
              icon = icon,
              detectedArchitecture = detectArchitectureForPackage(pkg, label),
              isLikelyEmulatorOrGame = isKnownEmulatorToken(pkg, label),
            )
          } catch (_: Throwable) {
            continue
          }
        }
      }
    } catch (_: Throwable) {
      // Fallback below
    }

    // Fallback to installed emulators on device or Eden default
    val installedEmulators = queryInstalledAppsForChooser(context)
    if (installedEmulators.isNotEmpty()) {
      return installedEmulators.first()
    }
    return InstalledAppInfo(
      packageName = "dev.eden.eden_emulator",
      appLabel = "Eden Emulator",
      icon = null,
      detectedArchitecture = EmulatorArchitecture.SWITCH_YUZU_ENGINE,
      isLikelyEmulatorOrGame = true,
    )
  }

  private val KNOWN_EMULATOR_PACKAGES = listOf(
    "dev.eden.eden_emulator",
    "dev.eden.eden_emulator.ea",
    "org.yuzu.yuzu_emu",
    "org.yuzu.yuzu_emu.ea",
    "org.citron.citron_emu",
    "org.citron.citron_emu.ea",
    "org.sudachi.sudachi_emu",
    "org.sudachi.sudachi_emu.ea",
    "dev.suyu.suyu_emu",
    "org.uzuy.uzuy_emu",
    "org.ziunx.ziunx_emu",
    "emu.skyline",
    "org.stratoemu.strato",
    "com.xiaoji.egggame",
    "org.ppsspp.ppsspp",
    "org.ppsspp.ppssppgold",
    "xyz.aethersx2.android",
    "xyz.nethersx2.android",
    "org.dolphinemu.dolphinemu",
    "org.dolphinemu.mmjr",
    "org.citra.citra_emu",
    "org.citra.emu",
    "io.github.lime3ds.android",
    "io.github.azahar_emu.azahar",
    "com.winlator",
    "com.winlator.glibc",
    "com.winlator.cmod",
    "com.gamehub.emulator",
    "org.vita3k.emulator",
    "com.github.stenzek.duckstation",
    "com.retroarch",
    "com.retroarch.aarch64",
    "com.swordfish.lemuroid",
    "com.dsemu.drastic",
    "me.magnum.melonds",
    "io.recompiled.redream",
    "com.flycast.emulator",
    "org.mupen64plusae.v3.fzurita",
    "info.cemu.cemu",
  )

  private val IGNORED_PACKAGE_PREFIXES = listOf(
    "com.android.",
    "com.google.android.",
    "android.",
    "com.samsung.android.",
    "com.sec.android.",
    "com.miui.",
    "com.xiaomi.",
    "com.huawei.",
    "com.oppo.",
    "com.coloros.",
    "com.vivo.",
    "com.oneplus.",
    "com.whatsapp",
    "com.facebook.",
    "com.instagram.",
    "com.zhiliaoapp.",
    "org.telegram.",
    "com.spotify.",
    "com.netflix.",
  )

  private val KNOWN_EMULATOR_TOKENS = listOf(
    "eden", "yuzu", "citron", "sudachi", "suyu", "uzuy", "ziunx", "torzu", "ryujinx",
    "skyline", "strato", "eggns", "egggame", "ppsspp", "aethersx", "nethersx", "pcsx2",
    "damonps2", "dolphin", "citra", "lime3ds", "azahar", "mandarine", "borked3ds",
    "winlator", "mobox", "gamehub", "gamefusion", "micewine", "pluvia", "cemu",
    "vita3k", "rpcsx", "aps3e", "drastic", "melonds", "duckstation", "retroarch",
    "lemuroid", "redream", "flycast", "mupen64", "m64plus", "pizzaboy", "myboy",
    "epsxe", "fpse", "emulator", "_emu", ".emu"
  )

  private val ALL_KNOWN_EMULATOR_IDS = listOf(
    "eden", "eden_ea", "yuzu", "yuzu_ea", "citron", "citron_ea", "sudachi", "suyu", "uzuy", "ziunx",
    "skyline", "strato", "egggame", "ppsspp", "ppssppgold", "aethersx2", "nethersx2", "dolphin",
    "dolphin_mmjr", "lime3ds", "citra", "azahar", "winlator", "winlator_cmod", "gamehub", "vita3k",
    "duckstation", "retroarch", "drastic", "melonds", "flycast"
  )

  private fun isSystemOrNonEmulatorPackage(pkg: String): Boolean {
    val lower = pkg.lowercase(Locale.ROOT)
    return IGNORED_PACKAGE_PREFIXES.any { lower.startsWith(it) }
  }

  private fun isKnownEmulatorToken(pkg: String, label: String): Boolean {
    val lowerPkg = pkg.lowercase(Locale.ROOT)
    val lowerLabel = label.lowercase(Locale.ROOT)
    val combined = "$lowerPkg $lowerLabel"
    return KNOWN_EMULATOR_TOKENS.any { combined.contains(it) }
  }

  /**
   * Automatically determines the engine architecture from an app's package name or label.
   */
  fun detectArchitectureForPackage(pkg: String, label: String = ""): EmulatorArchitecture {
    val combined = "${pkg.lowercase(Locale.ROOT)} ${label.lowercase(Locale.ROOT)}"
    return when {
      combined.contains("ppsspp") -> EmulatorArchitecture.PSP_PPSSPP_ENGINE
      combined.contains("aethersx") || combined.contains("nethersx") || combined.contains("pcsx2") || combined.contains("damon") ->
        EmulatorArchitecture.PS2_AETHERSX2_ENGINE
      combined.contains("dolphin") -> EmulatorArchitecture.DOLPHIN_GC_WII_ENGINE
      combined.contains("citra") || combined.contains("lime3ds") || combined.contains("azahar") || combined.contains("mandarine") || combined.contains("3ds") ->
        EmulatorArchitecture.CITRA_3DS_ENGINE
      combined.contains("winlator") || combined.contains("mobox") || combined.contains("box64") || combined.contains("gamehub") || combined.contains("micewine") ->
        EmulatorArchitecture.WINLATOR_PC_ENGINE
      else -> EmulatorArchitecture.SWITCH_YUZU_ENGINE
    }
  }

  /**
   * Builds a dynamic [EmulatorProfile] for ANY emulator selected by the user.
   */
  fun createProfileFromInstalledApp(
    packageName: String,
    appLabel: String,
    overrideArchitecture: EmulatorArchitecture? = null,
    isInstalled: Boolean = true,
  ): EmulatorProfile {
    val arch = overrideArchitecture ?: detectArchitectureForPackage(packageName, appLabel)
    return when (arch) {
      EmulatorArchitecture.SWITCH_YUZU_ENGINE -> EmulatorProfile(
        id = packageName,
        nameEn = appLabel,
        nameAr = appLabel,
        platformBadgeEn = "Switch / Vulkan",
        platformBadgeAr = "محاكي Switch",
        packageName = packageName,
        architecture = arch,
        defaultDataSubPath = "Android/data/{pkg}/files",
        protocolSummaryAr = "فك 60FPS عبر [Core] speed_limit=200 + NCE + AMD FSR + باتش .pchtxt",
        protocolSummaryEn = "60FPS via [Core] speed_limit=200 + NCE + AMD FSR + .pchtxt patch",
        configFilesPathsSummary = "config/config.ini + config/custom/<TitleID>.ini + load/<TitleID>/60FPS_Mod/exefs/*.pchtxt",
        isInstalledOnDevice = isInstalled,
        detectedPackageName = packageName,
      )

      EmulatorArchitecture.PSP_PPSSPP_ENGINE -> EmulatorProfile(
        id = packageName,
        nameEn = appLabel,
        nameAr = appLabel,
        platformBadgeEn = "PSP Engine",
        platformBadgeAr = "محاكي PSP",
        packageName = packageName,
        architecture = arch,
        defaultDataSubPath = "PSP",
        protocolSummaryAr = "تفعيل 60FPS CWCheat + محرك Vulkan في ppsspp.ini",
        protocolSummaryEn = "CWCheat 60FPS + Vulkan scaling in ppsspp.ini",
        configFilesPathsSummary = "PSP/CHEATS/<GameID>.ini + PSP/SYSTEM/ppsspp.ini",
        isInstalledOnDevice = isInstalled,
        detectedPackageName = packageName,
      )

      EmulatorArchitecture.PS2_AETHERSX2_ENGINE -> EmulatorProfile(
        id = packageName,
        nameEn = appLabel,
        nameAr = appLabel,
        platformBadgeEn = "PS2 Engine",
        platformBadgeAr = "محاكي PS2",
        packageName = packageName,
        architecture = arch,
        defaultDataSubPath = "Android/data/{pkg}/files",
        protocolSummaryAr = "حقن باتشات .pnach لفتح 60FPS + تفعيل Vulkan و AMD CAS في PCSX2.ini",
        protocolSummaryEn = "Injects .pnach 60FPS patches + Vulkan & AMD CAS in PCSX2.ini",
        configFilesPathsSummary = "cheats/<CRC>.pnach + cheats_ws/<CRC>.pnach + inis/PCSX2.ini",
        isInstalledOnDevice = isInstalled,
        detectedPackageName = packageName,
      )

      EmulatorArchitecture.DOLPHIN_GC_WII_ENGINE -> EmulatorProfile(
        id = packageName,
        nameEn = appLabel,
        nameAr = appLabel,
        platformBadgeEn = "GC / Wii",
        platformBadgeAr = "محاكي GC / Wii",
        packageName = packageName,
        architecture = arch,
        defaultDataSubPath = "Android/data/{pkg}/files",
        protocolSummaryAr = "حقن أكواد Gecko 60FPS + تفعيل Async Ubershaders و Vulkan",
        protocolSummaryEn = "Injects Gecko 60FPS codes + Async Ubershaders & Vulkan",
        configFilesPathsSummary = "GameSettings/<GameID>.ini + Config/Dolphin.ini + Config/GFX.ini",
        isInstalledOnDevice = isInstalled,
        detectedPackageName = isInstalled.let { packageName },
      )

      EmulatorArchitecture.CITRA_3DS_ENGINE -> EmulatorProfile(
        id = packageName,
        nameEn = appLabel,
        nameAr = appLabel,
        platformBadgeEn = "3DS Engine",
        platformBadgeAr = "محاكي 3DS",
        packageName = packageName,
        architecture = arch,
        defaultDataSubPath = "Android/data/{pkg}/files",
        protocolSummaryAr = "حقن شفرات 60FPS + تفعيل Vulkan و SPIR-V Shaders ومكبر FSR",
        protocolSummaryEn = "Injects 60FPS cheats + Vulkan, SPIR-V Shaders & FSR",
        configFilesPathsSummary = "cheats/<TitleID>.txt + config/config.ini",
        isInstalledOnDevice = isInstalled,
        detectedPackageName = packageName,
      )

      EmulatorArchitecture.WINLATOR_PC_ENGINE -> EmulatorProfile(
        id = packageName,
        nameEn = appLabel,
        nameAr = appLabel,
        platformBadgeEn = "PC Container",
        platformBadgeAr = "محاكي PC",
        packageName = packageName,
        architecture = arch,
        defaultDataSubPath = "Android/data/{pkg}/files",
        protocolSummaryAr = "توليد ملف dxvk.conf لفك 60FPS + تفعيل WINE_FULLSCREEN_FSR و Box64",
        protocolSummaryEn = "Generates dxvk.conf 60FPS unlock + WINE_FULLSCREEN_FSR & Box64",
        configFilesPathsSummary = "dxvk.conf + profiles/Performance_60FPS_Boost.env",
        isInstalledOnDevice = isInstalled,
        detectedPackageName = packageName,
      )
    }
  }

  fun findProfileById(id: String, isInstalled: Boolean = false): EmulatorProfile {
    val lower = id.lowercase(Locale.ROOT)
    val (label, pkg) = when {
      lower == "eden" || lower == "dev.eden.eden_emulator" -> "Eden" to "dev.eden.eden_emulator"
      lower == "eden_ea" || lower == "dev.eden.eden_emulator.ea" -> "Eden EA" to "dev.eden.eden_emulator.ea"
      lower == "yuzu" || lower == "org.yuzu.yuzu_emu" -> "Yuzu" to "org.yuzu.yuzu_emu"
      lower == "yuzu_ea" || lower == "org.yuzu.yuzu_emu.ea" -> "Yuzu EA" to "org.yuzu.yuzu_emu.ea"
      lower == "citron" || lower == "org.citron.citron_emu" -> "Citron" to "org.citron.citron_emu"
      lower == "citron_ea" || lower == "org.citron.citron_emu.ea" -> "Citron EA" to "org.citron.citron_emu.ea"
      lower == "sudachi" || lower == "org.sudachi.sudachi_emu" -> "Sudachi" to "org.sudachi.sudachi_emu"
      lower == "sudachi_ea" || lower == "org.sudachi.sudachi_emu.ea" -> "Sudachi EA" to "org.sudachi.sudachi_emu.ea"
      lower == "suyu" || lower == "dev.suyu.suyu_emu" -> "Suyu" to "dev.suyu.suyu_emu"
      lower == "uzuy" || lower == "org.uzuy.uzuy_emu" -> "Uzuy" to "org.uzuy.uzuy_emu"
      lower == "ziunx" || lower == "org.ziunx.ziunx_emu" -> "Ziunx" to "org.ziunx.ziunx_emu"
      lower == "skyline" || lower == "emu.skyline" -> "Skyline" to "emu.skyline"
      lower == "strato" || lower == "org.stratoemu.strato" -> "Strato" to "org.stratoemu.strato"
      lower == "egggame" || lower == "eggns" || lower == "com.xiaoji.egggame" -> "EggNS" to "com.xiaoji.egggame"
      lower == "ppsspp" || lower == "org.ppsspp.ppsspp" -> "PPSSPP" to "org.ppsspp.ppsspp"
      lower == "ppssppgold" || lower == "org.ppsspp.ppssppgold" -> "PPSSPP Gold" to "org.ppsspp.ppssppgold"
      lower == "aethersx2" || lower == "xyz.aethersx2.android" -> "AetherSX2" to "xyz.aethersx2.android"
      lower == "nethersx2" || lower == "xyz.nethersx2.android" -> "NetherSX2" to "xyz.nethersx2.android"
      lower == "dolphin" || lower == "org.dolphinemu.dolphinemu" -> "Dolphin" to "org.dolphinemu.dolphinemu"
      lower == "dolphin_mmjr" || lower == "org.dolphinemu.mmjr" -> "Dolphin MMJR" to "org.dolphinemu.mmjr"
      lower == "citra" || lower == "org.citra.citra_emu" -> "Citra" to "org.citra.citra_emu"
      lower == "lime3ds" || lower == "io.github.lime3ds.android" -> "Lime3DS" to "io.github.lime3ds.android"
      lower == "azahar" || lower == "io.github.azahar_emu.azahar" -> "Azahar" to "io.github.azahar_emu.azahar"
      lower == "winlator" || lower == "com.winlator" -> "Winlator" to "com.winlator"
      lower == "winlator_cmod" || lower == "com.winlator.cmod" -> "Winlator CMod" to "com.winlator.cmod"
      lower == "gamehub" || lower == "com.gamehub.emulator" -> "GameHub" to "com.gamehub.emulator"
      lower == "vita3k" || lower == "org.vita3k.emulator" -> "Vita3K" to "org.vita3k.emulator"
      lower == "duckstation" || lower == "com.github.stenzek.duckstation" -> "DuckStation" to "com.github.stenzek.duckstation"
      lower == "retroarch" || lower == "com.retroarch.aarch64" || lower == "com.retroarch" -> "RetroArch" to "com.retroarch.aarch64"
      lower == "drastic" || lower == "com.dsemu.drastic" -> "DraStic" to "com.dsemu.drastic"
      lower == "melonds" || lower == "me.magnum.melonds" -> "melonDS" to "me.magnum.melonds"
      lower == "flycast" || lower == "com.flycast.emulator" -> "Flycast" to "com.flycast.emulator"
      else -> id.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.ROOT) else it.toString() } to id
    }
    return createProfileFromInstalledApp(
      packageName = pkg,
      appLabel = label,
      isInstalled = isInstalled,
    )
  }

  fun getAllEmulatorsWithInstallStatus(context: Context): List<EmulatorProfile> {
    val now = android.os.SystemClock.elapsedRealtime()
    val cached = cachedEmulatorProfiles
    if (cached != null && (now - cachedEmulatorProfilesTimestampMs) < APP_QUERY_CACHE_TTL_MS) {
      return cached
    }
    val pm = context.packageManager
    val installedApps = queryInstalledAppsForChooser(context)
    val installedPkgMap = installedApps.associateBy { it.packageName.lowercase(Locale.ROOT) }

    val resultMap = linkedMapOf<String, EmulatorProfile>()

    // First, register installed emulators detected on device
    for (app in installedApps) {
      val profile = createProfileFromInstalledApp(
        packageName = app.packageName,
        appLabel = app.appLabel,
        overrideArchitecture = app.detectedArchitecture,
        isInstalled = true,
      )
      resultMap[app.packageName.lowercase(Locale.ROOT)] = profile
    }

    // Then, make sure ALL emulator applications are available so the user can access and select any of them
    for (id in ALL_KNOWN_EMULATOR_IDS) {
      val base = findProfileById(id)
      val key = base.packageName.lowercase(Locale.ROOT)
      if (!resultMap.containsKey(key)) {
        val isInst = installedPkgMap.containsKey(key) || try {
          pm.getApplicationInfo(base.packageName, 0) != null
        } catch (_: Throwable) {
          false
        }
        resultMap[key] = base.copy(isInstalledOnDevice = isInst)
      }
    }

    // Return list with installed emulators at the top, followed by all other emulators
    val sorted = resultMap.values.sortedWith(
      compareByDescending<EmulatorProfile> { it.isInstalledOnDevice }
        .thenBy { it.nameEn.lowercase(Locale.ROOT) }
    )
    cachedEmulatorProfiles = sorted
    cachedEmulatorProfilesTimestampMs = now
    return sorted
  }

  fun getLaunchIntentForEmulator(context: Context, profile: EmulatorProfile): Intent? {
    return try {
      val pm = context.packageManager
      val pkg = profile.detectedPackageName ?: profile.packageName
      pm.getLaunchIntentForPackage(pkg)?.apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      }
    } catch (_: Throwable) {
      null
    }
  }

  /**
   * Builds the emulator-specific configuration file content for each architecture
   * so each emulator receives its authentic native INI/CONF format for 60FPS + Performance/Vulkan FSR.
   */
  fun buildEmulatorSpecificConfigContent(
    architecture: EmulatorArchitecture,
    hwConfig: EmulatorHardwareConfig,
    existingContent: String? = null,
    isPerGameCustomIni: Boolean = false,
  ): String {
    return when (architecture) {
      EmulatorArchitecture.SWITCH_YUZU_ENGINE ->
        GameDecoderDatabase.buildOrMergeEdenConfigIni(
          existingIniContent = existingContent,
          hwConfig = hwConfig,
          isPerGameCustomIni = isPerGameCustomIni,
        )

      EmulatorArchitecture.PSP_PPSSPP_ENGINE -> {
        val texLevel = if (hwConfig.enableAmdFsrUpscaling) 3 else 1
        val texType = if (hwConfig.enableAmdFsrUpscaling) 4 else 0
        val fastMem = if (hwConfig.enablePerformanceNceOptimization) "True" else "False"
        listOf(
          "[Graphics]",
          "GraphicsBackend = 3 (VULKAN)",
          "VSyncInterval = False",
          "FrameSkip = 0",
          "FrameSkipType = 0",
          "AutoFrameSkip = False",
          "AlternativeSpeed = ${if (hwConfig.force60FpsEngineSpeed) 200 else 100}",
          "TexScalingLevel = $texLevel",
          "TexScalingType = $texType",
          "TexDeposterize = True",
          "InflateFrames = 2",
          "RenderDuplicateFrames = True",
          "",
          "[CPU]",
          "CPUCore = 1 (JIT)",
          "MultiThreaded = True",
          "FastMemory = $fastMem",
          "IOTimingMethod = 0",
        ).joinToString("\n")
      }

      EmulatorArchitecture.PS2_AETHERSX2_ENGINE -> {
        val casMode = if (hwConfig.enableAmdFsrUpscaling) 2 else 0
        val sharpness = hwConfig.fsrSharpnessPercent.coerceIn(0, 100)
        val eeCycle = if (hwConfig.enablePerformanceNceOptimization) 0 else 1
        listOf(
          "[EmuCore/GS]",
          "Renderer = 14",
          "VsyncEnable = false",
          "FramerateNTSC = 60.0",
          "FrameratePAL = 60.0",
          "SyncToHostRefreshRate = false",
          "CASMode = $casMode",
          "CASSharpness = $sharpness",
          "upscale_multiplier = ${if (hwConfig.enableAmdFsrUpscaling) 2 else 1}",
          "gpu_palette_conversion = true",
          "preload_frame_with_gs_data = true",
          "",
          "[EmuCore/Speedhacks]",
          "EECycleRate = $eeCycle",
          "EECycleSkip = 0",
          "vuThread = true",
          "fastCDVD = true",
          "WaitLoop = true",
          "IntcStat = true",
        ).joinToString("\n")
      }

      EmulatorArchitecture.DOLPHIN_GC_WII_ENGINE -> {
        val fastMem = if (hwConfig.enablePerformanceNceOptimization) "True" else "False"
        val asyncShaders = if (hwConfig.forceMaxGpuClockAndAsyncShaders) 2 else 0
        listOf(
          "[Core]",
          "GFXBackend = Vulkan",
          "CPUThread = True",
          "Fastmem = $fastMem",
          "SyncGPU = False",
          "EmulationSpeed = 1.0",
          "OverclockEnable = True",
          "Overclock = 1.25",
          "",
          "[Hardware]",
          "VSync = False",
          "",
          "[Settings]",
          "ShaderCompilationMode = $asyncShaders",
          "WaitForShadersBeforeStarting = True",
          "FastDepthCalc = True",
          "BackendMultithreading = True",
          "EFBScale = ${if (hwConfig.enableAmdFsrUpscaling) 2 else 1}",
        ).joinToString("\n")
      }

      EmulatorArchitecture.CITRA_3DS_ENGINE -> {
        val frameLimit = if (hwConfig.force60FpsEngineSpeed) 200 else 100
        val filterMode = if (hwConfig.enableAmdFsrUpscaling) 5 else 0
        val asyncShader = if (hwConfig.forceMaxGpuClockAndAsyncShaders) "true" else "false"
        listOf(
          "[Core]",
          "use_cpu_jit = true",
          "cpu_clock_percentage = ${if (hwConfig.enablePerformanceNceOptimization) 100 else 120}",
          "",
          "[Renderer]",
          "graphics_api = 2",
          "async_shader_compilation = $asyncShader",
          "async_presentation = true",
          "spirv_shader_gen = true",
          "use_vsync_new = 0",
          "use_frame_limit = true",
          "frame_limit = $frameLimit",
          "texture_filter = $filterMode",
          "resolution_factor = ${if (hwConfig.enableAmdFsrUpscaling) 2 else 1}",
        ).joinToString("\n")
      }

      EmulatorArchitecture.WINLATOR_PC_ENGINE -> {
        val fsrEnabled = if (hwConfig.enableAmdFsrUpscaling) 1 else 0
        val fsrStrength = ((100 - hwConfig.fsrSharpnessPercent) / 20).coerceIn(0, 5)
        listOf(
          "# DXVK + Box64 Performance & 60FPS Configuration",
          "dxgi.syncInterval = 0",
          "d3d9.presentInterval = 0",
          "dxgi.maxFrameRate = ${if (hwConfig.force60FpsEngineSpeed) 60 else 30}",
          "d3d9.maxFrameRate = ${if (hwConfig.force60FpsEngineSpeed) 60 else 30}",
          "d3d11.cachedDynamicResources = a",
          "dxvk.numCompilerThreads = 4",
          "dxvk.useRawSsbo = True",
          "",
          "[Box64_Performance_Environment]",
          "WINE_FULLSCREEN_FSR=$fsrEnabled",
          "WINE_FULLSCREEN_FSR_STRENGTH=$fsrStrength",
          "BOX64_DYNAREC_FASTNAN=${if (hwConfig.enablePerformanceNceOptimization) 1 else 0}",
          "BOX64_DYNAREC_FASTROUND=${if (hwConfig.enablePerformanceNceOptimization) 1 else 0}",
          "BOX64_DYNAREC_STRONGMEM=0",
          "BOX64_DYNAREC_BIGBLOCK=2",
          "TU_DEBUG=noconform,sysmem",
        ).joinToString("\n")
      }
    }
  }

  /**
   * Builds the emulator-specific 60FPS patch file content for the selected game.
   */
  fun buildEmulatorSpecificPatchPayload(
    architecture: EmulatorArchitecture,
    gameId: String,
    gameTitle: String,
    versionTag: String,
    decodedSwitch: DecodedGameRelease,
  ): String {
    return when (architecture) {
      EmulatorArchitecture.SWITCH_YUZU_ENGINE ->
        decodedSwitch.pchtxtPayload

      EmulatorArchitecture.PSP_PPSSPP_ENGINE -> {
        val cleanId = gameId.uppercase(Locale.US).ifBlank { "UCUS98653" }
        listOf(
          "_S $cleanId",
          "_G $gameTitle",
          "_C1 60.0 FPS Constant Unlock + Performance Smooth Frame Pacing ($versionTag)",
          "_L 0x20001A40 0x00000001",
          "_L 0x20001A44 0x3F800000",
          "_C1 Disable 30 FPS VBlank Cap",
          "_L 0x20084F10 0x00000000",
        ).joinToString("\n")
      }

      EmulatorArchitecture.PS2_AETHERSX2_ENGINE -> {
        listOf(
          "gametitle=$gameTitle [$gameId] ($versionTag)",
          "comment=60.0 FPS Constant Unlock + Performance Frame Pacing",
          "",
          "// Unlock 60 FPS VBlank Divider",
          "patch=1,EE,201A4C00,extended,24020001",
          "patch=1,EE,201A4C04,extended,03E00008",
          "patch=1,EE,201A4C08,extended,00000000",
        ).joinToString("\n")
      }

      EmulatorArchitecture.DOLPHIN_GC_WII_ENGINE -> {
        listOf(
          "# $gameTitle [$gameId] ($versionTag) - 60 FPS + Performance Profile",
          "[Core]",
          "CPUThread = True",
          "Fastmem = True",
          "SyncGPU = False",
          "",
          "[Video_Settings]",
          "wideScreenHack = True",
          "",
          "[Gecko]",
          "\$60 FPS Constant Unlock",
          "04001A40 38600001",
          "04001A44 4E800020",
          "",
          "[Gecko_Enabled]",
          "\$60 FPS Constant Unlock",
        ).joinToString("\n")
      }

      EmulatorArchitecture.CITRA_3DS_ENGINE -> {
        listOf(
          "[60 FPS Constant Unlock - $gameTitle ($versionTag) *citra_enabled]",
          "D3000000 08000000",
          "001A4C00 00000001",
          "001A4C04 E12FFF1E",
          "D2000000 00000000",
        ).joinToString("\n")
      }

      EmulatorArchitecture.WINLATOR_PC_ENGINE -> {
        listOf(
          "# Winlator Container 60FPS + Performance Profile for $gameTitle [$gameId]",
          "DXVK_FRAME_RATE=60",
          "DXVK_ASYNC=1",
          "WINE_FULLSCREEN_FSR=1",
          "BOX64_DYNAREC_FASTNAN=1",
          "BOX64_DYNAREC_STRONGMEM=0",
        ).joinToString("\n")
      }
    }
  }
}
