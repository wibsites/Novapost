package com.example.thermal

import android.content.Context
import android.os.Build
import android.os.PowerManager
import androidx.annotation.RequiresApi
import java.util.concurrent.Executors
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

data class DeviceThermalStatus(
  val statusLevel: Int = 0,
  val statusNameEn: String = "Normal",
  val statusNameAr: String = "طبيعي",
  val thermalHeadroom: Float? = null,
  val isHot: Boolean = false,
  val isSevere: Boolean = false,
  val recommendationEn: String = "Operating within normal thermal range. All profiles safe.",
  val recommendationAr: String = "درجة الحرارة في النطاق الطبيعي المستقر. جميع الأنماط آمنة.",
  val disclaimerEn: String = "Gaming naturally generates heat. ModInjector adjusts emulator workload but does not actively cool hardware.",
  val disclaimerAr: String = "الألعاب تستهلك طاقة وتولد حرارة طبيعياً. التطبيق يخفف عبء المعالجة عبر الإعدادات ولا يبرد العتاد ذاتياً.",
)

object ThermalMonitor {

  fun getThermalStatusName(level: Int, isArabic: Boolean): String {
    return when (level) {
      0 -> if (isArabic) "طبيعي (مستقر)" else "Normal (Stable)"
      1 -> if (isArabic) "دافئ خفيف" else "Light Warmth"
      2 -> if (isArabic) "حرارة متوسطة" else "Moderate Heat"
      3 -> if (isArabic) "حرارة مرتفعة (بدء التخنيق)" else "Severe (Throttling)"
      4 -> if (isArabic) "حرارة حرجة" else "Critical"
      5 -> if (isArabic) "طوارئ قصوى" else "Emergency"
      6 -> if (isArabic) "إيقاف طارئ" else "Shutdown"
      else -> if (isArabic) "غير محدد" else "Unknown"
    }
  }

  fun readCurrentThermalStatus(context: Context): DeviceThermalStatus {
    val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
      ?: return DeviceThermalStatus()

    val level = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      try {
        pm.currentThermalStatus
      } catch (_: Throwable) {
        0
      }
    } else {
      0
    }

    val headroom = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
      try {
        val hr = pm.getThermalHeadroom(10)
        if (hr.isNaN() || hr < 0f) null else hr
      } catch (_: Throwable) {
        null
      }
    } else {
      null
    }

    val isHot = level >= 2 // MODERATE or higher
    val isSevere = level >= 3 // SEVERE or higher

    val (recEn, recAr) = when {
      isSevere -> Pair(
        "High thermal level detected. Recommend switching to Battery Saver or Balanced profile to reduce GPU/CPU load.",
        "تم رصد حرارة مرتفعة. يُنصح بالتحويل إلى نمط توفير الطاقة أو المتوازن لتخفيف الحمل ومنع هبوط الفريمات."
      )
      isHot -> Pair(
        "Device is moderately warm. Balanced profile recommended to prevent thermal throttling.",
        "الجهاز دافئ بدرجة متوسطة. يُفضل استخدام النمط المتوازن لمنع هبوط الأداء الحراري."
      )
      else -> Pair(
        "Operating within safe thermal limits. Performance or Balanced profile is suitable.",
        "الحرارة ضمن الحدود الآمنة. نمط الأداء أو المتوازن مناسب تماماً."
      )
    }

    return DeviceThermalStatus(
      statusLevel = level,
      statusNameEn = getThermalStatusName(level, false),
      statusNameAr = getThermalStatusName(level, true),
      thermalHeadroom = headroom,
      isHot = isHot,
      isSevere = isSevere,
      recommendationEn = recEn,
      recommendationAr = recAr,
    )
  }

  fun observeThermalStatus(context: Context): Flow<DeviceThermalStatus> = callbackFlow {
    val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
    if (pm == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
      trySend(readCurrentThermalStatus(context))
      channel.close()
      return@callbackFlow
    }

    val executor = Executors.newSingleThreadExecutor()
    val listener = PowerManager.OnThermalStatusChangedListener { _ ->
      trySend(readCurrentThermalStatus(context))
    }

    try {
      pm.addThermalStatusListener(executor, listener)
      trySend(readCurrentThermalStatus(context))
    } catch (_: Throwable) {
      trySend(readCurrentThermalStatus(context))
    }

    awaitClose {
      try {
        pm.removeThermalStatusListener(listener)
      } catch (_: Throwable) {
      }
      executor.shutdown()
    }
  }
}
