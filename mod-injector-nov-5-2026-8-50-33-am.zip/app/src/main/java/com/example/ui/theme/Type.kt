package com.example.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.R

val SpaceGroteskFontFamily = FontFamily(
  Font(R.font.space_grotesk, FontWeight.Normal),
  Font(R.font.space_grotesk, FontWeight.Medium),
  Font(R.font.space_grotesk, FontWeight.Bold),
)

val CairoFontFamily = FontFamily(
  Font(R.font.cairo, FontWeight.Normal),
  Font(R.font.cairo, FontWeight.Medium),
  Font(R.font.cairo, FontWeight.Bold),
)

val JetBrainsMonoFontFamily = FontFamily(
  Font(R.font.jetbrains_mono, FontWeight.Normal),
  Font(R.font.jetbrains_mono, FontWeight.Medium),
  Font(R.font.jetbrains_mono, FontWeight.Bold),
)

fun buildAppTypography(isArabic: Boolean): Typography {
  val primaryFont = if (isArabic) CairoFontFamily else SpaceGroteskFontFamily
  return Typography(
    headlineMedium = TextStyle(
      fontFamily = primaryFont,
      fontWeight = FontWeight.Bold,
      fontSize = 25.sp,
      lineHeight = 32.sp,
    ),
    titleLarge = TextStyle(
      fontFamily = primaryFont,
      fontWeight = FontWeight.Bold,
      fontSize = 20.sp,
      lineHeight = 27.sp,
    ),
    titleMedium = TextStyle(
      fontFamily = primaryFont,
      fontWeight = FontWeight.Bold,
      fontSize = 16.sp,
      lineHeight = 23.sp,
    ),
    bodyLarge = TextStyle(
      fontFamily = primaryFont,
      fontWeight = FontWeight.Medium,
      fontSize = 15.sp,
      lineHeight = 22.sp,
    ),
    bodyMedium = TextStyle(
      fontFamily = primaryFont,
      fontWeight = FontWeight.Normal,
      fontSize = 13.sp,
      lineHeight = 19.sp,
    ),
    labelLarge = TextStyle(
      fontFamily = primaryFont,
      fontWeight = FontWeight.Bold,
      fontSize = 14.sp,
      lineHeight = 20.sp,
    ),
    labelSmall = TextStyle(
      fontFamily = JetBrainsMonoFontFamily,
      fontWeight = FontWeight.Medium,
      fontSize = 11.sp,
      lineHeight = 16.sp,
    ),
  )
}

val Typography = buildAppTypography(isArabic = false)
