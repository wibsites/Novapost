package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Visually comfortable, calm dark palette (Soft Slate Navy + Sky Blue + Soft Mint)
val CyberNavyDark = Color(0xFF0B111E)
val CyberSurfaceDark = Color(0xFF131C2E)
val CyberCardDark = Color(0xFF1B273D)
val ElectricCyan = Color(0xFF38BDF8)
val NeonEmerald = Color(0xFF34D399)
val AmberPulse = Color(0xFFFBBF24)
val CrimsonAlert = Color(0xFFF87171)
val SlateTextPrimary = Color(0xFFF1F5F9)
val SlateTextSecondary = Color(0xFF94A3B8)

// Visually comfortable, soft light palette
val CyberLightBg = Color(0xFFF4F7FB)
val CyberLightSurface = Color(0xFFFFFFFF)
val DeepCyanPrimary = Color(0xFF0284C7)
val DeepEmeraldSecondary = Color(0xFF059669)
