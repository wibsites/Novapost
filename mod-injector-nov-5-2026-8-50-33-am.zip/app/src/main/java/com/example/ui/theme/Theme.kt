package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
  primary = ElectricCyan,
  onPrimary = CyberNavyDark,
  primaryContainer = CyberCardDark,
  onPrimaryContainer = ElectricCyan,
  secondary = NeonEmerald,
  onSecondary = CyberNavyDark,
  secondaryContainer = Color(0xFF0E332B),
  onSecondaryContainer = NeonEmerald,
  tertiary = AmberPulse,
  background = CyberNavyDark,
  onBackground = SlateTextPrimary,
  surface = CyberSurfaceDark,
  onSurface = SlateTextPrimary,
  surfaceVariant = CyberCardDark,
  onSurfaceVariant = SlateTextSecondary,
  error = CrimsonAlert,
)

private val LightColorScheme = lightColorScheme(
  primary = DeepCyanPrimary,
  onPrimary = Color.White,
  primaryContainer = Color(0xFFC8F4FF),
  onPrimaryContainer = Color(0xFF001F25),
  secondary = DeepEmeraldSecondary,
  onSecondary = Color.White,
  secondaryContainer = Color(0xFFB9F6D3),
  onSecondaryContainer = Color(0xFF00210E),
  tertiary = AmberPulse,
  background = CyberLightBg,
  onBackground = Color(0xFF0E1726),
  surface = CyberLightSurface,
  onSurface = Color(0xFF0E1726),
  surfaceVariant = Color(0xFFE3ECF7),
  onSurfaceVariant = Color(0xFF475872),
  error = CrimsonAlert,
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  isArabic: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
  MaterialTheme(
    colorScheme = colorScheme,
    typography = buildAppTypography(isArabic = isArabic),
    content = content,
  )
}
