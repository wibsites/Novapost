package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.example.ai.AiOptimizationPlan
import com.example.ai.AiOptimizationUiState
import com.example.ai.DirectFrameAndHardwareMetrics
import com.example.ai.LocalNpuUpscalerStatus
import com.example.network.DirectPhoneTelemetry
import com.example.network.NetworkConnectionState
import com.example.ui.theme.JetBrainsMonoFontFamily

@Composable
fun AiOptimizationSystemCard(
  isArabic: Boolean,
  localNpuEnabled: Boolean,
  localNpuStatus: LocalNpuUpscalerStatus,
  isBackgroundGovernorActive: Boolean = false,
  isFrameGenOverlayActive: Boolean = false,
  overlayStatusText: String = "",
  aiState: AiOptimizationUiState,
  latestMetrics: DirectFrameAndHardwareMetrics?,
  networkState: NetworkConnectionState,
  directTelemetry: DirectPhoneTelemetry,
  isRunning: Boolean,
  isCloudSyncing: Boolean,
  onToggleLocalNpuUpscaling: (Boolean) -> Unit,
  onToggleBackgroundGovernor: (Boolean) -> Unit = {},
  onToggleFrameGenOverlay: (Boolean) -> Unit = {},
  onRunAiOptimization: () -> Unit,
  onApplyAiPlan: (AiOptimizationPlan) -> Unit,
  onSyncNetwork: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val isAiBusy = aiState is AiOptimizationUiState.Running

  Card(
    modifier = modifier
      .fillMaxWidth()
      .testTag("ai_optimization_system_card"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      // Header Row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f),
        ) {
          Icon(
            imageVector = Icons.Filled.AutoAwesome,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(22.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Column {
            Text(
              text = if (isArabic) {
                "✨ نظام الذكاء الاصطناعي المحلي (Local NPU AI Governor)"
              } else {
                "✨ Local NPU AI Governor (TensorFlow Lite)"
              },
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface,
            )
            Text(
              text = if (isArabic) {
                "يعمل في الخلفية عبر Snapdragon Hexagon NPU مع إشعار مستمر: AI NPU Active & 60FPS Unlocked"
              } else {
                "Persistent Background Governor on Snapdragon Hexagon NPU ('AI NPU Active & 60FPS Unlocked')"
              },
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.secondary,
              fontWeight = FontWeight.SemiBold,
            )
          }
        }

        FilledTonalButton(
          onClick = onSyncNetwork,
          enabled = !isCloudSyncing && !isAiBusy,
          shape = RoundedCornerShape(10.dp),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
          modifier = Modifier
            .height(36.dp)
            .testTag("ai_card_network_sync_button"),
        ) {
          Icon(
            imageVector = Icons.Filled.CloudDownload,
            contentDescription = null,
            modifier = Modifier.size(14.dp),
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = if (isArabic) "فحص الشبكة" else "Sync Net",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
          )
        }
      }

      // Dedicated Toggle Row 1: 'Local NPU AI Upscaling'
      Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 10.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f),
          ) {
            Icon(
              imageVector = Icons.Filled.Memory,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(20.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = if (isArabic) {
                  "Local NPU AI Upscaling (رفع الدقة المحلي عبر NPU)"
                } else {
                  "Local NPU AI Upscaling"
                },
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
              )
              Text(
                text = if (isArabic) {
                  localNpuStatus.statusHeadlineAr
                } else {
                  localNpuStatus.statusHeadlineEn
                },
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
          Spacer(modifier = Modifier.width(8.dp))
          Switch(
            checked = localNpuEnabled,
            onCheckedChange = onToggleLocalNpuUpscaling,
            modifier = Modifier.testTag("switch_local_npu_ai_upscaling"),
          )
        }
      }

      // Dedicated Toggle Row 2: Persistent Background AI Governor Service ('AI NPU Active & 60FPS Unlocked')
      Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (isBackgroundGovernorActive) {
          MaterialTheme.colorScheme.secondary.copy(alpha = 0.14f)
        } else {
          MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
        },
        border = BorderStroke(
          1.dp,
          if (isBackgroundGovernorActive) {
            MaterialTheme.colorScheme.secondary.copy(alpha = 0.5f)
          } else {
            MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
          },
        ),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 10.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f),
          ) {
            Icon(
              imageVector = Icons.Filled.Bolt,
              contentDescription = null,
              tint = if (isBackgroundGovernorActive) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(20.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = if (isArabic) {
                  "حارس الخلفية المستمر (AI NPU Active & 60FPS Unlocked)"
                } else {
                  "Persistent Background AI Governor ('AI NPU Active & 60FPS Unlocked')"
                },
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
              )
              Text(
                text = if (isArabic) {
                  "يبقي التطبيق نشطاً أثناء اللعب ويحقن speed_limit=200 و cpu_backend=1 (NCE) و scaling_filter=5 (FSR)"
                } else {
                  "Keeps governor alive in background • speed_limit=200 • cpu_backend=1 (NCE) • scaling_filter=5 (FSR)"
                },
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
          Spacer(modifier = Modifier.width(8.dp))
          Switch(
            checked = isBackgroundGovernorActive,
            onCheckedChange = onToggleBackgroundGovernor,
            modifier = Modifier.testTag("switch_background_ai_governor"),
          )
        }
      }

      // Dedicated Toggle Row 3: External AI Frame Generation & Spatial Upscaler Overlay (Lossless Scaling for Android)
      Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (isFrameGenOverlayActive) {
          MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
        } else {
          MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
        },
        border = BorderStroke(
          1.dp,
          if (isFrameGenOverlayActive) {
            MaterialTheme.colorScheme.primary
          } else {
            MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
          },
        ),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("ai_frame_gen_overlay_section"),
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 10.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.weight(1f),
            ) {
              Icon(
                imageVector = Icons.Filled.AutoAwesome,
                contentDescription = null,
                tint = if (isFrameGenOverlayActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp),
              )
              Spacer(modifier = Modifier.width(8.dp))
              Column {
                Text(
                  text = if (isArabic) {
                    "Start AI Frame Generation Overlay (توليد الإطارات العائم عبر NPU)"
                  } else {
                    "Start AI Frame Generation Overlay (Lossless Scaling NPU)"
                  },
                  style = MaterialTheme.typography.titleSmall,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.onSurface,
                )
                Text(
                  text = if (overlayStatusText.isNotBlank()) {
                    overlayStatusText
                  } else if (isArabic) {
                    "يلتقط إطارات المحاكي عبر MediaProjection ويولد إطارات بينية 120FPS عبر Hexagon NPU على طبقة شفافة"
                  } else {
                    "Captures raw frames via MediaProjection & renders NPU-interpolated 120FPS onto TYPE_APPLICATION_OVERLAY"
                  },
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
            }
            Spacer(modifier = Modifier.width(8.dp))
            Switch(
              checked = isFrameGenOverlayActive,
              onCheckedChange = onToggleFrameGenOverlay,
              modifier = Modifier.testTag("switch_ai_frame_gen_overlay"),
            )
          }

          Button(
            onClick = { onToggleFrameGenOverlay(!isFrameGenOverlayActive) },
            modifier = Modifier
              .fillMaxWidth()
              .height(44.dp)
              .testTag("start_ai_frame_gen_overlay_button"),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(
              containerColor = if (isFrameGenOverlayActive) {
                MaterialTheme.colorScheme.error
              } else {
                MaterialTheme.colorScheme.secondary
              },
              contentColor = if (isFrameGenOverlayActive) {
                MaterialTheme.colorScheme.onError
              } else {
                MaterialTheme.colorScheme.onSecondary
              },
            ),
          ) {
            Icon(
              imageVector = Icons.Filled.Bolt,
              contentDescription = null,
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = if (isFrameGenOverlayActive) {
                if (isArabic) "⏹ إيقاف AI Frame Generation Overlay" else "⏹ Stop AI Frame Generation Overlay"
              } else {
                if (isArabic) "🚀 Start AI Frame Generation Overlay (NPU 120FPS)" else "🚀 Start AI Frame Generation Overlay"
              },
              style = MaterialTheme.typography.labelLarge,
              fontWeight = FontWeight.Bold,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }
        }
      }

      // Live Display Frame Pacing & Sensor Strip (Measured via Choreographer + BatteryManager)
      Surface(
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("ai_live_telemetry_strip"),
      ) {
        Column(
          modifier = Modifier.padding(10.dp),
          verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
          val fpsVal = latestMetrics?.measuredDisplayFps ?: directTelemetry.displayRefreshHz.toDouble()
          val low1Val = latestMetrics?.onePercentLowFps ?: (fpsVal - 1.0)
          val jitterVal = latestMetrics?.frameJitterMs ?: 0.35

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Filled.Speed,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(15.dp),
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = if (isArabic) {
                  "قياس الإطارات المباشر: $fpsVal FPS (أدنى 1%: $low1Val)"
                } else {
                  "Live Frame Pacing: $fpsVal FPS (1% Low: $low1Val)"
                },
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
              )
            }
            Text(
              text = "${directTelemetry.batteryTempCelsius}°C • ${directTelemetry.availableRamMb}MB RAM",
              fontFamily = JetBrainsMonoFontFamily,
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.secondary,
              fontWeight = FontWeight.Bold,
            )
          }

          Text(
            text = if (isArabic) {
              "المسرّع النشط: ${localNpuStatus.activeAccelerator.labelAr} • تذبذب الإطار: ${jitterVal}ms"
            } else {
              "Active Accelerator: ${localNpuStatus.activeAccelerator.labelEn} • Jitter: ${jitterVal}ms"
            },
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }

      // One-Tap Run Local NPU AI Optimization Button
      Button(
        onClick = onRunAiOptimization,
        enabled = !isAiBusy && !isRunning,
        modifier = Modifier
          .fillMaxWidth()
          .height(50.dp)
          .testTag("run_ai_optimization_button"),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(
          containerColor = MaterialTheme.colorScheme.primary,
          contentColor = MaterialTheme.colorScheme.onPrimary,
        ),
      ) {
        if (isAiBusy) {
          CircularProgressIndicator(
            modifier = Modifier.size(18.dp),
            strokeWidth = 2.dp,
            color = MaterialTheme.colorScheme.onPrimary,
          )
          Spacer(modifier = Modifier.width(8.dp))
        } else {
          Icon(
            imageVector = Icons.Filled.AutoAwesome,
            contentDescription = null,
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
        }
        Text(
          text = if (isArabic) {
            "✨ تشغيل Local NPU AI Upscaling (جودة + 60 FPS)"
          } else {
            "✨ Run Local NPU AI Upscaling (Quality + 60 FPS)"
          },
          style = MaterialTheme.typography.labelLarge,
          fontWeight = FontWeight.Bold,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }

      // Active Local NPU AI Optimization Result Box
      val activePlan: AiOptimizationPlan? = when (aiState) {
        is AiOptimizationUiState.Success -> aiState.plan
        is AiOptimizationUiState.Error -> aiState.fallbackPlan
        else -> null
      }

      AnimatedVisibility(visible = activePlan != null) {
        if (activePlan != null) {
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("ai_optimization_plan_result_box"),
          ) {
            Column(
              modifier = Modifier.padding(12.dp),
              verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  modifier = Modifier.weight(1f),
                ) {
                  Icon(
                    imageVector = Icons.Filled.CheckCircle,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.size(18.dp),
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = if (isArabic) activePlan.summaryHeadlineAr else activePlan.summaryHeadlineEn,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                  )
                }
              }

              Text(
                text = if (isArabic) activePlan.qualityAndFrameAnalysisAr else activePlan.qualityAndFrameAnalysisEn,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )

              CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Surface(
                  shape = RoundedCornerShape(8.dp),
                  color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
                  modifier = Modifier.fillMaxWidth(),
                ) {
                  Column(
                    modifier = Modifier.padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp),
                  ) {
                    Text(
                      text = "Local NPU Scale: ${activePlan.resolutionScaleLabel} • Sharpness: ${activePlan.aiFsrSharpnessPercent}%",
                      fontFamily = JetBrainsMonoFontFamily,
                      style = MaterialTheme.typography.labelSmall,
                      color = MaterialTheme.colorScheme.primary,
                      fontWeight = FontWeight.Bold,
                    )
                    activePlan.optimizationPillars.take(3).forEach { pillar ->
                      Text(
                        text = "• $pillar",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface,
                      )
                    }
                  }
                }
              }

              HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))

              Button(
                onClick = { onApplyAiPlan(activePlan) },
                enabled = !isRunning,
                modifier = Modifier
                  .fillMaxWidth()
                  .height(46.dp)
                  .testTag("apply_ai_optimization_plan_button"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                  containerColor = MaterialTheme.colorScheme.secondary,
                  contentColor = MaterialTheme.colorScheme.onSecondary,
                ),
              ) {
                Icon(
                  imageVector = Icons.Filled.Bolt,
                  contentDescription = null,
                  modifier = Modifier.size(18.dp),
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = if (isArabic) {
                    "🚀 تطبيق خطة الـ NPU المحلي وتفعيل 60 FPS"
                  } else {
                    "🚀 Apply Local NPU Plan & Unlock 60 FPS"
                  },
                  style = MaterialTheme.typography.labelLarge,
                  fontWeight = FontWeight.Bold,
                )
              }
            }
          }
        }
      }
    }
  }
}
