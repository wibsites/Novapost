package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.DevicePerformanceDetector
import com.example.data.EmulatorArchitecture
import com.example.data.EmulatorHardwareConfig
import com.example.data.EmulatorRegistry
import com.example.data.GameDecoderDatabase
import com.example.data.InstalledAppInfo
import com.example.data.InstalledGameItem
import com.example.data.ModInjectorRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("NovaBoost", appName)
  }

  @Test
  fun `resolveGameInput handles Arabic English and Hex Title IDs with single nsobid per file`() {
    val totkFromAr = GameDecoderDatabase.resolveGameInput("زيلدا دموع المملكة", "1.2.1")
    assertEquals("0100F2C0115B6000", totkFromAr.primaryTitleId)
    assertEquals("1.2.1", totkFromAr.requestedVersion)
    assertTrue(totkFromAr.versionFiles.isNotEmpty())

    totkFromAr.versionFiles.forEach { vf ->
      val lines = vf.pchtxtContent.lines()
      assertTrue(
        "First line of ${vf.fileName} must start with @nsobid-",
        lines.first().startsWith("@nsobid-"),
      )
      val nsobidCount = lines.count { it.trim().startsWith("@nsobid-") }
      assertEquals("Each .pchtxt file must contain strictly 1 @nsobid header", 1, nsobidCount)
      assertTrue(vf.pchtxtContent.contains("@enabled"))
    }

    val rdrFromHex = GameDecoderDatabase.resolveGameInput("01007820196A6000", "Auto")
    assertEquals("Red Dead Redemption", rdrFromHex.titleNameEn)
    assertTrue(rdrFromHex.cheatFileName.endsWith(".txt"))
    assertTrue(rdrFromHex.cheatFileContent.contains("60 FPS Constant Unlock"))
  }

  @Test
  fun `buildOrMergeEdenConfigIni writes Core speed_limit NCE cpu_backend scaling_filter and PerGame use_global`() {
    val hwConfig = EmulatorHardwareConfig(
      force60FpsEngineSpeed = true,
      enableAmdFsrUpscaling = true,
      fsrSharpnessPercent = 85,
      forceMaxGpuClockAndAsyncShaders = true,
      enablePerformanceNceOptimization = true,
    )

    val existingIni = """
      [Core]
      use_multi_core=false

      [Renderer]
      use_vsync=1
      speed_limit=100
      window_adapting_filter=1
      custom_user_setting=keep_me

      [GpuDriver]
      driver_path=/data/user/0/dev.eden.eden_emulator/files/gpu_drivers/Turnip_v24.zip
    """.trimIndent()

    val mergedGlobal = GameDecoderDatabase.buildOrMergeEdenConfigIni(existingIni, hwConfig, isPerGameCustomIni = false)
    assertTrue(mergedGlobal.contains("use_vsync=0"))
    assertTrue(mergedGlobal.contains("use_speed_limit=true"))
    // Global config.ini MUST keep speed_limit=100 and frame_limit=100 (never change global speed_limit)
    assertTrue(mergedGlobal.contains("speed_limit=100"))
    assertTrue(mergedGlobal.contains("frame_limit=100"))
    assertFalse(mergedGlobal.contains("speed_limit=200"))
    assertTrue(mergedGlobal.contains("scaling_filter=5"))
    assertTrue(mergedGlobal.contains("window_adapting_filter=5"))
    assertTrue(mergedGlobal.contains("fsr_sharpening_slider=85"))
    assertTrue(mergedGlobal.contains("cpu_backend=1"))
    assertTrue(mergedGlobal.contains("cpu_accuracy=0"))
    assertTrue(mergedGlobal.contains("gpu_accuracy=0"))
    assertTrue(mergedGlobal.contains("use_reactive_flushing=false"))
    assertTrue(mergedGlobal.contains("use_asynchronous_shaders=true"))
    assertTrue(mergedGlobal.contains("force_max_clock=true"))
    assertTrue(mergedGlobal.contains("custom_user_setting=keep_me"))
    assertTrue(mergedGlobal.contains("driver_path=/data/user/0/dev.eden.eden_emulator/files/gpu_drivers/Turnip_v24.zip"))

    // Per-game custom/<Title_ID>.ini sets speed_limit=200 and frame_limit=200 with use_global=false
    val customGameIni = GameDecoderDatabase.buildOrMergeEdenConfigIni(mergedGlobal, hwConfig, isPerGameCustomIni = true)
    val speedLimit200Count = customGameIni.lines().count { it.trim() == "speed_limit=200" }
    assertEquals("Both [Core] and [Renderer] in per-game custom ini must contain speed_limit=200", 2, speedLimit200Count)
    assertTrue(customGameIni.contains("frame_limit=120") || customGameIni.contains("frame_limit=200"))
    assertTrue(customGameIni.contains("speed_limit\\use_global=false"))
    assertTrue(customGameIni.contains("frame_limit\\use_global=false"))
    assertTrue(customGameIni.contains("use_vsync\\use_global=false"))
    assertTrue(customGameIni.contains("cpu_backend\\use_global=false"))
    assertTrue(customGameIni.contains("scaling_filter\\use_global=false"))
    assertTrue(customGameIni.contains("driver_path=/data/user/0/dev.eden.eden_emulator/files/gpu_drivers/Turnip_v24.zip"))

    val restored30 = GameDecoderDatabase.buildDefault30FpsConfigIni(customGameIni)
    assertTrue(restored30.contains("speed_limit=100"))
    assertTrue(restored30.contains("scaling_filter=1"))
  }

  @Test
  fun `emulatorRegistry dynamic app detection and native config generation work for all engines`() {
    val hwConfig = EmulatorHardwareConfig()
    val decodedSwitch = GameDecoderDatabase.resolveGameInput("0100F2C0115B6000", "1.2.1")

    val ppssppCfg = EmulatorRegistry.buildEmulatorSpecificConfigContent(
      EmulatorArchitecture.PSP_PPSSPP_ENGINE,
      hwConfig,
    )
    assertTrue(ppssppCfg.contains("GraphicsBackend = 3 (VULKAN)"))
    assertTrue(ppssppCfg.contains("TexScalingType = 4"))

    val ps2Cfg = EmulatorRegistry.buildEmulatorSpecificConfigContent(
      EmulatorArchitecture.PS2_AETHERSX2_ENGINE,
      hwConfig,
    )
    assertTrue(ps2Cfg.contains("FramerateNTSC = 60.0"))
    assertTrue(ps2Cfg.contains("CASMode = 2"))

    val ps2Patch = EmulatorRegistry.buildEmulatorSpecificPatchPayload(
      EmulatorArchitecture.PS2_AETHERSX2_ENGINE,
      "SLUS-20946",
      "GTA San Andreas",
      "1.03",
      decodedSwitch,
    )
    assertTrue(ps2Patch.contains("patch=1,EE,"))

    val winlatorCfg = EmulatorRegistry.buildEmulatorSpecificConfigContent(
      EmulatorArchitecture.WINLATOR_PC_ENGINE,
      hwConfig,
    )
    assertTrue(winlatorCfg.contains("dxgi.maxFrameRate = 60"))
    assertTrue(winlatorCfg.contains("WINE_FULLSCREEN_FSR=1"))
    assertTrue(winlatorCfg.contains("BOX64_DYNAREC_FASTNAN=1"))
  }

  @Test
  fun `devicePerformanceDetector and ViewModel app chooser and Smart Profile screen work end to end`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val hwInfo = DevicePerformanceDetector.detectDeviceHardware(context)
    assertTrue(hwInfo.chipName.isNotBlank())
    assertTrue(hwInfo.hardwareSummary.isNotBlank())
    assertTrue(hwInfo.totalRamGb >= 2)
    assertTrue(hwInfo.refreshRateHz >= 60)

    val repo = ModInjectorRepository(context)
    val vm = ModInjectorViewModel(repo, context)

    // Verify Smart Profile preselection matches detected device class
    assertEquals(hwInfo.recommendedProfile, vm.uiState.value.selectedProfile)

    // Test Smart Profile and Diagnosis screen navigation
    assertFalse(vm.uiState.value.isSmartProfileScreenOpen)
    vm.onOpenSmartProfileScreen()
    assertTrue(vm.uiState.value.isSmartProfileScreenOpen)
    vm.onCloseSmartProfileScreen()
    assertFalse(vm.uiState.value.isSmartProfileScreenOpen)

    assertFalse(vm.uiState.value.isDiagnosisScreenOpen)
    vm.onOpenDiagnosisScreen()
    assertTrue(vm.uiState.value.isDiagnosisScreenOpen)
    vm.onCloseDiagnosisScreen()
    assertFalse(vm.uiState.value.isDiagnosisScreenOpen)

    // Simulate picking an app from the Share-style Installed App Chooser
    val pickedApp = InstalledAppInfo(
      packageName = "dev.eden.eden_emulator",
      appLabel = "Eden",
      icon = null,
      detectedArchitecture = EmulatorArchitecture.SWITCH_YUZU_ENGINE,
      isLikelyEmulatorOrGame = true,
    )
    vm.onPickInstalledPhoneApp(pickedApp)
    assertEquals("dev.eden.eden_emulator", vm.uiState.value.selectedEmulator.packageName)
    assertEquals(EmulatorArchitecture.SWITCH_YUZU_ENGINE, vm.uiState.value.selectedEmulator.architecture)

    val folderGame = InstalledGameItem(
      titleId = "0100000000010000",
      nameEn = "Super Mario Odyssey",
      nameAr = "سوبر ماريو أوديسي",
      detectedVersion = "1.3.0",
      has60FpsPatch = false,
      hasPerformanceConfig = false,
      folderSource = "load/0100000000010000",
    )

    vm.onSelectInstalledGame(folderGame)
    assertEquals(folderGame, vm.uiState.value.selectedGame)
    assertEquals("Super Mario Odyssey", vm.uiState.value.gameNameInput)
    assertEquals("1.3.0", vm.uiState.value.gameVersionInput)
    assertEquals("0100000000010000", vm.uiState.value.resolvedPreview.primaryTitleId)

    vm.onTogglePerformanceNce(false)
    assertFalse(vm.uiState.value.enablePerformanceNce)
    vm.onTogglePerformanceNce(true)
    assertTrue(vm.uiState.value.enablePerformanceNce)

    vm.onFsrSharpnessChanged(92)
    assertEquals(92, vm.uiState.value.fsrSharpnessPercent)

    val initialLang = vm.uiState.value.isArabic
    vm.toggleLanguage()
    assertEquals(!initialLang, vm.uiState.value.isArabic)
  }

  @Test
  fun `normalizeSwitchTitleIdToBaseGame and parseSwitchVersionFromFileName and diagnosis statuses work honestly`() {
    // Switch Update Title ID (ending in 800) must normalize to Base Game Title ID (ending in 000)
    val normalizedBotw = GameDecoderDatabase.normalizeSwitchTitleIdToBaseGame("01007EF00011E800")
    assertEquals("01007EF00011E000", normalizedBotw)

    val parsedSemantic = GameDecoderDatabase.parseSwitchVersionFromFileName("Zelda_BOTW_Update_v1.6.0_[01007EF00011E800].nsp")
    assertEquals("1.6.0", parsedSemantic)

    val parsedNumeric = GameDecoderDatabase.parseSwitchVersionFromFileName("Zelda_BOTW_[01007EF00011E800][v196608].nsp")
    assertEquals("1.3.0", parsedNumeric)

    // 1. Matched: BOTW 1.6.0 uses authentic NSO Build ID 16A91992BBA71201...
    val botwDecoded = GameDecoderDatabase.resolveGameInput("01007EF00011E800", "1.6.0")
    assertEquals("01007EF00011E000", botwDecoded.primaryTitleId)
    assertEquals("16A91992BBA71201.txt", botwDecoded.cheatFileName)
    assertTrue(botwDecoded.hasExactBuildIdPatchMatch)
    assertEquals("Matched", botwDecoded.diagnosisStatus.statusEn)

    // 2. Version mismatch: Known game (BOTW) but with an unverified Build ID or unsupported version
    val mismatchBuildDecoded = GameDecoderDatabase.resolveGameInput(
      rawGameInput = "01007EF00011E800",
      rawVersionInput = "1.6.0",
      customBuildId = "AABBCCDDEEFF0011223344556677889900000000",
    )
    assertFalse(mismatchBuildDecoded.hasExactBuildIdPatchMatch)
    assertEquals("Version mismatch", mismatchBuildDecoded.diagnosisStatus.statusEn)

    val mismatchVersionDecoded = GameDecoderDatabase.resolveGameInput("01007EF00011E000", "9.9.9")
    assertFalse(mismatchVersionDecoded.hasExactBuildIdPatchMatch)
    assertEquals("Version mismatch", mismatchVersionDecoded.diagnosisStatus.statusEn)

    // 3. No patch available: Unknown game Title ID not in verified database
    val unknownGameDecoded = GameDecoderDatabase.resolveGameInput("0100DEAD0000BEEF", "1.0.0")
    assertFalse(unknownGameDecoded.hasExactBuildIdPatchMatch)
    assertEquals("No patch available", unknownGameDecoded.diagnosisStatus.statusEn)
    assertTrue(unknownGameDecoded.versionFiles.isEmpty())

    // 4. Written but not verified enum label check
    assertEquals("Written but not verified", com.example.data.GamePatchDiagnosisStatus.WRITTEN_NOT_VERIFIED.statusEn)
  }

  @Test
  fun `smartTuningProfiles configure verified resolution_setup and scaling_filter while keeping global speed_limit 100`() {
    val batteryConfig = EmulatorHardwareConfig.fromProfile(com.example.data.SmartTuningProfile.BATTERY_SAVER)
    val batteryIni = GameDecoderDatabase.buildOrMergeEdenConfigIni("", batteryConfig, false)
    assertTrue(batteryIni.contains("resolution_setup=0")) // 0.5x
    assertTrue(batteryIni.contains("scaling_filter=5")) // AMD FSR
    assertTrue(batteryIni.contains("cpu_backend=1")) // NCE
    assertTrue(batteryIni.contains("speed_limit=100")) // capped for battery saving

    val balancedConfig = EmulatorHardwareConfig.fromProfile(com.example.data.SmartTuningProfile.BALANCED)
    val balancedIni = GameDecoderDatabase.buildOrMergeEdenConfigIni("", balancedConfig, false)
    assertTrue(balancedIni.contains("resolution_setup=1")) // 0.75x lowered for GPU relief
    assertTrue(balancedIni.contains("scaling_filter=5")) // AMD FSR

    val perfConfig = EmulatorHardwareConfig.fromProfile(com.example.data.SmartTuningProfile.PERFORMANCE)
    val perfGlobalIni = GameDecoderDatabase.buildOrMergeEdenConfigIni("", perfConfig, isPerGameCustomIni = false)
    assertTrue(perfGlobalIni.contains("resolution_setup=1")) // 0.75x with FSR for stable 60 FPS
    assertTrue(perfGlobalIni.contains("speed_limit=100")) // Global stays 100
    assertTrue(perfGlobalIni.contains("frame_limit=100"))

    val perfPerGameIni = GameDecoderDatabase.buildOrMergeEdenConfigIni("", perfConfig, isPerGameCustomIni = true)
    assertTrue(perfPerGameIni.contains("speed_limit=200")) // Per-game gets 200
    assertTrue(perfPerGameIni.contains("frame_limit=120") || perfPerGameIni.contains("frame_limit=200"))

    val qualityConfig = EmulatorHardwareConfig.fromProfile(com.example.data.SmartTuningProfile.QUALITY)
    val qualityIni = GameDecoderDatabase.buildOrMergeEdenConfigIni("", qualityConfig, false)
    assertTrue(qualityIni.contains("resolution_setup=2")) // 1.0x native
  }

  @Test
  fun `deviceThermalStatus provides honest recommendations without false claims`() {
    val normalStatus = com.example.thermal.DeviceThermalStatus(
      statusLevel = android.os.PowerManager.THERMAL_STATUS_NONE,
      thermalHeadroom = 0.5f,
      isHot = false,
      isSevere = false,
      recommendationEn = "Operating within safe thermal limits. Performance or Balanced profile is suitable.",
    )
    assertFalse(normalStatus.isHot)
    assertFalse(normalStatus.isSevere)
    assertTrue(normalStatus.recommendationEn.contains("Performance or Balanced"))

    val severeStatus = com.example.thermal.DeviceThermalStatus(
      statusLevel = android.os.PowerManager.THERMAL_STATUS_SEVERE,
      thermalHeadroom = 1.3f,
      isHot = true,
      isSevere = true,
      recommendationEn = "High thermal level detected. Recommend switching to Battery Saver or Balanced profile to reduce GPU/CPU load.",
    )
    assertTrue(severeStatus.isHot)
    assertTrue(severeStatus.isSevere)
    assertTrue(severeStatus.recommendationEn.contains("Battery Saver"))
  }

  @Test
  fun `aiOptimizationEngine measures display frame pacing and builds multi-layer quality and 60fps plan without Shizuku`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val hwInfo = DevicePerformanceDetector.detectDeviceHardware(context)
    val thermal = com.example.thermal.DeviceThermalStatus()
    val decodedTotk = GameDecoderDatabase.resolveGameInput("0100F2C0115B6000", "1.2.1")

    val netState = com.example.network.NetworkConnectivityMonitor.readCurrentNetworkState(context)
    val directTelemetry = com.example.network.NetworkConnectivityMonitor.readDirectPhoneTelemetry(context)

    val metrics = kotlinx.coroutines.runBlocking {
      com.example.ai.AiOptimizationEngine.sampleRealDeviceFrameAndHardwareMetrics(
        context = context,
        networkState = netState,
        directTelemetry = directTelemetry,
      )
    }
    assertTrue(metrics.measuredDisplayFps >= 15.0)
    assertTrue(metrics.avgFrameIntervalMs > 0.0)
    assertTrue(metrics.onePercentLowFps >= 12.0)
    assertTrue(metrics.availableRamMb > 0L)
    assertTrue(metrics.networkRouteLabelEn.isNotBlank())

    val plan = com.example.ai.AiOptimizationEngine.buildDeterministicBaselinePlan(
      hardwareInfo = hwInfo,
      thermalStatus = thermal,
      decodedGame = decodedTotk,
      metrics = metrics,
    )
    assertTrue(plan.enableDynamic60FpsFramePacing)
    assertTrue(plan.enableAstcBc1VramCompression)
    assertTrue(plan.enableSnapdragonCoolGovernor)
    assertTrue(plan.aiFsrSharpnessPercent in 45..98)
    assertTrue(plan.optimizationPillars.size >= 3)
    assertTrue(plan.summaryHeadlineEn.contains("AI Mode"))
  }

  @Test
  fun `snapdragon 7 and 8 long session cool mode and mobile data auto failover work without Shizuku`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val hwInfo = DevicePerformanceDetector.detectDeviceHardware(context)
    assertTrue(hwInfo.isSnapdragon7Or8)
    assertTrue(hwInfo.snapdragonSeries.badgeEn.contains("Snapdragon"))

    // Verify Snapdragon 7 & 8 Long-Session Cool Mode config keys:
    // accelerate_astc=true, astc_recompression=1, max_anisotropy=0, force_max_clock=false
    val coolConfig = EmulatorHardwareConfig(
      force60FpsEngineSpeed = true,
      enableAmdFsrUpscaling = true,
      fsrSharpnessPercent = 86,
      forceMaxGpuClockAndAsyncShaders = true,
      enablePerformanceNceOptimization = true,
      snapdragonLongSessionCoolMode = true,
    )
    val coolIni = GameDecoderDatabase.buildOrMergeEdenConfigIni("", coolConfig, isPerGameCustomIni = true)
    assertTrue(coolIni.contains("accelerate_astc=true"))
    assertTrue(coolIni.contains("astc_recompression=1"))
    assertTrue(coolIni.contains("max_anisotropy=0"))
    assertTrue(coolIni.contains("force_max_clock=false"))
    assertTrue(coolIni.contains("cpu_backend=1"))
    assertTrue(coolIni.contains("use_asynchronous_shaders=true"))

    // Verify Smart Network & Hardware Telemetry Monitor (Phone Internet 4G/5G failover when Wi-Fi is off)
    val netState = com.example.network.NetworkConnectivityMonitor.readCurrentNetworkState(context)
    assertTrue(netState.badgeEn.isNotBlank())
    assertTrue(netState.statusDetailEn.isNotBlank())

    val directTelemetry = com.example.network.NetworkConnectivityMonitor.readDirectPhoneTelemetry(context)
    assertTrue(directTelemetry.totalRamMb >= 1024L)
    assertTrue(directTelemetry.displayRefreshRateHz >= 60)

    // Verify AiFrameEnhancerProcessor MappedByteBuffer & Local TFLite NPU/GPU Delegate
    val processor = com.example.ai.AiFrameEnhancerProcessor(context)
    val mappedBuf = processor.loadModelMappedByteBuffer(context)
    assertTrue(mappedBuf.capacity() >= 64)
    val npuStatus = processor.initialize(context)
    assertTrue(npuStatus.isEnabled)
    assertTrue(npuStatus.isInitialized)
    assertTrue(npuStatus.zeroCpuThermalStress)
    val enhanced = processor.enhanceFrameTensor(floatArrayOf(0.2f, 0.5f, 0.85f, 0.4f), sharpnessGain = 0.86f)
    assertEquals(4, enhanced.size)
    processor.close()

    // Verify ViewModel AI Optimization state and Long-Session Cool Mode toggle
    val repo = ModInjectorRepository(context)
    val vm = ModInjectorViewModel(repo, context)
    assertTrue(vm.uiState.value.snapdragonLongSessionCoolMode)
    assertTrue(vm.uiState.value.localNpuAiUpscalingEnabled)
    assertTrue(vm.uiState.value.latestFrameMetrics != null)

    vm.onToggleSnapdragonLongSessionCoolMode(false)
    assertFalse(vm.uiState.value.snapdragonLongSessionCoolMode)
    vm.onToggleSnapdragonLongSessionCoolMode(true)
    assertTrue(vm.uiState.value.snapdragonLongSessionCoolMode)
  }

  @Test
  fun `modForegroundService initializes local NPU TFLite with NnApiDelegate and ViewModel binds UI toggles`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    assertEquals("AI NPU Active & 60FPS Unlocked", ModForegroundService.NOTIFICATION_TITLE)

    val serviceController = org.robolectric.Robolectric.buildService(ModForegroundService::class.java)
    val service = serviceController.create().get()
    assertTrue(service.initializeLocalNpuTfliteEngine())
    assertTrue(ModForegroundService.governorState.value.mappedModelBytes >= 64)

    val heuristic = kotlinx.coroutines.runBlocking {
      service.runNpuThermalAndPerformanceHeuristics(
        fsrSharpnessHint = 85,
        force60Fps = true,
        enableNce = true,
        enableFsr = true,
      )
    }
    assertEquals(200, heuristic.recommendedSpeedLimit)
    assertEquals(1, heuristic.recommendedCpuBackend)
    assertEquals(5, heuristic.recommendedScalingFilter)
    assertTrue(heuristic.summaryEn.contains("AI NPU Active & 60FPS Unlocked"))
    assertTrue(heuristic.summaryEn.contains("speed_limit=200"))
    assertTrue(heuristic.summaryEn.contains("cpu_backend=1"))
    assertTrue(heuristic.summaryEn.contains("scaling_filter=5"))

    val repo = ModInjectorRepository(context)
    val vm = ModInjectorViewModel(repo, context)
    vm.onToggleBackgroundGovernorService(true)
    assertTrue(vm.uiState.value.isBackgroundGovernorActive)
    assertTrue(vm.uiState.value.force60FpsEngineSpeed)
    assertTrue(vm.uiState.value.enablePerformanceNce)
    assertTrue(vm.uiState.value.enableAmdFsrUpscaling)

    vm.onToggleBackgroundGovernorService(false)
    assertFalse(vm.uiState.value.isBackgroundGovernorActive)
    serviceController.destroy()
  }
}

