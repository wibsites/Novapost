package com.example

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.AiFrameEnhancerProcessor
import com.example.ai.AiOptimizationEngine
import com.example.ai.AiOptimizationPlan
import com.example.ai.AiOptimizationUiState
import com.example.ai.DirectFrameAndHardwareMetrics
import com.example.ai.LocalNpuUpscalerStatus
import com.example.data.ConfigDiffItem
import com.example.data.DecodedGameRelease
import com.example.data.DeviceHardwareInfo
import com.example.data.DevicePerformanceDetector
import com.example.data.EmulatorHardwareConfig
import com.example.data.EmulatorProfile
import com.example.data.EmulatorRegistry
import com.example.data.GameDecoderDatabase
import com.example.data.InstalledAppInfo
import com.example.data.InstalledGameItem
import com.example.data.ModInjectorRepository
import com.example.data.RealInjectionResult
import com.example.data.SelectedGameOrUpdateFileInfo
import com.example.data.SmartTuningProfile
import com.example.network.DirectPhoneTelemetry
import com.example.network.NetworkConnectionState
import com.example.network.NetworkConnectivityMonitor
import com.example.thermal.DeviceThermalStatus
import com.example.thermal.ThermalMonitor
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class PermissionsOnboardingState(
  val hasNotificationPermission: Boolean = false,
  val isBatteryOptimizationIgnored: Boolean = false,
  val hasUsageStatsPermission: Boolean = false,
  val hasSafAccess: Boolean = false,
  val isCompleted: Boolean = false,
  val isDismissed: Boolean = false,
) {
  val allGranted: Boolean
    get() = hasNotificationPermission && isBatteryOptimizationIgnored && hasSafAccess
  val hasBatteryOptimizationIgnored: Boolean
    get() = isBatteryOptimizationIgnored
}

data class ModInjectorUiState(
  val isArabic: Boolean = true,
  val isSmartProfileScreenOpen: Boolean = false,
  val isDiagnosisScreenOpen: Boolean = false,
  val lastOpenedApp: InstalledAppInfo? = null,
  val installedPhoneApps: List<InstalledAppInfo> = emptyList(),
  val emulatorProfiles: List<EmulatorProfile> = emptyList(),
  val selectedEmulator: EmulatorProfile = EmulatorRegistry.findProfileById("eden"),
  val hasUserPickedApp: Boolean = false,
  val grantedTreeUri: Uri? = null,
  val isVerifiedEmulatorRoot: Boolean = false,
  val selectedGameFileInfo: SelectedGameOrUpdateFileInfo? = null,
  val selectedUpdateFileInfo: SelectedGameOrUpdateFileInfo? = null,
  val discoveredUpdateFiles: List<SelectedGameOrUpdateFileInfo> = emptyList(),
  val deviceHardwareInfo: DeviceHardwareInfo = DevicePerformanceDetector.detectDeviceHardware(),
  val installedGames: List<InstalledGameItem> = emptyList(),
  val selectedGame: InstalledGameItem? = null,
  val gameNameInput: String = "",
  val gameVersionInput: String = "Auto",
  val githubUrlInput: String = ModInjectorRepository.DEFAULT_GITHUB_SOURCE_URL,
  val resolvedPreview: DecodedGameRelease =
    GameDecoderDatabase.resolveGameInput("0100F2C0115B6000", "Auto"),
  val selectedProfile: SmartTuningProfile = SmartTuningProfile.PERFORMANCE,
  val force60FpsEngineSpeed: Boolean = true,
  val enableAmdFsrUpscaling: Boolean = true,
  val fsrSharpnessPercent: Int = 90,
  val forceMaxGpuClock: Boolean = false,
  val enablePerformanceNce: Boolean = true,
  val snapdragonLongSessionCoolMode: Boolean = true,
  val localNpuAiUpscalingEnabled: Boolean = true,
  val localNpuStatus: LocalNpuUpscalerStatus = LocalNpuUpscalerStatus(isEnabled = true),
  val isBackgroundGovernorActive: Boolean = false,
  val governorState: ForegroundGovernorState = ForegroundGovernorState(),
  val networkState: NetworkConnectionState = NetworkConnectionState(),
  val directTelemetry: DirectPhoneTelemetry = DirectPhoneTelemetry(),
  val latestFrameMetrics: DirectFrameAndHardwareMetrics? = null,
  val aiOptimizationState: AiOptimizationUiState = AiOptimizationUiState.Idle,
  val isCloudSyncing: Boolean = false,
  val isRunning: Boolean = false,
  val statusMessage: String =
    "اختر المحاكي، اربط مجلد البيانات، وفعل Local NPU AI Upscaling لرفع الجودة و 60 FPS بدون حرارة",
  val lastInjectionResult: RealInjectionResult? = null,
  val lastPatchSource: String = "Multi-Source Database",
  val thermalStatus: DeviceThermalStatus = DeviceThermalStatus(),
  val autoAdaptThermalProfile: Boolean = true,
  val isDiffDialogVisible: Boolean = false,
  val previewDiffList: List<ConfigDiffItem> = emptyList(),
  val isCustomPatchDialogOpen: Boolean = false,
  val customPatchTextInput: String = "",
  val customPatchBuildIdInput: String = "",
  val onboardingState: PermissionsOnboardingState = PermissionsOnboardingState(),
  val showOnboardingDialog: Boolean = false,
  val logs: List<String> = listOf(
    "Hardware Info: ${DevicePerformanceDetector.detectDeviceHardware().chipName} (${DevicePerformanceDetector.detectDeviceHardware().snapdragonSeries.badgeEn}) detected.",
    "Local NPU AI Upscaling: TensorFlow Lite MappedByteBuffer + Hexagon NPU / Adreno GPU Delegate ready.",
    "Snapdragon 7 & 8 Long-Session Cool Mode active: NCE + Adreno ASTC + BC1/BC3 Recompression.",
  ),
)

class ModInjectorViewModel(
  private val repository: ModInjectorRepository,
  private val appContext: Context? = null,
) : ViewModel() {

  private val aiFrameEnhancerProcessor = AiFrameEnhancerProcessor(appContext)
  private val _uiState = MutableStateFlow(ModInjectorUiState())
  val uiState: StateFlow<ModInjectorUiState> = _uiState.asStateFlow()

  init {
    val hwInfo = DevicePerformanceDetector.detectDeviceHardware(appContext)
    val preselectedProfile = hwInfo.recommendedProfile
    val preselectedConfig = EmulatorHardwareConfig.fromProfile(preselectedProfile)
    val initialNetworkState = NetworkConnectivityMonitor.readCurrentNetworkState(appContext)
    val initialDirectTelemetry = NetworkConnectivityMonitor.readDirectPhoneTelemetry(appContext)

    val phoneApps = if (appContext != null) {
      val emus = EmulatorRegistry.queryInstalledAppsForChooser(appContext)
      val allApps = EmulatorRegistry.queryAllLaunchablePhoneApps(appContext)
      (emus + allApps).distinctBy { it.packageName }
    } else {
      emptyList()
    }
    val profiles = if (appContext != null) {
      EmulatorRegistry.getAllEmulatorsWithInstallStatus(appContext)
    } else {
      listOf(EmulatorRegistry.findProfileById("eden"))
    }
    val detectedLastOpened = if (appContext != null) {
      EmulatorRegistry.detectLastOpenedApp(appContext)
    } else {
      null
    }
    val autoDetectedApp = detectedLastOpened ?: phoneApps.firstOrNull { it.isLikelyEmulatorOrGame }
    val defaultEmulator = if (autoDetectedApp != null) {
      EmulatorRegistry.createProfileFromInstalledApp(
        packageName = autoDetectedApp.packageName,
        appLabel = autoDetectedApp.appLabel,
        overrideArchitecture = autoDetectedApp.detectedArchitecture,
      )
    } else {
      profiles.first()
    }

    val initialNpuStatus = aiFrameEnhancerProcessor.initialize(appContext)

    val initialBaselinePlan = AiOptimizationEngine.buildDeterministicBaselinePlan(
      hardwareInfo = hwInfo,
      thermalStatus = DeviceThermalStatus(),
      decodedGame = GameDecoderDatabase.resolveGameInput("0100F2C0115B6000", "Auto"),
      metrics = DirectFrameAndHardwareMetrics(
        measuredDisplayFps = initialDirectTelemetry.displayRefreshHz.toDouble(),
        avgFrameIntervalMs = initialDirectTelemetry.targetFrameTimeMs,
        frameJitterMs = 0.35,
        onePercentLowFps = (initialDirectTelemetry.displayRefreshHz - 1).toDouble(),
        batteryTempCelsius = initialDirectTelemetry.batteryTempCelsius,
        batteryCurrentMa = initialDirectTelemetry.batteryCurrentMa,
        availableRamMb = initialDirectTelemetry.availableRamMb,
        totalRamMb = initialDirectTelemetry.totalRamMb,
        networkRouteLabelEn = initialNpuStatus.activeAccelerator.labelEn,
        networkRouteLabelAr = initialNpuStatus.activeAccelerator.labelAr,
        usedMobileDataFallback = !initialNetworkState.isWifiOrLan && initialNetworkState.isMobileData,
      ),
      npuStatus = initialNpuStatus,
    )

    _uiState.update { state ->
      state.copy(
        deviceHardwareInfo = hwInfo,
        selectedProfile = preselectedProfile,
        force60FpsEngineSpeed = preselectedConfig.force60FpsEngineSpeed,
        enableAmdFsrUpscaling = preselectedConfig.enableAmdFsrUpscaling,
        fsrSharpnessPercent = preselectedConfig.fsrSharpnessPercent,
        forceMaxGpuClock = false,
        enablePerformanceNce = preselectedConfig.enablePerformanceNceOptimization,
        snapdragonLongSessionCoolMode = true,
        localNpuAiUpscalingEnabled = true,
        localNpuStatus = initialNpuStatus,
        networkState = initialNetworkState,
        directTelemetry = initialDirectTelemetry,
        latestFrameMetrics = initialBaselinePlan.measuredMetrics,
        lastOpenedApp = detectedLastOpened,
        installedPhoneApps = phoneApps,
        emulatorProfiles = profiles,
        selectedEmulator = defaultEmulator,
        hasUserPickedApp = false,
        logs = listOf(
          "Snapdragon Engine: ${hwInfo.socBrand} (${hwInfo.chipName}) • ${hwInfo.snapdragonSeries.badgeEn} • ${hwInfo.totalRamGb}GB RAM • ${hwInfo.refreshRateHz}Hz",
          "Local TFLite NPU Upscaler: ${initialNpuStatus.statusHeadlineEn} (MappedByteBuffer=${initialNpuStatus.mappedBufferCapacityBytes}B)",
          "Long-Session Cool Mode: Active (NCE + Adreno ASTC + BC1/BC3 VRAM Relief + Governor Cool Clock)",
        ),
      )
    }

    refreshLiveDiffPreview()

    if (appContext != null) {
      viewModelScope.launch {
        NetworkConnectivityMonitor.observeNetworkState(appContext).collect { netState ->
          val telemetry = NetworkConnectivityMonitor.readDirectPhoneTelemetry(appContext)
          _uiState.update { st ->
            st.copy(
              networkState = netState,
              directTelemetry = telemetry,
            )
          }
        }
      }

      viewModelScope.launch {
        ThermalMonitor.observeThermalStatus(appContext).collect { status ->
          val cur = _uiState.value
          val telemetry = NetworkConnectivityMonitor.readDirectPhoneTelemetry(appContext)
          var autoChangedProfile: SmartTuningProfile? = null
          if (cur.autoAdaptThermalProfile && (status.isHot || telemetry.batteryTempCelsius >= 40.0f)) {
            if (cur.selectedProfile == SmartTuningProfile.PERFORMANCE || cur.selectedProfile == SmartTuningProfile.QUALITY) {
              autoChangedProfile = if (status.isSevere || telemetry.batteryTempCelsius >= 42.5f) {
                SmartTuningProfile.BATTERY_SAVER
              } else {
                SmartTuningProfile.BALANCED
              }
            }
          }
          _uiState.update { st ->
            val updatedConfig = if (autoChangedProfile != null) {
              EmulatorHardwareConfig.fromProfile(autoChangedProfile)
            } else null

            st.copy(
              thermalStatus = status,
              directTelemetry = telemetry,
              selectedProfile = autoChangedProfile ?: st.selectedProfile,
              force60FpsEngineSpeed = updatedConfig?.force60FpsEngineSpeed ?: st.force60FpsEngineSpeed,
              enableAmdFsrUpscaling = updatedConfig?.enableAmdFsrUpscaling ?: st.enableAmdFsrUpscaling,
              fsrSharpnessPercent = updatedConfig?.fsrSharpnessPercent ?: st.fsrSharpnessPercent,
              forceMaxGpuClock = if (st.snapdragonLongSessionCoolMode) false else (updatedConfig?.forceMaxGpuClockAndAsyncShaders ?: st.forceMaxGpuClock),
              enablePerformanceNce = updatedConfig?.enablePerformanceNceOptimization ?: st.enablePerformanceNce,
              logs = if (autoChangedProfile != null) {
                (st.logs + "Snapdragon Cool Guard: Switched to ${autoChangedProfile.labelEn} profile to keep phone cool during long play.").takeLast(40)
              } else st.logs
            )
          }
          if (autoChangedProfile != null) {
            refreshLiveDiffPreview()
          }
        }
      }

      viewModelScope.launch {
        ModForegroundService.governorState.collect { govState ->
          _uiState.update { st ->
            st.copy(
              isBackgroundGovernorActive = govState.isRunning,
              governorState = govState,
            )
          }
        }
      }
    }

    viewModelScope.launch {
      val persisted = repository.getPersistedTreeUri(defaultEmulator)
      if (persisted != null) {
        val isVerifiedRoot = repository.checkIsTrueEmulatorAppFolder(persisted, defaultEmulator)
        val games = repository.scanInstalledGamesDetailed(persisted, defaultEmulator)
        val firstGame = games.firstOrNull()
        _uiState.update { state ->
          state.copy(
            grantedTreeUri = persisted,
            isVerifiedEmulatorRoot = isVerifiedRoot,
            installedGames = games,
            selectedGame = firstGame,
            gameNameInput = firstGame?.titleId ?: "",
            gameVersionInput = firstGame?.detectedVersion ?: "Auto",
            resolvedPreview = GameDecoderDatabase.resolveGameInput(
              firstGame?.titleId ?: "0100F2C0115B6000",
              firstGame?.detectedVersion ?: "Auto",
            ),
            statusMessage = if (state.isArabic) {
              "تم العثور على ${games.size} لعبة حقيقية — شغّل Local NPU AI Upscaling أو فعّل 60 FPS!"
            } else {
              "Found ${games.size} real game(s) — run Local NPU AI Upscaling or unlock 60 FPS!"
            },
          )
        }
        refreshLiveDiffPreview()
      }
      if (appContext != null) {
        checkAndUpdatePermissions(appContext)
      }
    }
  }

  fun checkAndUpdatePermissions(context: Context) {
    val hasNotif = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.POST_NOTIFICATIONS,
      ) == PackageManager.PERMISSION_GRANTED
    } else {
      true
    }

    val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
    val isBatteryIgnored = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
      powerManager?.isIgnoringBatteryOptimizations(context.packageName) == true
    } else {
      true
    }

    val hasUsageStats = EmulatorRegistry.hasUsageStatsPermission(context)
    val latestOpened = EmulatorRegistry.detectLastOpenedApp(context)
    val hasSaf = _uiState.value.grantedTreeUri != null

    val isAllGranted = hasNotif && isBatteryIgnored && hasSaf

    _uiState.update { st ->
      val updatedOnboarding = st.onboardingState.copy(
        hasNotificationPermission = hasNotif,
        isBatteryOptimizationIgnored = isBatteryIgnored,
        hasUsageStatsPermission = hasUsageStats,
        hasSafAccess = hasSaf,
        isCompleted = isAllGranted,
      )
      val nextSelectedEmulator = if (!st.hasUserPickedApp && latestOpened != null) {
        EmulatorRegistry.createProfileFromInstalledApp(
          packageName = latestOpened.packageName,
          appLabel = latestOpened.appLabel,
          overrideArchitecture = latestOpened.detectedArchitecture,
        )
      } else {
        st.selectedEmulator
      }
      st.copy(
        lastOpenedApp = latestOpened ?: st.lastOpenedApp,
        selectedEmulator = nextSelectedEmulator,
        onboardingState = updatedOnboarding,
        showOnboardingDialog = if (updatedOnboarding.isDismissed) false else (!isAllGranted || st.showOnboardingDialog),
      )
    }
  }

  fun onCompleteOnboarding() {
    _uiState.update { st ->
      st.copy(
        showOnboardingDialog = false,
        onboardingState = st.onboardingState.copy(isDismissed = true, isCompleted = true),
      )
    }
  }

  fun onDismissOnboarding() {
    _uiState.update { st ->
      st.copy(
        showOnboardingDialog = false,
        onboardingState = st.onboardingState.copy(isDismissed = true),
      )
    }
  }

  fun onReopenOnboarding() {
    _uiState.update { it.copy(showOnboardingDialog = true) }
  }

  private fun buildCurrentHardwareConfig(state: ModInjectorUiState = _uiState.value): EmulatorHardwareConfig {
    return EmulatorHardwareConfig(
      profile = state.selectedProfile,
      force60FpsEngineSpeed = state.force60FpsEngineSpeed,
      enableAmdFsrUpscaling = state.enableAmdFsrUpscaling || state.localNpuAiUpscalingEnabled,
      fsrSharpnessPercent = 90,
      forceMaxGpuClockAndAsyncShaders = false,
      enablePerformanceNceOptimization = state.enablePerformanceNce,
      resolutionScale = "0.5x + SGSR / FSR",
      snapdragonLongSessionCoolMode = true,
      ultimateThermalBypass = true,
      useSnapdragonSgsr = true,
      frameLimit = 120,
    )
  }

  private fun dispatchGovernorServiceStart(state: ModInjectorUiState = _uiState.value) {
    val ctx = appContext ?: return
    val targetInput = state.selectedUpdateFileInfo?.detectedBaseTitleId
      ?: state.selectedGameFileInfo?.detectedBaseTitleId
      ?: state.selectedGame?.titleId
      ?: state.gameNameInput.ifBlank { "0100F2C0115B6000" }
    val customBid = state.selectedUpdateFileInfo?.extractedBuildId
      ?: state.selectedGameFileInfo?.extractedBuildId
    val customPchtxt = state.selectedUpdateFileInfo?.embeddedPchtxtContent
      ?: state.selectedGameFileInfo?.embeddedPchtxtContent

    ModForegroundService.startGovernorService(
      context = ctx,
      treeUri = state.grantedTreeUri,
      gameInput = targetInput,
      gameVersion = state.gameVersionInput,
      emulatorId = state.selectedEmulator.id,
      fsrSharpness = state.fsrSharpnessPercent,
      force60Fps = state.force60FpsEngineSpeed,
      enableNce = state.enablePerformanceNce,
      enableFsr = state.enableAmdFsrUpscaling || state.localNpuAiUpscalingEnabled,
      customBuildId = customBid,
      customPchtxt = customPchtxt,
    )
  }

  /**
   * Starts or stops the persistent background AI governor service (`ModForegroundService`)
   * with continuous notification ('AI NPU Active & 60FPS Unlocked').
   */
  fun onToggleBackgroundGovernorService(enabled: Boolean) {
    val state = _uiState.value
    if (enabled) {
      val updatedState = state.copy(
        isBackgroundGovernorActive = true,
        localNpuAiUpscalingEnabled = true,
        force60FpsEngineSpeed = true,
        enablePerformanceNce = true,
        enableAmdFsrUpscaling = true,
      )
      _uiState.update {
        updatedState.copy(
          statusMessage = if (it.isArabic) {
            "🛡️ تم تشغيل حارس الذكاء الاصطناعي في الخلفية (AI NPU Active & 60FPS Unlocked) مع حقن speed_limit=200 و NCE و FSR."
          } else {
            "🛡️ Persistent Background AI Governor active ('AI NPU Active & 60FPS Unlocked') with speed_limit=200, NCE=1, FSR=5."
          },
          logs = (
            it.logs +
              "ModForegroundService started: 'AI NPU Active & 60FPS Unlocked' [speed_limit=200, cpu_backend=1, scaling_filter=5]"
            ).takeLast(50),
        )
      }
      dispatchGovernorServiceStart(updatedState)
    } else {
      appContext?.let { ModForegroundService.stopGovernorService(it) }
      _uiState.update {
        it.copy(
          isBackgroundGovernorActive = false,
          statusMessage = if (it.isArabic) {
            "تم إيقاف خدمة حارس الذكاء الاصطناعي في الخلفية."
          } else {
            "Persistent Background AI Governor service stopped."
          },
          logs = (it.logs + "ModForegroundService stopped.").takeLast(50),
        )
      }
    }
    refreshLiveDiffPreview()
  }

  /**
   * Toggles the Local On-Device TensorFlow Lite NPU/GPU AI Upscaler (`AiFrameEnhancerProcessor`)
   * and binds directly to `ModForegroundService` to start/stop persistent background NPU governance.
   */
  fun onToggleLocalNpuAiUpscaling(enabled: Boolean) {
    viewModelScope.launch {
      val status = withContext(Dispatchers.Default) {
        if (enabled) {
          val initialized = aiFrameEnhancerProcessor.initialize(appContext)
          aiFrameEnhancerProcessor.enhanceFrameTensor(
            floatArrayOf(0.2f, 0.5f, 0.85f, 0.5f),
            sharpnessGain = (_uiState.value.fsrSharpnessPercent / 100f),
          )
          initialized
        } else {
          aiFrameEnhancerProcessor.close()
          aiFrameEnhancerProcessor.currentStatus(isEnabled = false)
        }
      }

      _uiState.update { state ->
        state.copy(
          localNpuAiUpscalingEnabled = enabled,
          isBackgroundGovernorActive = enabled,
          localNpuStatus = status,
          enableAmdFsrUpscaling = if (enabled) true else state.enableAmdFsrUpscaling,
          statusMessage = if (state.isArabic) {
            if (enabled) {
              "⚡ تم تفعيل Local NPU AI Upscaling وتشغيل الخدمة الدائمة (AI NPU Active & 60FPS Unlocked) بدون ضغط على الـ CPU."
            } else {
              "تم إيقاف Local NPU AI Upscaling وإيقاف خدمة الخلفية."
            }
          } else {
            if (enabled) {
              "⚡ Local NPU AI Upscaling & Foreground Governor ('AI NPU Active & 60FPS Unlocked') started on ${status.activeAccelerator.labelEn}."
            } else {
              "Local NPU AI Upscaling & Foreground Governor stopped."
            }
          },
          logs = (
            state.logs +
              "Local NPU AI Upscaling = $enabled [Delegate=${status.activeAccelerator.labelEn}, MappedByteBuffer=${status.mappedBufferCapacityBytes}B, ForegroundService=$enabled]"
            ).takeLast(50),
        )
      }
      if (enabled) {
        dispatchGovernorServiceStart(_uiState.value)
      } else {
        appContext?.let { ModForegroundService.stopGovernorService(it) }
      }
      refreshLiveDiffPreview()
    }
  }

  fun refreshLiveDiffPreview() {
    viewModelScope.launch {
      val state = _uiState.value
      val hwConfig = buildCurrentHardwareConfig(state)
      val diffs = repository.generateConfigDiffPreview(
        treeUri = state.grantedTreeUri,
        profile = state.selectedEmulator,
        hwConfig = hwConfig,
      )
      _uiState.update { it.copy(previewDiffList = diffs) }
    }
  }

  fun onOpenSmartProfileScreen() {
    refreshLiveDiffPreview()
    _uiState.update { it.copy(isSmartProfileScreenOpen = true, isDiagnosisScreenOpen = false) }
  }

  fun onCloseSmartProfileScreen() {
    _uiState.update { it.copy(isSmartProfileScreenOpen = false, isDiagnosisScreenOpen = false) }
  }

  fun onOpenDiagnosisScreen() {
    _uiState.update { it.copy(isDiagnosisScreenOpen = true, isSmartProfileScreenOpen = false) }
  }

  fun onCloseDiagnosisScreen() {
    _uiState.update { it.copy(isDiagnosisScreenOpen = false) }
  }

  fun refreshInstalledPhoneApps(context: Context) {
    viewModelScope.launch(Dispatchers.Default) {
      val emus = EmulatorRegistry.queryInstalledAppsForChooser(context)
      val allApps = EmulatorRegistry.queryAllLaunchablePhoneApps(context)
      val apps = (emus + allApps).distinctBy { it.packageName }
      val profiles = EmulatorRegistry.getAllEmulatorsWithInstallStatus(context)
      val latestOpened = EmulatorRegistry.detectLastOpenedApp(context)
      val hasUsageStats = EmulatorRegistry.hasUsageStatsPermission(context)
      _uiState.update { st ->
        val nextEmulator = if (!st.hasUserPickedApp && latestOpened != null) {
          EmulatorRegistry.createProfileFromInstalledApp(
            packageName = latestOpened.packageName,
            appLabel = latestOpened.appLabel,
            overrideArchitecture = latestOpened.detectedArchitecture,
          )
        } else {
          st.selectedEmulator
        }
        st.copy(
          lastOpenedApp = latestOpened ?: st.lastOpenedApp,
          installedPhoneApps = apps,
          emulatorProfiles = profiles,
          selectedEmulator = nextEmulator,
          onboardingState = st.onboardingState.copy(hasUsageStatsPermission = hasUsageStats),
        )
      }
    }
  }

  fun onPickInstalledPhoneApp(appInfo: InstalledAppInfo) {
    val profile = EmulatorRegistry.createProfileFromInstalledApp(
      packageName = appInfo.packageName,
      appLabel = appInfo.appLabel,
      overrideArchitecture = appInfo.detectedArchitecture,
    )
    onSelectEmulatorProfile(profile)
  }

  fun onSelectEmulatorProfile(profile: EmulatorProfile) {
    _uiState.update { state ->
      state.copy(
        selectedEmulator = profile,
        hasUserPickedApp = true,
        selectedGame = null,
        statusMessage = if (state.isArabic) {
          "تم اختيار المحاكي: ${profile.nameAr} (${profile.packageName}) ✓"
        } else {
          "Selected Emulator: ${profile.nameEn} (${profile.packageName}) ✓"
        },
        logs = (state.logs + "Selected Emulator -> ${profile.nameEn} [${profile.packageName}] (${profile.architecture})").takeLast(40),
      )
    }

    viewModelScope.launch {
      val persisted = repository.getPersistedTreeUri(profile)
      val isVerifiedRoot = if (persisted != null) {
        repository.checkIsTrueEmulatorAppFolder(persisted, profile)
      } else {
        false
      }
      val games = if (persisted != null) {
        repository.scanInstalledGamesDetailed(persisted, profile)
      } else {
        emptyList()
      }
      val firstGame = games.firstOrNull()
      _uiState.update { state ->
        if (state.selectedEmulator.id != profile.id) state
        else if (firstGame != null) {
          state.copy(
            grantedTreeUri = persisted,
            isVerifiedEmulatorRoot = isVerifiedRoot,
            installedGames = games,
            selectedGame = firstGame,
            gameNameInput = firstGame.nameEn,
            gameVersionInput = firstGame.detectedVersion,
            resolvedPreview = GameDecoderDatabase.resolveGameInput(firstGame.titleId, firstGame.detectedVersion),
          )
        } else {
          state.copy(
            grantedTreeUri = persisted,
            isVerifiedEmulatorRoot = isVerifiedRoot,
            installedGames = emptyList(),
            selectedGame = null,
          )
        }
      }
      refreshLiveDiffPreview()
    }
  }

  fun toggleLanguage() {
    _uiState.update { state ->
      val nextAr = !state.isArabic
      state.copy(
        isArabic = nextAr,
        statusMessage = if (nextAr) {
          "المحاكي المحدد: ${state.selectedEmulator.nameAr} — شغّل Local NPU AI Upscaling لتحسين الجودة والفريمات"
        } else {
          "Selected Emulator: ${state.selectedEmulator.nameEn} — Run Local NPU AI Upscaling for Quality + 60 FPS"
        },
      )
    }
  }

  fun onSelectInstalledGame(game: InstalledGameItem) {
    val ver = if (game.detectedVersion != "Auto-Detect") game.detectedVersion else "Auto"
    val customBid = _uiState.value.selectedUpdateFileInfo?.extractedBuildId
    val resolved = GameDecoderDatabase.resolveGameInput(game.titleId, ver, customBid)
    _uiState.update { state ->
      state.copy(
        selectedGame = game,
        gameNameInput = game.nameEn,
        gameVersionInput = state.selectedUpdateFileInfo?.detectedVersion ?: ver,
        resolvedPreview = resolved,
        statusMessage = if (state.isArabic) {
          "تم اختيار اللعبة: ${game.nameAr} (${game.titleId})"
        } else {
          "Selected game: ${game.nameEn} (${game.titleId})"
        },
        logs = (state.logs + "Selected Game: ${game.nameEn} [${game.titleId}]").takeLast(40),
      )
    }
  }

  fun onGameFilePicked(fileUri: Uri?) {
    if (fileUri == null) return
    viewModelScope.launch {
      val info = repository.inspectSelectedGameOrUpdateFile(fileUri, isUpdateFile = false)
      val state = _uiState.value
      val effectiveGameId = info.detectedBaseTitleId ?: info.fileName.substringBeforeLast(".")
      val effectiveVersion = state.selectedUpdateFileInfo?.detectedVersion
        ?: info.detectedVersion
        ?: state.gameVersionInput
      val customBid = state.selectedUpdateFileInfo?.extractedBuildId ?: info.extractedBuildId
      val resolved = GameDecoderDatabase.resolveGameInput(effectiveGameId, effectiveVersion, customBid)

      val newItem = InstalledGameItem(
        titleId = resolved.primaryTitleId,
        nameEn = resolved.titleNameEn,
        nameAr = resolved.titleNameAr,
        detectedVersion = effectiveVersion,
        has60FpsPatch = false,
        hasPerformanceConfig = false,
        folderSource = info.fileName,
        detectedBuildId = customBid ?: resolved.detectedBuildId,
        hasExactPatchForBuildId = resolved.hasExactBuildIdPatchMatch,
        diagnosisStatus = resolved.diagnosisStatus,
        diagnosisReasonEn = resolved.diagnosisReasonEn,
        diagnosisReasonAr = resolved.diagnosisReasonAr,
      )

      _uiState.update { cur ->
        val updatedList = (listOf(newItem) + cur.installedGames.filterNot { it.titleId == newItem.titleId })
        cur.copy(
          selectedGameFileInfo = info,
          installedGames = updatedList,
          selectedGame = newItem,
          gameNameInput = resolved.primaryTitleId,
          gameVersionInput = effectiveVersion,
          resolvedPreview = resolved,
          statusMessage = if (cur.isArabic) {
            "تم فحص ملف اللعبة: ${info.fileName} (${resolved.primaryTitleId}) — الحالة: ${resolved.diagnosisStatus.statusAr}"
          } else {
            "Inspected Game File: ${info.fileName} (${resolved.primaryTitleId}) — Status: ${resolved.diagnosisStatus.statusEn}"
          },
          logs = (cur.logs + "Game File Loaded: ${info.fileName} -> TitleID=${resolved.primaryTitleId}, Status=${resolved.diagnosisStatus.statusEn}").takeLast(40),
        )
      }
    }
  }

  fun onUpdateFilePicked(fileUri: Uri?) {
    if (fileUri == null) return
    viewModelScope.launch {
      val info = repository.inspectSelectedGameOrUpdateFile(fileUri, isUpdateFile = true)
      applySelectedUpdateInfo(info)
    }
  }

  fun onSelectDiscoveredUpdate(info: SelectedGameOrUpdateFileInfo) {
    applySelectedUpdateInfo(info)
  }

  private fun applySelectedUpdateInfo(info: SelectedGameOrUpdateFileInfo) {
    val state = _uiState.value
    val targetGameInput = info.detectedBaseTitleId
      ?: state.selectedGame?.titleId
      ?: state.selectedGameFileInfo?.detectedBaseTitleId
      ?: state.gameNameInput.ifBlank { "01007EF00011E000" }
    val targetVer = info.detectedVersion ?: "Update"
    val customBid = info.extractedBuildId
    val resolved = GameDecoderDatabase.resolveGameInput(targetGameInput, targetVer, customBid)

    val isCustomPchtxt = !info.embeddedPchtxtContent.isNullOrBlank() && info.embeddedPchtxtContent.contains("@nsobid-")
    val diagnosisStatus = if (isCustomPchtxt) {
      com.example.data.GamePatchDiagnosisStatus.MATCHED
    } else {
      resolved.diagnosisStatus
    }
    val reasonEn = if (isCustomPchtxt) {
      "Verified custom/manual 60 FPS patch provided (${info.fileName}) matching Build ID ${customBid?.take(16) ?: "Direct"}."
    } else {
      resolved.diagnosisReasonEn
    }
    val reasonAr = if (isCustomPchtxt) {
      "تم توفير والتحقق من باتش 60 FPS يدوي (${info.fileName}) مطابق لمعرّف البناء ${customBid?.take(16) ?: "مباشر"}."
    } else {
      resolved.diagnosisReasonAr
    }

    val updatedItem = InstalledGameItem(
      titleId = resolved.primaryTitleId,
      nameEn = resolved.titleNameEn,
      nameAr = resolved.titleNameAr,
      detectedVersion = targetVer,
      has60FpsPatch = state.selectedGame?.has60FpsPatch ?: false,
      hasPerformanceConfig = state.selectedGame?.hasPerformanceConfig ?: false,
      folderSource = info.fileName,
      detectedBuildId = customBid ?: resolved.detectedBuildId,
      hasExactPatchForBuildId = resolved.hasExactBuildIdPatchMatch || isCustomPchtxt,
      diagnosisStatus = diagnosisStatus,
      diagnosisReasonEn = reasonEn,
      diagnosisReasonAr = reasonAr,
    )

    _uiState.update { cur ->
      val updatedGames = (listOf(updatedItem) + cur.installedGames.filterNot { it.titleId == updatedItem.titleId })
      cur.copy(
        selectedUpdateFileInfo = info,
        installedGames = updatedGames,
        selectedGame = updatedItem,
        gameNameInput = resolved.primaryTitleId,
        gameVersionInput = targetVer,
        resolvedPreview = resolved,
        statusMessage = if (cur.isArabic) {
          "تم فحص التحديث: ${info.fileName} ($targetVer) — الحالة: ${updatedItem.diagnosisStatus.statusAr}"
        } else {
          "Update Inspected: ${info.fileName} ($targetVer) — Status: ${updatedItem.diagnosisStatus.statusEn}"
        },
        logs = (
          cur.logs +
            "Update File Linked: ${info.fileName} -> BaseTitleID=${resolved.primaryTitleId}, Ver=$targetVer, BuildID=${customBid ?: "Not in header"}, Status=${updatedItem.diagnosisStatus.statusEn}"
          ).takeLast(40),
      )
    }
  }

  fun onOpenCustomPatchDialog(forGame: InstalledGameItem? = null) {
    val target = forGame ?: _uiState.value.selectedGame
    val existingBid = target?.detectedBuildId?.takeIf { b ->
      !b.contains("Unknown", ignoreCase = true) && !b.contains("Not in", ignoreCase = true)
    } ?: ""
    _uiState.update {
      it.copy(
        isCustomPatchDialogOpen = true,
        customPatchBuildIdInput = existingBid.ifBlank { it.customPatchBuildIdInput },
      )
    }
  }

  fun onCloseCustomPatchDialog() {
    _uiState.update { it.copy(isCustomPatchDialogOpen = false) }
  }

  fun onCustomPatchTextChanged(text: String) {
    _uiState.update { it.copy(customPatchTextInput = text) }
  }

  fun onCustomPatchBuildIdChanged(bid: String) {
    _uiState.update { it.copy(customPatchBuildIdInput = bid) }
  }

  fun applyCustomPastedPatch(
    rawPatchText: String,
    overrideBuildId: String?,
  ) {
    if (rawPatchText.isBlank()) return
    val state = _uiState.value
    val targetTitleId = state.selectedGame?.titleId
      ?: state.selectedGameFileInfo?.detectedBaseTitleId
      ?: state.gameNameInput.ifBlank { "01007EF00011E000" }

    val formattedPchtxt = GameDecoderDatabase.buildCustomPchtxtFromRawCode(
      rawCode = rawPatchText,
      titleId = targetTitleId,
      fallbackBuildId = overrideBuildId?.trim()?.ifBlank { null }
        ?: state.selectedGame?.detectedBuildId?.takeIf { !it.contains("Unknown") && !it.contains("Not in") },
      gameTitle = state.selectedGame?.nameEn ?: "Custom Game",
    )

    val extractedBid = Regex("@nsobid-([0-9A-Fa-f]{16,64})", RegexOption.IGNORE_CASE)
      .find(formattedPchtxt)?.groupValues?.getOrNull(1)?.take(32)?.uppercase(Locale.US)

    val customFileInfo = SelectedGameOrUpdateFileInfo(
      uri = Uri.parse("custom://patch/${System.currentTimeMillis()}"),
      fileName = "custom_60fps_patch.pchtxt",
      isUpdateFile = true,
      detectedBaseTitleId = targetTitleId,
      rawTitleIdInFile = targetTitleId,
      detectedVersion = "Custom/Mod",
      extractedBuildId = extractedBid,
      embeddedPchtxtContent = formattedPchtxt,
    )

    applySelectedUpdateInfo(customFileInfo)
    _uiState.update {
      it.copy(
        isCustomPatchDialogOpen = false,
        statusMessage = if (it.isArabic) {
          "✅ تم ربط الباتش اليدوي بنجاح! يمكنك الآن الضغط على 'تفعيل 60 FPS وتطبيق الإعدادات'."
        } else {
          "✅ Custom 60FPS patch linked successfully! You can now tap 'Unlock 60 FPS & Apply Settings'."
        },
        logs = (it.logs + "Custom 60FPS Patch Linked: Target=$targetTitleId, BuildID=${extractedBid ?: "Auto"}").takeLast(40),
      )
    }
  }

  fun onGamesFolderPicked(uri: Uri?) {
    if (uri == null) return
    repository.persistTreePermission(uri)
    viewModelScope.launch {
      val state = _uiState.value
      val games = repository.scanInstalledGamesDetailed(uri, state.selectedEmulator)
      val updates = repository.scanUpdatesFolder(uri).filter {
        it.fileName.contains("update", ignoreCase = true) ||
          it.fileName.contains("upd", ignoreCase = true) ||
          it.rawTitleIdInFile?.endsWith("800") == true ||
          it.fileName.endsWith(".pchtxt", ignoreCase = true)
      }
      val firstGame = games.firstOrNull() ?: state.selectedGame
      val keepExistingAppRoot = state.grantedTreeUri != null && state.isVerifiedEmulatorRoot
      val nextTreeUri = if (keepExistingAppRoot) state.grantedTreeUri else uri
      val nextVerified = if (keepExistingAppRoot) true else repository.checkIsTrueEmulatorAppFolder(uri, state.selectedEmulator)

      _uiState.update { cur ->
        val mergedGames = (games + cur.installedGames).distinctBy { it.titleId }
        cur.copy(
          grantedTreeUri = nextTreeUri,
          isVerifiedEmulatorRoot = nextVerified,
          installedGames = mergedGames,
          selectedGame = firstGame,
          discoveredUpdateFiles = (updates + cur.discoveredUpdateFiles).distinctBy { it.fileName },
          gameNameInput = firstGame?.titleId ?: cur.gameNameInput,
          statusMessage = if (cur.isArabic) {
            "تم فحص مجلد الألعاب: تم العثور على ${games.size} لعبة و ${updates.size} ملف تحديث!"
          } else {
            "Scanned Games folder: found ${games.size} game(s) and ${updates.size} update(s)!"
          },
          logs = (cur.logs + "Games Folder Scanned: ${games.size} games, ${updates.size} updates.").takeLast(40),
        )
      }
      refreshLiveDiffPreview()
    }
  }

  fun onUpdatesFolderPicked(uri: Uri?) {
    if (uri == null) return
    repository.persistTreePermission(uri)
    viewModelScope.launch {
      val updates = repository.scanUpdatesFolder(uri)
      val firstMatching = updates.firstOrNull {
        it.detectedBaseTitleId != null && it.detectedBaseTitleId == _uiState.value.resolvedPreview.primaryTitleId
      } ?: updates.firstOrNull()

      _uiState.update { cur ->
        cur.copy(
          discoveredUpdateFiles = updates,
          statusMessage = if (cur.isArabic) {
            "تم فحص مجلد التحديثات: تم العثور على ${updates.size} ملف تحديث — اختر التحديث المطلوب مع اللعبة!"
          } else {
            "Scanned Updates folder: found ${updates.size} update file(s)!"
          },
          logs = (cur.logs + "Updates Folder Scanned: found ${updates.size} update files.").takeLast(40),
        )
      }
      if (firstMatching != null) {
        applySelectedUpdateInfo(firstMatching)
      }
    }
  }

  fun onGameNameChanged(input: String) {
    val customBid = _uiState.value.selectedUpdateFileInfo?.extractedBuildId
    val resolved = GameDecoderDatabase.resolveGameInput(input, _uiState.value.gameVersionInput, customBid)
    _uiState.update {
      it.copy(
        gameNameInput = input,
        resolvedPreview = resolved,
      )
    }
  }

  fun onGameVersionChanged(version: String) {
    val customBid = _uiState.value.selectedUpdateFileInfo?.extractedBuildId
    val resolved = GameDecoderDatabase.resolveGameInput(_uiState.value.gameNameInput, version, customBid)
    _uiState.update {
      it.copy(
        gameVersionInput = version,
        resolvedPreview = resolved,
      )
    }
  }

  fun onTogglePerformanceNce(enabled: Boolean) {
    _uiState.update { it.copy(enablePerformanceNce = enabled) }
    if (_uiState.value.isBackgroundGovernorActive) {
      dispatchGovernorServiceStart(_uiState.value)
    }
    refreshLiveDiffPreview()
  }

  fun onToggleForce60Engine(enabled: Boolean) {
    _uiState.update { it.copy(force60FpsEngineSpeed = enabled) }
    if (_uiState.value.isBackgroundGovernorActive) {
      dispatchGovernorServiceStart(_uiState.value)
    }
    refreshLiveDiffPreview()
  }

  fun onToggleAmdFsr(enabled: Boolean) {
    _uiState.update { it.copy(enableAmdFsrUpscaling = enabled) }
    if (_uiState.value.isBackgroundGovernorActive) {
      dispatchGovernorServiceStart(_uiState.value)
    }
    refreshLiveDiffPreview()
  }

  fun onFsrSharpnessChanged(percent: Int) {
    _uiState.update { it.copy(fsrSharpnessPercent = percent.coerceIn(25, 100)) }
    refreshLiveDiffPreview()
  }

  fun onToggleMaxGpuClock(enabled: Boolean) {
    _uiState.update { it.copy(forceMaxGpuClock = enabled) }
    refreshLiveDiffPreview()
  }

  fun onToggleSnapdragonLongSessionCoolMode(enabled: Boolean) {
    _uiState.update { state ->
      state.copy(
        snapdragonLongSessionCoolMode = enabled,
        forceMaxGpuClock = if (enabled) false else state.forceMaxGpuClock,
        statusMessage = if (state.isArabic) {
          if (enabled) {
            "❄️ تم تفعيل وضع اللعب الطويل بدون حرارة لمعالجات Snapdragon 7 & 8 (Adreno ASTC + BC1/BC3 + خفض الفولت)."
          } else {
            "تم إيقاف وضع التبريد الطويل لمعالجات Snapdragon 7 & 8."
          }
        } else {
          if (enabled) {
            "❄️ Snapdragon 7 & 8 Long-Session Cool Mode enabled (Adreno ASTC + BC1/BC3 + Governor Relief)."
          } else {
            "Snapdragon 7 & 8 Long-Session Cool Mode disabled."
          }
        },
        logs = (state.logs + "Snapdragon 7/8 Long-Session Cool Mode = $enabled [force_max_clock=${!enabled}, astc_recompression=${if (enabled) 1 else 0}]").takeLast(40),
      )
    }
    refreshLiveDiffPreview()
  }

  fun onSafTreeGranted(uri: Uri?) {
    if (uri == null) {
      _uiState.update {
        it.copy(
          statusMessage = if (it.isArabic) "لم يتم اختيار المجلد." else "Folder selection cancelled.",
        )
      }
      return
    }
    repository.persistTreePermission(uri)
    viewModelScope.launch {
      val uriDecoded = Uri.decode(uri.toString()).lowercase(Locale.ROOT)
      val matchedProfile = when {
        uriDecoded.contains("yuzu") -> EmulatorRegistry.findProfileById("yuzu")
        uriDecoded.contains("citron") -> EmulatorRegistry.findProfileById("citron")
        uriDecoded.contains("sudachi") -> EmulatorRegistry.findProfileById("sudachi")
        uriDecoded.contains("suyu") -> EmulatorRegistry.findProfileById("suyu")
        uriDecoded.contains("uzuy") -> EmulatorRegistry.findProfileById("uzuy")
        uriDecoded.contains("skyline") -> EmulatorRegistry.findProfileById("skyline")
        uriDecoded.contains("strato") -> EmulatorRegistry.findProfileById("strato")
        uriDecoded.contains("ppsspp") -> EmulatorRegistry.findProfileById("ppsspp")
        uriDecoded.contains("aethersx2") || uriDecoded.contains("nethersx2") -> EmulatorRegistry.findProfileById("aethersx2")
        uriDecoded.contains("dolphin") -> EmulatorRegistry.findProfileById("dolphin")
        uriDecoded.contains("lime3ds") || uriDecoded.contains("citra") || uriDecoded.contains("azahar") -> EmulatorRegistry.findProfileById("lime3ds")
        uriDecoded.contains("winlator") || uriDecoded.contains("gamehub") -> EmulatorRegistry.findProfileById("winlator")
        else -> _uiState.value.selectedEmulator
      }
      val isVerifiedRoot = repository.checkIsTrueEmulatorAppFolder(uri, matchedProfile)
      val detectedArch = repository.detectArchitectureFromSafFolder(uri, matchedProfile.architecture)
      val updatedProfile = matchedProfile.copy(architecture = detectedArch)
      val games = repository.scanInstalledGamesDetailed(uri, updatedProfile)
      val firstGame = games.firstOrNull() ?: _uiState.value.selectedGame
      val selectedName = firstGame?.titleId ?: _uiState.value.gameNameInput
      val selectedVer = _uiState.value.selectedUpdateFileInfo?.detectedVersion
        ?: firstGame?.detectedVersion
        ?: "Auto"
      val customBid = _uiState.value.selectedUpdateFileInfo?.extractedBuildId
      val resolved = GameDecoderDatabase.resolveGameInput(selectedName.ifBlank { "01007EF00011E000" }, selectedVer, customBid)
      _uiState.update {
        val mergedGames = (games + it.installedGames).distinctBy { g -> g.titleId }
        it.copy(
          selectedEmulator = updatedProfile,
          grantedTreeUri = uri,
          isVerifiedEmulatorRoot = isVerifiedRoot,
          installedGames = mergedGames,
          selectedGame = firstGame,
          gameNameInput = selectedName,
          gameVersionInput = selectedVer,
          resolvedPreview = resolved,
          onboardingState = it.onboardingState.copy(hasSafAccess = true),
          statusMessage = if (it.isArabic) {
            "✅ تم ربط مجلد بيانات المحاكي بنجاح واكتشاف ${mergedGames.size} لعبة!"
          } else {
            "✅ Emulator Data Folder connected! Found ${mergedGames.size} game(s)."
          },
          logs = (it.logs + "Direct SAF Connected (Uri=${uri.lastPathSegment}, VerifiedRoot=$isVerifiedRoot, Arch=$detectedArch): ${mergedGames.size} game(s)").takeLast(40),
        )
      }
      refreshLiveDiffPreview()
    }
  }

  fun rescanInstalledGames() {
    val state = _uiState.value
    val treeUri = state.grantedTreeUri ?: return
    viewModelScope.launch {
      val isVerified = repository.checkIsTrueEmulatorAppFolder(treeUri, state.selectedEmulator)
      val games = repository.scanInstalledGamesDetailed(treeUri, state.selectedEmulator)
      val firstGame = state.selectedGame ?: games.firstOrNull()
      _uiState.update {
        val merged = (games + it.installedGames).distinctBy { g -> g.titleId }
        it.copy(
          isVerifiedEmulatorRoot = isVerified,
          installedGames = merged,
          selectedGame = firstGame,
          statusMessage = if (it.isArabic) {
            "تم تحديث فحص المجلد: يوجد ${merged.size} لعبة."
          } else {
            "Rescanned folder: found ${merged.size} game(s)."
          },
          logs = (it.logs + "Rescanned folder -> ${merged.size} real games.").takeLast(40),
        )
      }
      refreshLiveDiffPreview()
    }
  }

  fun executeSingleGameUnlock(onRequireSafPermission: () -> Unit) {
    val state = _uiState.value
    val treeUri = state.grantedTreeUri
    if (treeUri == null) {
      _uiState.update {
        it.copy(
          statusMessage = if (it.isArabic) {
            "يرجى منح إذن الوصول الكامل للمحاكي المختار أولاً لتفعيل 60 FPS."
          } else {
            "Please grant full access to the selected emulator first to unlock 60 FPS."
          },
        )
      }
      onRequireSafPermission()
      return
    }

    viewModelScope.launch {
      _uiState.update {
        it.copy(
          isRunning = true,
          statusMessage = if (it.isArabic) {
            "جارٍ كتابة والتحقق من main.pchtxt وحقن إعدادات Local NPU AI (60FPS + AMD FSR + NCE)..."
          } else {
            "Writing & verifying main.pchtxt and injecting Local NPU AI Optimization (60FPS + AMD FSR + NCE)..."
          },
        )
      }

      try {
        val hwConfig = buildCurrentHardwareConfig(state)
        val targetInput = state.selectedUpdateFileInfo?.detectedBaseTitleId
          ?: state.selectedGameFileInfo?.detectedBaseTitleId
          ?: state.selectedGame?.titleId
          ?: state.gameNameInput
        val customBid = state.selectedUpdateFileInfo?.extractedBuildId
          ?: state.selectedGameFileInfo?.extractedBuildId
        val customPchtxt = state.selectedUpdateFileInfo?.embeddedPchtxtContent
          ?: state.selectedGameFileInfo?.embeddedPchtxtContent

        val result = repository.importFromGithubAndUnlock60Fps(
          treeUri = treeUri,
          rawGameInput = targetInput,
          rawVersionInput = state.gameVersionInput,
          githubUrlInput = state.githubUrlInput,
          hwConfig = hwConfig,
          profile = state.selectedEmulator,
          customBuildId = customBid,
          customUpdatePchtxt = customPchtxt,
        )
        val updatedGames = repository.scanInstalledGamesDetailed(treeUri, state.selectedEmulator)
        _uiState.update {
          val mergedGames = (updatedGames + it.installedGames).distinctBy { g -> g.titleId }
          val nextStatus =
            if (!result.applied) {
              if (it.isArabic) result.plainOutcomeMessageAr.ifBlank { "لا يوجد باتش مطابق — لم يتم تطبيق أي تعديل." }
              else result.plainOutcomeMessageEn.ifBlank { "No matching patch found — nothing was applied." }
            } else if (result.pchtxtWriteVerified) {
              if (it.isArabic) {
                result.plainOutcomeMessageAr.ifBlank {
                  "تم بنجاح! تم التحقق من main.pchtxt وتفعيل 60 FPS للعبة (${result.diagnosisStatus.statusEn}) ✓"
                }
              } else {
                result.plainOutcomeMessageEn.ifBlank {
                  "Success! Verified main.pchtxt & unlocked per-game 60 FPS (${result.diagnosisStatus.statusEn}) ✓"
                }
              }
            } else {
              if (it.isArabic) {
                "تنبيه الأمان: تعذّر التحقق من كتابة main.pchtxt، تم إبقاء speed_limit=100 لمنع تسريع اللعبة 2x."
              } else {
                "Safety Fallback: main.pchtxt failed verification; kept speed_limit=100 to prevent 2x fast-forward."
              }
            }
          it.copy(
            isRunning = false,
            isBackgroundGovernorActive = result.applied || it.isBackgroundGovernorActive,
            isSmartProfileScreenOpen = false,
            isDiagnosisScreenOpen = false,
            isVerifiedEmulatorRoot = result.isVerifiedEmulatorRoot,
            installedGames = mergedGames,
            lastInjectionResult = result,
            lastPatchSource = result.patchSource,
            statusMessage = nextStatus,
            logs = (
              it.logs +
                result.logs +
                "Multi-Source Telemetry: Active Patch Source = [${result.patchSource}] | NSO Build ID: ${result.detectedBuildId}"
            ).takeLast(50),
          )
        }
        if (result.applied) {
          dispatchGovernorServiceStart(_uiState.value)
        }
        refreshLiveDiffPreview()
      } catch (e: Exception) {
        _uiState.update {
          it.copy(
            isRunning = false,
            statusMessage = if (it.isArabic) "حدث خطأ: ${e.message}" else "Error: ${e.message}",
            logs = (it.logs + "ERROR: ${e.message}").takeLast(50),
          )
        }
      }
    }
  }

  fun executeUnlockAllGames(onRequireSafPermission: () -> Unit) {
    val state = _uiState.value
    val treeUri = state.grantedTreeUri
    if (treeUri == null) {
      onRequireSafPermission()
      return
    }

    viewModelScope.launch {
      _uiState.update {
        it.copy(
          isRunning = true,
          statusMessage = if (it.isArabic) {
            "جارٍ تفعيل 60 FPS وأنماط الأداء لجميع الألعاب الموجودة في المجلد (${state.installedGames.size})..."
          } else {
            "Unlocking 60 FPS + Performance Tuning for all ${state.installedGames.size} folder games..."
          },
        )
      }

      try {
        val hwConfig = buildCurrentHardwareConfig(state)

        var lastResult: RealInjectionResult? = null
        val totalLogs = mutableListOf<String>()

        val targets = state.installedGames.map { it.titleId }.ifEmpty {
          listOf(state.gameNameInput.ifBlank { "0100F2C0115B6000" })
        }

        for (targetId in targets) {
          val res = repository.importFromGithubAndUnlock60Fps(
            treeUri = treeUri,
            rawGameInput = targetId,
            rawVersionInput = "Auto",
            githubUrlInput = state.githubUrlInput,
            hwConfig = hwConfig,
            profile = state.selectedEmulator,
          )
          lastResult = res
          totalLogs.addAll(res.logs)
        }

        val updatedGames = repository.scanInstalledGamesDetailed(treeUri, state.selectedEmulator)
        _uiState.update {
          it.copy(
            isRunning = false,
            installedGames = updatedGames,
            lastInjectionResult = lastResult,
            statusMessage = if (it.isArabic) {
              "تم بنجاح تفعيل 60 FPS وأنماط الأداء لجميع ألعاب المجلد (${targets.size}) ✓"
            } else {
              "Success! Unlocked 60 FPS + Performance for all ${targets.size} folder games ✓"
            },
            logs = (it.logs + totalLogs).takeLast(50),
          )
        }
        refreshLiveDiffPreview()
      } catch (e: Exception) {
        _uiState.update {
          it.copy(
            isRunning = false,
            statusMessage = "Batch Error: ${e.message}",
            logs = (it.logs + "BATCH ERROR: ${e.message}").takeLast(50),
          )
        }
      }
    }
  }

  fun onSelectProfile(profile: SmartTuningProfile) {
    val cfg = EmulatorHardwareConfig.fromProfile(profile)
    _uiState.update {
      it.copy(
        selectedProfile = profile,
        force60FpsEngineSpeed = cfg.force60FpsEngineSpeed,
        enableAmdFsrUpscaling = cfg.enableAmdFsrUpscaling,
        fsrSharpnessPercent = cfg.fsrSharpnessPercent,
        forceMaxGpuClock = cfg.forceMaxGpuClockAndAsyncShaders,
        enablePerformanceNce = cfg.enablePerformanceNceOptimization,
        statusMessage = if (it.isArabic) {
          "تم اختيار نمط: ${profile.labelAr} (${profile.resolutionLabel} • ${profile.targetFpsLabel})"
        } else {
          "Selected profile: ${profile.labelEn} (${profile.resolutionLabel} • ${profile.targetFpsLabel})"
        },
        logs = (it.logs + "Profile selected: ${profile.labelEn} [res=${profile.resolutionLabel}, speed=${profile.speedLimitValue}]").takeLast(40)
      )
    }
    refreshLiveDiffPreview()
  }

  fun onToggleAutoAdaptThermal(enabled: Boolean) {
    _uiState.update { it.copy(autoAdaptThermalProfile = enabled) }
  }

  fun onOpenDiffPreview() {
    val state = _uiState.value
    viewModelScope.launch {
      val hwConfig = buildCurrentHardwareConfig(state)
      val diffs = repository.generateConfigDiffPreview(state.grantedTreeUri, state.selectedEmulator, hwConfig)
      _uiState.update {
        it.copy(
          previewDiffList = diffs,
          isDiffDialogVisible = true,
        )
      }
    }
  }

  fun onDismissDiffPreview() {
    _uiState.update { it.copy(isDiffDialogVisible = false) }
  }

  fun restoreOriginalConfig() {
    val state = _uiState.value
    val treeUri = state.grantedTreeUri ?: return
    viewModelScope.launch {
      _uiState.update { it.copy(isRunning = true) }
      try {
        val restoreLogs = repository.restoreOriginalConfig(treeUri)
        val updatedGames = repository.scanInstalledGamesDetailed(treeUri, state.selectedEmulator)
        _uiState.update {
          it.copy(
            isRunning = false,
            installedGames = updatedGames,
            lastInjectionResult = null,
            statusMessage = if (it.isArabic) {
              "تم بنجاح استعادة الإعدادات الأصلية من النسخة الاحتياطية وإزالة المودات."
            } else {
              "Successfully restored original configuration from backup & cleaned mods."
            },
            logs = (it.logs + restoreLogs).takeLast(50),
          )
        }
        refreshLiveDiffPreview()
      } catch (e: Exception) {
        _uiState.update {
          it.copy(
            isRunning = false,
            logs = (it.logs + "Restore error: ${e.message}").takeLast(50),
          )
        }
      }
    }
  }

  fun restoreDefault30Fps() {
    restoreOriginalConfig()
  }

  /**
   * Runs the Local On-Device TensorFlow Lite NPU/GPU AI Optimization System (`AiFrameEnhancerProcessor`):
   * 1. Initializes the `.tflite` Super-Resolution model via `MappedByteBuffer` on `NnApiDelegate` (Hexagon NPU)
   *    or `GpuDelegate` (Adreno GPU) with CPU fallback disabled.
   * 2. Samples display frame pacing, battery temperature (°C), and free RAM, then synthesizes the optimization plan.
   */
  fun runAiOptimizationSystem() {
    val cur = _uiState.value
    val net = NetworkConnectivityMonitor.readCurrentNetworkState(appContext)
    val telemetry = NetworkConnectivityMonitor.readDirectPhoneTelemetry(appContext)

    _uiState.update {
      it.copy(
        localNpuAiUpscalingEnabled = true,
        networkState = net,
        directTelemetry = telemetry,
        aiOptimizationState = AiOptimizationUiState.Running(
          stepMessageEn = "Initializing Local .tflite Super-Resolution model on Hexagon NPU / Adreno GPU...",
          stepMessageAr = "جارٍ تشغيل نموذج الذكاء الاصطناعي المحلي (.tflite) على معالج Hexagon NPU / Adreno GPU...",
        ),
        statusMessage = if (it.isArabic) {
          "✨ جارٍ تشغيل Local NPU AI Upscaling عبر معالج Hexagon NPU..."
        } else {
          "✨ Running Local NPU AI Upscaling on Hexagon NPU / Adreno GPU..."
        },
      )
    }

    viewModelScope.launch {
      val targetInput = cur.selectedUpdateFileInfo?.detectedBaseTitleId
        ?: cur.selectedGameFileInfo?.detectedBaseTitleId
        ?: cur.selectedGame?.titleId
        ?: cur.gameNameInput.ifBlank { "01007EF00011E000" }
      val customBid = cur.selectedUpdateFileInfo?.extractedBuildId
        ?: cur.selectedGameFileInfo?.extractedBuildId
      val resolved = GameDecoderDatabase.resolveGameInput(targetInput, cur.gameVersionInput, customBid)

      val aiResult = AiOptimizationEngine.generateLocalNpuOptimizationPlan(
        context = appContext,
        processor = aiFrameEnhancerProcessor,
        hardwareInfo = cur.deviceHardwareInfo,
        thermalStatus = cur.thermalStatus,
        decodedGame = resolved,
      )

      val refreshedNet = NetworkConnectivityMonitor.readCurrentNetworkState(appContext)
      val refreshedTelemetry = NetworkConnectivityMonitor.readDirectPhoneTelemetry(appContext)
      val updatedNpuStatus = aiFrameEnhancerProcessor.currentStatus(isEnabled = true)

      aiResult.onSuccess { plan ->
        applyPlanToTunerState(plan, resolved, refreshedNet, refreshedTelemetry)
        _uiState.update { st ->
          st.copy(
            localNpuAiUpscalingEnabled = true,
            isBackgroundGovernorActive = true,
            localNpuStatus = updatedNpuStatus,
            aiOptimizationState = AiOptimizationUiState.Success(plan),
            latestFrameMetrics = plan.measuredMetrics,
            statusMessage = if (st.isArabic) plan.summaryHeadlineAr else plan.summaryHeadlineEn,
            logs = (
              st.logs +
                "Local NPU AI Optimization [${plan.activeHardwareDelegateEn}]: ${plan.summaryHeadlineEn}"
              ).takeLast(50),
          )
        }
        dispatchGovernorServiceStart(_uiState.value)
        refreshLiveDiffPreview()
      }.onFailure { err ->
        val sampledMetrics = AiOptimizationEngine.sampleRealDeviceFrameAndHardwareMetrics(
          context = appContext,
          networkState = refreshedNet,
          directTelemetry = refreshedTelemetry,
        )
        val fallbackBaseline = AiOptimizationEngine.buildDeterministicBaselinePlan(
          hardwareInfo = cur.deviceHardwareInfo,
          thermalStatus = cur.thermalStatus,
          decodedGame = resolved,
          metrics = sampledMetrics,
          npuStatus = updatedNpuStatus,
        )
        applyPlanToTunerState(fallbackBaseline, resolved, refreshedNet, refreshedTelemetry)
        _uiState.update { st ->
          st.copy(
            localNpuAiUpscalingEnabled = true,
            localNpuStatus = updatedNpuStatus,
            aiOptimizationState = AiOptimizationUiState.Error(
              message = err.message ?: "Applied Local NPU Baseline Optimization Plan.",
              fallbackPlan = fallbackBaseline,
            ),
            latestFrameMetrics = fallbackBaseline.measuredMetrics,
            statusMessage = if (st.isArabic) fallbackBaseline.summaryHeadlineAr else fallbackBaseline.summaryHeadlineEn,
          )
        }
        refreshLiveDiffPreview()
      }
    }
  }

  private fun applyPlanToTunerState(
    plan: AiOptimizationPlan,
    resolved: DecodedGameRelease,
    net: NetworkConnectionState,
    telemetry: DirectPhoneTelemetry,
  ) {
    _uiState.update { st ->
      st.copy(
        selectedProfile = plan.recommendedProfile,
        force60FpsEngineSpeed = plan.enableDynamic60FpsFramePacing,
        enableAmdFsrUpscaling = true,
        fsrSharpnessPercent = plan.aiFsrSharpnessPercent,
        forceMaxGpuClock = false,
        enablePerformanceNce = true,
        snapdragonLongSessionCoolMode = plan.enableSnapdragonCoolGovernor,
        resolvedPreview = resolved,
        networkState = net,
        directTelemetry = telemetry,
      )
    }
  }

  fun applyAiOptimizationPlan(
    plan: AiOptimizationPlan,
    onRequireSafPermission: () -> Unit,
  ) {
    val cur = _uiState.value
    applyPlanToTunerState(
      plan = plan,
      resolved = cur.resolvedPreview,
      net = cur.networkState,
      telemetry = cur.directTelemetry,
    )
    executeSingleGameUnlock(onRequireSafPermission)
  }

  fun syncCloudOverMobileDataOrWifi() {
    val cur = _uiState.value
    val net = NetworkConnectivityMonitor.readCurrentNetworkState(appContext)
    val telemetry = NetworkConnectivityMonitor.readDirectPhoneTelemetry(appContext)
    _uiState.update {
      it.copy(
        isCloudSyncing = true,
        networkState = net,
        directTelemetry = telemetry,
        statusMessage = if (it.isArabic) {
          "🌐 جارٍ المزامنة المباشرة عبر ${net.badgeAr}..."
        } else {
          "🌐 Syncing directly over ${net.badgeEn}..."
        },
      )
    }

    viewModelScope.launch {
      val targetInput = cur.selectedUpdateFileInfo?.detectedBaseTitleId
        ?: cur.selectedGameFileInfo?.detectedBaseTitleId
        ?: cur.selectedGame?.titleId
        ?: cur.gameNameInput.ifBlank { "01007EF00011E000" }
      val customBid = cur.selectedUpdateFileInfo?.extractedBuildId
        ?: cur.selectedGameFileInfo?.extractedBuildId
      val resolved = GameDecoderDatabase.resolveGameInput(targetInput, cur.gameVersionInput, customBid)

      val syncResult = repository.syncCloudPatchOverMobileDataOrWifi(
        titleId = resolved.primaryTitleId,
        gameName = resolved.titleNameEn,
        githubUrlInput = cur.githubUrlInput,
      )

      val refreshedNet = NetworkConnectivityMonitor.readCurrentNetworkState(appContext)
      val refreshedTelemetry = NetworkConnectivityMonitor.readDirectPhoneTelemetry(appContext)
      _uiState.update { st ->
        st.copy(
          isCloudSyncing = false,
          networkState = refreshedNet,
          directTelemetry = refreshedTelemetry,
          resolvedPreview = resolved,
          statusMessage = if (st.isArabic) syncResult.summaryAr else syncResult.summaryEn,
          logs = (st.logs + "Direct Network Sync [${syncResult.transportLabelEn}]: ${syncResult.summaryEn}").takeLast(50),
        )
      }
    }
  }

  override fun onCleared() {
    super.onCleared()
    aiFrameEnhancerProcessor.close()
  }
}
