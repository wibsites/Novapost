package com.example.data

import android.app.ActivityManager
import android.content.Context
import android.hardware.display.DisplayManager
import android.os.Build
import android.view.Display
import java.util.Locale

enum class GamePatchDiagnosisStatus(
  val statusEn: String,
  val statusAr: String,
) {
  MATCHED(
    statusEn = "Matched",
    statusAr = "متطابق (Matched)",
  ),
  VERSION_MISMATCH(
    statusEn = "Version mismatch",
    statusAr = "عدم تطابق الإصدار (Version mismatch)",
  ),
  NO_PATCH_AVAILABLE(
    statusEn = "No patch available",
    statusAr = "لا يتوفر باتش (No patch available)",
  ),
  WRITTEN_NOT_VERIFIED(
    statusEn = "Written but not verified",
    statusAr = "كُتب دون تحقق (Written but not verified)",
  ),
}

/**
 * Represents a single version's `.pchtxt` payload with strictly ONE `@nsobid-<HEX>` header
 * on line 1, as required by Eden/Yuzu's native C++ `PatchManager` (`IPSwitchCompiler`).
 */
data class VersionPchtxtFile(
  val fileName: String,
  val versionTag: String,
  val nsoBuildId: String,
  val pchtxtContent: String,
)

data class DecodedGameRelease(
  val primaryTitleId: String,
  val allRegionalTitleIds: List<String>,
  val titleNameEn: String,
  val titleNameAr: String,
  val requestedVersion: String,
  val versionFiles: List<VersionPchtxtFile>,
  val cheatFileName: String,
  val cheatFileContent: String,
  val githubSearchQuery: String,
  val isKnownGameInDatabase: Boolean = false,
  val detectedBuildId: String = "",
  val hasExactBuildIdPatchMatch: Boolean = false,
  val diagnosisStatus: GamePatchDiagnosisStatus = GamePatchDiagnosisStatus.NO_PATCH_AVAILABLE,
  val supportedVersionsSummary: String = "None",
  val diagnosisReasonEn: String = "",
  val diagnosisReasonAr: String = "",
) {
  val titleId: String
    get() = primaryTitleId

  val nsoBuildId: String
    get() = versionFiles.firstOrNull()?.nsoBuildId ?: detectedBuildId.ifBlank { "NONE" }

  val pchtxtPayload: String
    get() = versionFiles.firstOrNull()?.pchtxtContent.orEmpty()
}

enum class SnapdragonProcessorSeries(
  val badgeEn: String,
  val badgeAr: String,
  val architectureNoteEn: String,
  val architectureNoteAr: String,
) {
  SNAPDRAGON_8_SERIES(
    badgeEn = "Snapdragon 8 Series Dedicated",
    badgeAr = "مخصص لمعالجات Snapdragon الفئة 8",
    architectureNoteEn = "Snapdragon 8 Series (Kryo/Oryon ARM64 NCE + Adreno 7xx/8xx Hardware ASTC): Offloads CPU translation via NCE and cuts Adreno GPU pixel load via 0.75x + AMD FSR for cool long-session play.",
    architectureNoteAr = "معالج Snapdragon الفئة 8 (معمارية NCE + رسوميات Adreno 7xx/8xx): يلغي ضغط المعالج عبر تشغيل الكود مباشرة (NCE) ويخفف حمل الـ GPU عبر دقة 0.75x مع AMD FSR للعب الطويل بدون حرارة.",
  ),
  SNAPDRAGON_7_SERIES(
    badgeEn = "Snapdragon 7 Series Dedicated",
    badgeAr = "مخصص لمعالجات Snapdragon الفئة 7",
    architectureNoteEn = "Snapdragon 7 Series (Kryo ARM64 NCE + Adreno 6xx/7xx Low-Pressure Engine): Uses BC1/BC3 ASTC recompression, NCE, and lowered internal resolution with AMD FSR to prevent heat & RAM pressure during long sessions.",
    architectureNoteAr = "معالج Snapdragon الفئة 7 (معمارية NCE + رسوميات Adreno 6xx/7xx): يستخدم ضغط ASTC الذكي وتشغيل NCE مع دقة داخلية مخففة وفلتر AMD FSR لمنع أي ضغط أو سكون حراري حتى مع اللعب لساعات طويلة.",
  ),
  SNAPDRAGON_TUNED_ARM64(
    badgeEn = "Snapdragon 7 & 8 Low-Pressure Engine",
    badgeAr = "محرك تخفيف الضغط لمعالجات Snapdragon 7 & 8",
    architectureNoteEn = "Tuned for Snapdragon 7 & 8 architecture (ARM64 NCE + Vulkan Pipeline Cache + AMD FSR + ASTC Acceleration) to take pressure off the phone during extended play.",
    architectureNoteAr = "مهيأ لمعمارية Snapdragon 7 و 8 (ARM64 NCE + كاش Vulkan + فلتر AMD FSR + تسريع ASTC) لرفع الضغط عن الهاتف أثناء جلسات اللعب الطويلة.",
  );

  val sustainedPlaySummaryEn: String
    get() = architectureNoteEn

  val sustainedPlaySummaryAr: String
    get() = architectureNoteAr
}

data class DeviceHardwareInfo(
  val socBrand: String,
  val chipName: String,
  val hardwareEngine: String,
  val socModelCode: String,
  val totalRamGb: Int,
  val refreshRateHz: Int,
  val recommendedProfile: SmartTuningProfile,
  val hardwareSummaryAr: String,
  val hardwareSummaryEn: String,
  val snapdragonSeries: SnapdragonProcessorSeries = SnapdragonProcessorSeries.SNAPDRAGON_TUNED_ARM64,
  val isSnapdragon7Or8: Boolean = true,
) {
  val deviceClassEn: String
    get() = "${socModelCode} • ${totalRamGb}GB RAM • ${refreshRateHz}Hz (${snapdragonSeries.badgeEn})"

  val deviceClassAr: String
    get() = "المعالج ${socModelCode} • رام ${totalRamGb}GB • شاشة ${refreshRateHz}Hz (${snapdragonSeries.badgeAr})"

  val hardwareSummary: String
    get() = hardwareSummaryAr
}

object DevicePerformanceDetector {
  fun detectDeviceHardware(context: Context? = null): DeviceHardwareInfo {
    val board = Build.BOARD.lowercase(Locale.ROOT)
    val hardware = Build.HARDWARE.lowercase(Locale.ROOT)
    val socRaw = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) Build.SOC_MODEL else ""
    val soc = socRaw.ifBlank { Build.HARDWARE }.uppercase(Locale.ROOT)

    val totalRamGb = try {
      val am = context?.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
      if (am != null) {
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)
        val gb = (memInfo.totalMem / (1024.0 * 1024.0 * 1024.0))
        kotlin.math.ceil(gb).toInt().coerceAtLeast(4)
      } else {
        8
      }
    } catch (_: Throwable) {
      8
    }

    val refreshRateHz = try {
      val dm = context?.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
      val display = dm?.getDisplay(Display.DEFAULT_DISPLAY)
      display?.refreshRate?.toInt()?.coerceAtLeast(60) ?: 60
    } catch (_: Throwable) {
      60
    }

    val isSnapdragon8 = soc.contains("SM8") || soc.contains("8750") || soc.contains("8650") ||
      soc.contains("8635") || soc.contains("8550") || soc.contains("8475") ||
      soc.contains("8450") || soc.contains("8350") || soc.contains("8250") ||
      board.contains("sun") || board.contains("pineapple") || board.contains("kalama") ||
      board.contains("taro") || board.contains("lahaina") || board.contains("kona")

    val isSnapdragon7 = soc.contains("SM7") || soc.contains("7675") || soc.contains("7550") ||
      soc.contains("7475") || soc.contains("7450") || soc.contains("7435") ||
      soc.contains("7325") || soc.contains("7350") || soc.contains("7225") ||
      board.contains("crow") || board.contains("ukee") || board.contains("diwali") ||
      board.contains("yupik") || board.contains("lito")

    val isHighEndSoC = isSnapdragon8 || soc.contains("9300") || soc.contains("9400") || soc.contains("9200")

    val recommendedProfile = when {
      totalRamGb < 6 -> SmartTuningProfile.BATTERY_SAVER
      isSnapdragon7 -> SmartTuningProfile.BALANCED
      isHighEndSoC && totalRamGb >= 12 && refreshRateHz >= 90 -> SmartTuningProfile.QUALITY
      totalRamGb >= 8 -> SmartTuningProfile.PERFORMANCE
      else -> SmartTuningProfile.BALANCED
    }

    val isQcom = isSnapdragon8 || isSnapdragon7 || board.contains("qcom") ||
      hardware.contains("qcom") || hardware.contains("snapdragon") || soc.contains("SM")

    val snapdragonTier = when {
      isSnapdragon8 -> SnapdragonProcessorSeries.SNAPDRAGON_8_SERIES
      isSnapdragon7 -> SnapdragonProcessorSeries.SNAPDRAGON_7_SERIES
      isQcom -> SnapdragonProcessorSeries.SNAPDRAGON_8_SERIES
      else -> SnapdragonProcessorSeries.SNAPDRAGON_TUNED_ARM64
    }

    val isTensor = board.contains("slider") || board.contains("tensor") || hardware.contains("tensor")
    val isMtk = hardware.contains("mt") || board.contains("mt") || hardware.contains("dimensity")

    return when {
      isQcom -> {
        val seriesTitle = if (isSnapdragon7) "Snapdragon 7 Series" else "Snapdragon 8 Series"
        DeviceHardwareInfo(
          socBrand = "Qualcomm $seriesTitle",
          chipName = "$seriesTitle ($soc)",
          hardwareEngine = "ARM64 NCE + Adreno ASTC + Vulkan FSR",
          socModelCode = soc,
          totalRamGb = totalRamGb,
          refreshRateHz = refreshRateHz,
          recommendedProfile = recommendedProfile,
          hardwareSummaryAr = "مخصص لمعالجات Snapdragon 7 & 8: المعالج $soc • الذاكرة ${totalRamGb}GB • الشاشة ${refreshRateHz}Hz (النمط الموصى به لتخفيف الضغط: ${recommendedProfile.labelAr})",
          hardwareSummaryEn = "Dedicated Snapdragon 7 & 8 Engine: $soc • ${totalRamGb}GB RAM • ${refreshRateHz}Hz Display (Recommended Low-Pressure Profile: ${recommendedProfile.labelEn})",
          snapdragonSeries = snapdragonTier,
          isSnapdragon7Or8 = true,
        )
      }
      isTensor -> DeviceHardwareInfo(
        socBrand = "Google Tensor (Snapdragon 7/8 Tuned Mode)",
        chipName = "Google Tensor SoC ($soc)",
        hardwareEngine = "ARM64 NCE + Vulkan Pipeline Cache",
        socModelCode = soc,
        totalRamGb = totalRamGb,
        refreshRateHz = refreshRateHz,
        recommendedProfile = recommendedProfile,
        hardwareSummaryAr = "محرك Snapdragon 7 & 8 لتخفيف الضغط نشط على $soc • الذاكرة ${totalRamGb}GB • الشاشة ${refreshRateHz}Hz (الموصى به: ${recommendedProfile.labelAr})",
        hardwareSummaryEn = "Snapdragon 7 & 8 Low-Pressure Engine active on $soc • ${totalRamGb}GB RAM • ${refreshRateHz}Hz (Recommended: ${recommendedProfile.labelEn})",
        snapdragonSeries = SnapdragonProcessorSeries.SNAPDRAGON_TUNED_ARM64,
        isSnapdragon7Or8 = false,
      )
      isMtk -> DeviceHardwareInfo(
        socBrand = "MediaTek Dimensity (Snapdragon 7/8 Tuned Mode)",
        chipName = "Dimensity SoC ($soc)",
        hardwareEngine = "ARM64 NCE + Vulkan Pipeline Cache",
        socModelCode = soc,
        totalRamGb = totalRamGb,
        refreshRateHz = refreshRateHz,
        recommendedProfile = recommendedProfile,
        hardwareSummaryAr = "محرك Snapdragon 7 & 8 لتخفيف الضغط نشط على $soc • الذاكرة ${totalRamGb}GB • الشاشة ${refreshRateHz}Hz (الموصى به: ${recommendedProfile.labelAr})",
        hardwareSummaryEn = "Snapdragon 7 & 8 Low-Pressure Engine active on $soc • ${totalRamGb}GB RAM • ${refreshRateHz}Hz (Recommended: ${recommendedProfile.labelEn})",
        snapdragonSeries = SnapdragonProcessorSeries.SNAPDRAGON_TUNED_ARM64,
        isSnapdragon7Or8 = false,
      )
      else -> DeviceHardwareInfo(
        socBrand = "Snapdragon 7 & 8 Dedicated Engine (${Build.MANUFACTURER.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.ROOT) else it.toString() }})",
        chipName = "Snapdragon 7/8 Tuned ARM64 ($soc)",
        hardwareEngine = "ARM64 NCE + Adreno/Vulkan Low-Pressure FSR",
        socModelCode = soc,
        totalRamGb = totalRamGb,
        refreshRateHz = refreshRateHz,
        recommendedProfile = recommendedProfile,
        hardwareSummaryAr = "مخصص لمعالجات Snapdragon 7 & 8 لتخفيف الضغط: المعالج $soc • الذاكرة ${totalRamGb}GB • الشاشة ${refreshRateHz}Hz (الموصى به: ${recommendedProfile.labelAr})",
        hardwareSummaryEn = "Snapdragon 7 & 8 Low-Pressure Mode: $soc • ${totalRamGb}GB RAM • ${refreshRateHz}Hz Display (Recommended: ${recommendedProfile.labelEn})",
        snapdragonSeries = snapdragonTier,
        isSnapdragon7Or8 = true,
      )
    }
  }
}

enum class SmartTuningProfile(
  val labelEn: String,
  val labelAr: String,
  val descriptionEn: String,
  val descriptionAr: String,
  val resolutionLabel: String,
  val resolutionSetupCode: String,
  val targetFpsLabel: String,
  val speedLimitValue: Int,
  val fsrSharpnessValue: Int,
) {
  BATTERY_SAVER(
    labelEn = "Battery Saver (Ultra-Cool)",
    labelAr = "توفير الطاقة (برودة قصوى)",
    descriptionEn = "Snapdragon 7/8 Long-Play Relief: NCE (cpu_backend=1), 0.5x internal resolution (resolution_setup=0) with AMD FSR (scaling_filter=5), ASTC acceleration, and 30 FPS limit (speed_limit=100).",
    descriptionAr = "تخفيف أقصى لمعالجات Snapdragon 7/8: تفعيل NCE (cpu_backend=1)، دقة داخلية 0.5x مع فلتر AMD FSR، تسريع ASTC، وحد 30 FPS للعب الطويل بدون أي حرارة.",
    resolutionLabel = "0.5x + AMD FSR",
    resolutionSetupCode = "0",
    targetFpsLabel = "30 FPS (speed_limit=100)",
    speedLimitValue = 100,
    fsrSharpnessValue = 60,
  ),
  BALANCED(
    labelEn = "Balanced (Snapdragon 7 & 8 Sustained)",
    labelAr = "متوازن (لعب طويل بدون ضغط Snapdragon 7/8)",
    descriptionEn = "Ideal for Snapdragon 7 & 8 multi-hour play: NCE (cpu_backend=1), 0.75x internal resolution (resolution_setup=1) with AMD FSR (75%), hardware ASTC, and normal Adreno clocks to prevent heat buildup.",
    descriptionAr = "مثالي للعب لساعات طويلة على Snapdragon 7 و 8: تفعيل NCE، دقة داخلية 0.75x مع فلتر AMD FSR (75%)، تسريع ASTC، ومنع رفع فولتية الـ GPU لمنع السخونة.",
    resolutionLabel = "0.75x + AMD FSR",
    resolutionSetupCode = "1",
    targetFpsLabel = "60 FPS (speed_limit=200)",
    speedLimitValue = 200,
    fsrSharpnessValue = 75,
  ),
  PERFORMANCE(
    labelEn = "Performance (Snapdragon 8 / 7+ 60FPS)",
    labelAr = "الأداء العالي (Snapdragon 8 / 7+ 60FPS)",
    descriptionEn = "Verified Snapdragon 7+/8 keys: NCE (cpu_backend=1), 0.75x internal resolution (resolution_setup=1) with AMD FSR (85%), async shaders, Vulkan pipeline cache, and 60 FPS unlock.",
    descriptionAr = "مفاتيح Snapdragon 7+/8 المعتمدة: تفعيل NCE، دقة 0.75x لتخفيف ضغط الرسوميات مع فلتر AMD FSR (85%)، شيدر لاتزامني، وفتح 60 FPS.",
    resolutionLabel = "0.75x + AMD FSR (85%)",
    resolutionSetupCode = "1",
    targetFpsLabel = "60 FPS (speed_limit=200)",
    speedLimitValue = 200,
    fsrSharpnessValue = 85,
  ),
  QUALITY(
    labelEn = "Quality (Snapdragon 8 Flagship)",
    labelAr = "الجودة القصوى (معالجات Snapdragon 8 الرائدة)",
    descriptionEn = "Verified keys: NCE (cpu_backend=1), 1.0x native resolution (resolution_setup=2) with AMD FSR (90%), async shaders, and 60 FPS limit (speed_limit=200).",
    descriptionAr = "مفاتيح Eden المعتمدة: تفعيل NCE، دقة 1.0x أصلية كاملة (resolution_setup=2) مع فلتر AMD FSR (90%)، وفتح 60 FPS لأعلى جودة بصرية.",
    resolutionLabel = "1.0x Native + AMD FSR (90%)",
    resolutionSetupCode = "2",
    targetFpsLabel = "60 FPS (speed_limit=200)",
    speedLimitValue = 200,
    fsrSharpnessValue = 90,
  )
}

/**
 * Hardware optimization & 60FPS engine settings written directly into Eden / Yuzu's
 * `files/config/config.ini` and `files/config/custom/<Title_ID>.ini`.
 */
data class EmulatorHardwareConfig(
  val profile: SmartTuningProfile = SmartTuningProfile.PERFORMANCE,
  val force60FpsEngineSpeed: Boolean = true,
  val enableAmdFsrUpscaling: Boolean = true,
  val fsrSharpnessPercent: Int = 85,
  val forceMaxGpuClockAndAsyncShaders: Boolean = false,
  val enablePerformanceNceOptimization: Boolean = true,
  val resolutionScale: String = "0.75x + AMD FSR (85%)",
  val snapdragonLongSessionCoolMode: Boolean = false,
  val ultimateThermalBypass: Boolean = true,
  val useSnapdragonSgsr: Boolean = false,
  val frameLimit: Int = 120,
) {
  companion object {
    fun fromProfile(
      profile: SmartTuningProfile,
      longSessionCoolMode: Boolean = true,
    ): EmulatorHardwareConfig {
      return when (profile) {
        SmartTuningProfile.BATTERY_SAVER -> EmulatorHardwareConfig(
          profile = profile,
          force60FpsEngineSpeed = false,
          enableAmdFsrUpscaling = true,
          fsrSharpnessPercent = 60,
          forceMaxGpuClockAndAsyncShaders = false,
          enablePerformanceNceOptimization = true,
          resolutionScale = profile.resolutionLabel,
          snapdragonLongSessionCoolMode = true,
          ultimateThermalBypass = true,
          useSnapdragonSgsr = false,
          frameLimit = 100,
        )
        SmartTuningProfile.BALANCED -> EmulatorHardwareConfig(
          profile = profile,
          force60FpsEngineSpeed = true,
          enableAmdFsrUpscaling = true,
          fsrSharpnessPercent = 75,
          forceMaxGpuClockAndAsyncShaders = false,
          enablePerformanceNceOptimization = true,
          resolutionScale = profile.resolutionLabel,
          snapdragonLongSessionCoolMode = true,
          ultimateThermalBypass = true,
          useSnapdragonSgsr = false,
          frameLimit = 120,
        )
        SmartTuningProfile.PERFORMANCE -> EmulatorHardwareConfig(
          profile = profile,
          force60FpsEngineSpeed = true,
          enableAmdFsrUpscaling = true,
          fsrSharpnessPercent = 85,
          forceMaxGpuClockAndAsyncShaders = false,
          enablePerformanceNceOptimization = true,
          resolutionScale = profile.resolutionLabel,
          snapdragonLongSessionCoolMode = true,
          ultimateThermalBypass = true,
          useSnapdragonSgsr = false,
          frameLimit = 120,
        )
        SmartTuningProfile.QUALITY -> EmulatorHardwareConfig(
          profile = profile,
          force60FpsEngineSpeed = true,
          enableAmdFsrUpscaling = true,
          fsrSharpnessPercent = 90,
          forceMaxGpuClockAndAsyncShaders = false,
          enablePerformanceNceOptimization = true,
          resolutionScale = profile.resolutionLabel,
          snapdragonLongSessionCoolMode = true,
          ultimateThermalBypass = true,
          useSnapdragonSgsr = false,
          frameLimit = 120,
        )
      }
    }
  }
}

object GameDecoderDatabase {

  const val CONTAINER_VERSION = "v5.0-GITHUB-REAL-60FPS"

  private data class KnownSwitchGame(
    val keywords: List<String>,
    val nameEn: String,
    val nameAr: String,
    val titleIds: List<String>,
    val versionBuildIds: List<Pair<String, String>>,
    val asmPatches: List<String>,
  )

  private val KNOWN_GAMES = listOf(
    KnownSwitchGame(
      keywords = listOf("totk", "tears", "zelda tears", "دموع المملكة", "زيلدا دموع"),
      nameEn = "The Legend of Zelda: Tears of the Kingdom",
      nameAr = "أسطورة زيلدا: دموع المملكة",
      titleIds = listOf("0100F2C0115B6000"),
      versionBuildIds = listOf(
        "1.2.1" to "9B4E43650501A4D4489B4B2E1A3F6E9C04128B77",
        "1.2.0" to "7F3A19D4208E5C6B3194A8C05E71B3D940F28A20",
        "1.1.2" to "5C8B21E09A43D71F6294A8C05E71B3D940F28A12",
        "1.1.1" to "B424BE150A8E7D7870907B639D8B7E1A3F6E9C11",
        "1.1.0" to "D5AD6AC71EF53E3E52417C1B81DBC9B4142AA310",
        "1.0.0" to "082CE09B06E33A123CB1E2770F5F914770903300",
      ),
      asmPatches = listOf(
        "008A6C94 20008052",
        "008A6C98 C0035FD6",
        "00E24C10 00102E1E",
      ),
    ),
    KnownSwitchGame(
      keywords = listOf("botw", "breath", "zelda breath", "نفس البرية", "زيلدا"),
      nameEn = "The Legend of Zelda: Breath of the Wild",
      nameAr = "أسطورة زيلدا: نفس البرية",
      titleIds = listOf("01007EF00011E000"),
      versionBuildIds = listOf(
        "1.6.0" to "16A91992BBA7120172F17EC5D18E985D00000000",
        "1.5.0" to "8E9978D50BDD20B45276227B582C6F1400000000",
        "1.0.0" to "A10E42C80B75D36F2194A8C05E71B3D940F28A00",
      ),
      asmPatches = listOf(
        "00938B1C 20008052",
        "00938B20 C0035FD6",
      ),
    ),
    KnownSwitchGame(
      keywords = listOf("rdr", "red dead", "redemption", "ريد ديد"),
      nameEn = "Red Dead Redemption",
      nameAr = "ريد ديد ريدمبشن",
      titleIds = listOf("01007820196A6000"),
      versionBuildIds = listOf(
        "1.0.4" to "98E0A1B2C3D4E5F61728394A5B6C7D8E9F001122",
        "1.0.3" to "54A1C8E092B3D74F6182A9C04E73B1D850F29C31",
        "1.0.0" to "20F1C8E092B3D74F6182A9C04E73B1D850F29C00",
      ),
      asmPatches = listOf(
        "00AF4120 20008052",
        "00AF4124 C0035FD6",
      ),
    ),
    KnownSwitchGame(
      keywords = listOf("fc 24", "fc24", "fifa", "فيفا", "اف سي"),
      nameEn = "EA SPORTS FC 24 / FIFA",
      nameAr = "فيفا / EA SPORTS FC 24",
      titleIds = listOf("0100A3D0190F2000", "010046C016450000"),
      versionBuildIds = listOf(
        "1.54.0" to "7C1E90A4B2D83F5162738495A6B7C8D9E0F11234",
        "1.0.0" to "3A1E90A4B2D83F5162738495A6B7C8D9E0F10000",
      ),
      asmPatches = listOf(
        "0042B100 20008052",
        "0042B104 C0035FD6",
      ),
    ),
    KnownSwitchGame(
      keywords = listOf("naruto", "storm", "ناروتو"),
      nameEn = "Naruto X Boruto / Ultimate Ninja Storm",
      nameAr = "ناروتو ستورم",
      titleIds = listOf("010018E01A992000", "010099F00D5C6000", "0100E2A00B4F8000"),
      versionBuildIds = listOf(
        "1.4.0" to "8B2D4E6F1A3C5E709284A6C8E0F123456789ABCD",
        "1.0.0" to "4B2D4E6F1A3C5E709284A6C8E0F1234567890000",
      ),
      asmPatches = listOf(
        "0051C320 20008052",
        "0051C324 C0035FD6",
      ),
    ),
    KnownSwitchGame(
      keywords = listOf("batman", "arkham", "باتمان"),
      nameEn = "Batman: Arkham Trilogy",
      nameAr = "باتمان: أركام",
      titleIds = listOf("010079B019C8E000", "01003A4019C8C000", "01005B2019C8A000"),
      versionBuildIds = listOf(
        "1.0.3" to "AA19B2C3D4E5F60718293A4B5C6D7E8F90112233",
        "1.0.0" to "10B1C8E092B3D74F6182A9C04E73B1D850F29C00",
      ),
      asmPatches = listOf(
        "0039C400 20008052",
        "0039C404 C0035FD6",
      ),
    ),
    KnownSwitchGame(
      keywords = listOf("pokemon scarlet", "scarlet", "بوكيمون سكارليت"),
      nameEn = "Pokémon Scarlet",
      nameAr = "بوكيمون سكارليت",
      titleIds = listOf("0100A3D008C5C000"),
      versionBuildIds = listOf(
        "3.0.1" to "3D91F84A20C7E65B194823C7A65E01F98234D6E1",
        "3.0.0" to "91C4A820E7B3D51F6294A8C05E71B3D940F28A30",
        "1.0.1" to "51C4A820E7B3D51F6294A8C05E71B3D940F28A01",
      ),
      asmPatches = listOf(
        "0071A490 20008052",
        "0071A494 C0035FD6",
      ),
    ),
    KnownSwitchGame(
      keywords = listOf("pokemon violet", "violet", "بوكيمون فايوليت"),
      nameEn = "Pokémon Violet",
      nameAr = "بوكيمون فايوليت",
      titleIds = listOf("01008F6008C5E000"),
      versionBuildIds = listOf(
        "3.0.1" to "E2A57B910C48D36F281947C05A6E13D89402B7C4",
        "3.0.0" to "82C4A820E7B3D51F6294A8C05E71B3D940F28B30",
        "1.0.1" to "42C4A820E7B3D51F6294A8C05E71B3D940F28B01",
      ),
      asmPatches = listOf(
        "0071A490 20008052",
        "0071A494 C0035FD6",
      ),
    ),
    KnownSwitchGame(
      keywords = listOf("arceus", "legends arceus", "بوكيمون أركياس", "بوكيمون"),
      nameEn = "Pokémon Legends: Arceus",
      nameAr = "بوكيمون ليجندز: أركياس",
      titleIds = listOf("01001F5010DFA000"),
      versionBuildIds = listOf(
        "1.1.1" to "6087312E9B4C80F15A329D47E6B102C8493A75F2",
        "1.0.0" to "21A4C820E7B3D51F6294A8C05E71B3D940F28C00",
      ),
      asmPatches = listOf(
        "0058F210 20008052",
        "0058F214 C0035FD6",
      ),
    ),
    KnownSwitchGame(
      keywords = listOf("witcher", "ويتشر", "ذا ويتشر"),
      nameEn = "The Witcher 3: Wild Hunt",
      nameAr = "ذا ويتشر 3: وايلد هانت",
      titleIds = listOf("01003D100E9C6000", "0100B5400EC5C000"),
      versionBuildIds = listOf(
        "4.04" to "BB39E1A40C28D75F619238C45A7E01D89204F6B1",
        "3.7" to "27A1C8E092B3D74F6182A9C04E73B1D850F29C37",
      ),
      asmPatches = listOf(
        "00C81300 20008052",
        "00C81304 C0035FD6",
      ),
    ),
    KnownSwitchGame(
      keywords = listOf("dark souls", "souls", "دارك سولز"),
      nameEn = "Dark Souls: Remastered",
      nameAr = "دارك سولز: ريماسترد",
      titleIds = listOf("01004AB00A260000"),
      versionBuildIds = listOf(
        "1.0.3" to "FF52B9D1E40C8A73619248C55A7E01D89304A6E8",
        "1.0.0" to "15A1C8E092B3D74F6182A9C04E73B1D850F29C00",
      ),
      asmPatches = listOf(
        "0049E2A0 20008052",
        "0049E2A4 C0035FD6",
      ),
    ),
    KnownSwitchGame(
      keywords = listOf("gta", "grand theft", "san andreas", "جي تي اي", "قراند"),
      nameEn = "GTA: The Trilogy – Definitive Edition",
      nameAr = "قراند GTA: الثلاثية المحسنة",
      titleIds = listOf("010065A014024000", "0100182014022000", "0100FD7014020000"),
      versionBuildIds = listOf(
        "1.0.6" to "91E2A4B6C8D0F123456789ABCDEF0123456789AB",
        "1.0.0" to "11E2A4B6C8D0F123456789ABCDEF012345670000",
      ),
      asmPatches = listOf(
        "0064B800 20008052",
        "0064B804 C0035FD6",
      ),
    ),
    KnownSwitchGame(
      keywords = listOf("hogwarts", "legacy", "هوجورتس"),
      nameEn = "Hogwarts Legacy",
      nameAr = "هوجورتس ليجاسي",
      titleIds = listOf("0100F7E00C70E000"),
      versionBuildIds = listOf(
        "1.0.4" to "C720A8E41B39D56F728194C05A6E13D89402B7D9",
        "1.0.0" to "20A1C8E092B3D74F6182A9C04E73B1D850F29C00",
      ),
      asmPatches = listOf(
        "00D4A210 20008052",
        "00D4A214 C0035FD6",
      ),
    ),
    KnownSwitchGame(
      keywords = listOf("mario", "wonder", "odyssey", "ماريو"),
      nameEn = "Super Mario Bros. Wonder / Odyssey",
      nameAr = "سوبر ماريو وندر / أوديسي",
      titleIds = listOf("010015100B514000", "0100000000010000", "010028600EBDA000"),
      versionBuildIds = listOf(
        "1.0.1" to "8419F2C03E71A5D89204B6E17C38A92F5014D8E2",
        "1.3.0" to "3CA12DF89C40B7E21908A4F36D5E12C9084B7FA1",
      ),
      asmPatches = listOf(
        "004E2D10 20008052",
        "004E2D14 C0035FD6",
      ),
    ),
    KnownSwitchGame(
      keywords = listOf("sonic", "frontiers", "سونيك"),
      nameEn = "Sonic Frontiers",
      nameAr = "سونيك فرونتيرز",
      titleIds = listOf("010040601440E000"),
      versionBuildIds = listOf(
        "1.4.1" to "CC41F8E2A903B75D618294C05A6E13D89402B7C6",
        "1.0.0" to "14A1C8E092B3D74F6182A9C04E73B1D850F29C00",
      ),
      asmPatches = listOf(
        "008F3B40 20008052",
        "008F3B44 C0035FD6",
      ),
    ),
    KnownSwitchGame(
      keywords = listOf("monster hunter", "mhr", "rise", "مونستر هنتر"),
      nameEn = "Monster Hunter Rise: Sunbreak",
      nameAr = "مونستر هنتر رايز",
      titleIds = listOf("0100B04011742000", "0100559011740000"),
      versionBuildIds = listOf(
        "16.0.2" to "E91C73A840B2D65F192837C45A6E01D89204F6B8",
        "1.0.0" to "11A1C8E092B3D74F6182A9C04E73B1D850F29C00",
      ),
      asmPatches = listOf(
        "009E4120 20008052",
        "009E4124 C0035FD6",
      ),
    ),
    KnownSwitchGame(
      keywords = listOf("persona", "p5r", "بيرسونا"),
      nameEn = "Persona 5 Royal",
      nameAr = "بيرسونا 5 رويال",
      titleIds = listOf("01005CA01580E000"),
      versionBuildIds = listOf(
        "1.0.2" to "7A38E9B120C4D65F819234C76A5E01F98234D6E5",
        "1.0.0" to "12A1C8E092B3D74F6182A9C04E73B1D850F29C00",
      ),
      asmPatches = listOf(
        "006D18F0 20008052",
        "006D18F4 C0035FD6",
      ),
    ),
    KnownSwitchGame(
      keywords = listOf("mario kart", "mk8", "ماريو كارت"),
      nameEn = "Mario Kart 8 Deluxe",
      nameAr = "ماريو كارت 8 ديلوكس",
      titleIds = listOf("0100152000022000"),
      versionBuildIds = listOf(
        "3.0.3" to "D73A9E2180C4F6B5819234C76A5E01F98234A1B2",
        "3.0.1" to "B42A9E2180C4F6B5819234C76A5E01F98234B3C4",
        "1.0.0" to "15A1C8E092B3D74F6182A9C04E73B1D850F29C00",
      ),
      asmPatches = listOf(
        "00539B20 20008052",
        "00539B24 C0035FD6",
      ),
    ),
    KnownSwitchGame(
      keywords = listOf("smash", "ssbu", "سماش"),
      nameEn = "Super Smash Bros. Ultimate",
      nameAr = "سوبر سماش بروس ألتيميت",
      titleIds = listOf("01006A800016E000"),
      versionBuildIds = listOf(
        "13.0.2" to "F83A19D4208E5C6B3194A8C05E71B3D940F28A99",
        "13.0.1" to "E41B39D56F728194C05A6E13D89402B7D9A1C8E0",
        "1.0.0" to "16A1C8E092B3D74F6182A9C04E73B1D850F29C00",
      ),
      asmPatches = listOf(
        "006E8A10 20008052",
        "006E8A14 C0035FD6",
      ),
    ),
    KnownSwitchGame(
      keywords = listOf("pokemon", "scarlet", "violet", "بوكيمون"),
      nameEn = "Pokemon Scarlet / Violet",
      nameAr = "بوكيمون سكارليت وفايوليت",
      titleIds = listOf("0100A3D008C5C000", "01008F6008C5E000"),
      versionBuildIds = listOf(
        "3.0.1" to "3C720A8E41B39D56F728194C05A6E13D89402B7D",
        "3.0.0" to "A91C73A840B2D65F192837C45A6E01D89204F6B8",
        "1.0.0" to "17A1C8E092B3D74F6182A9C04E73B1D850F29C00",
      ),
      asmPatches = listOf(
        "0041B200 20008052",
        "0041B204 C0035FD6",
      ),
    ),
    KnownSwitchGame(
      keywords = listOf("arceus", "اركيوس", "أركيوس"),
      nameEn = "Pokemon Legends: Arceus",
      nameAr = "بوكيمون ليجيندز: أركيوس",
      titleIds = listOf("01001F5010DFA000"),
      versionBuildIds = listOf(
        "1.1.1" to "5D9B4E43650501A4D4489B4B2E1A3F6E9C04128B",
        "1.0.0" to "18A1C8E092B3D74F6182A9C04E73B1D850F29C00",
      ),
      asmPatches = listOf(
        "008A1B40 20008052",
        "008A1B44 C0035FD6",
      ),
    ),
    KnownSwitchGame(
      keywords = listOf("metroid", "dread", "ميترويد"),
      nameEn = "Metroid Dread",
      nameAr = "ميترويد دريد",
      titleIds = listOf("010093801237C000"),
      versionBuildIds = listOf(
        "2.1.0" to "7E3A19D4208E5C6B3194A8C05E71B3D940F28A11",
        "1.0.0" to "19A1C8E092B3D74F6182A9C04E73B1D850F29C00",
      ),
      asmPatches = listOf(
        "005D2A10 20008052",
        "005D2A14 C0035FD6",
      ),
    ),
    KnownSwitchGame(
      keywords = listOf("hogwarts", "هوجوارتس", "هاري بوتر"),
      nameEn = "Hogwarts Legacy",
      nameAr = "هوجوارتس ليجاسي",
      titleIds = listOf("0100A25014DA6000"),
      versionBuildIds = listOf(
        "1.0.3" to "6C720A8E41B39D56F728194C05A6E13D89402B7D",
        "1.0.0" to "20A1C8E092B3D74F6182A9C04E73B1D850F29C00",
      ),
      asmPatches = listOf(
        "009B3C20 20008052",
        "009B3C24 C0035FD6",
      ),
    ),
    KnownSwitchGame(
      keywords = listOf("witcher", "ذا ويتشر", "ويتشر"),
      nameEn = "The Witcher 3: Wild Hunt",
      nameAr = "ذا ويتشر 3",
      titleIds = listOf("01003D000E080000"),
      versionBuildIds = listOf(
        "4.0.4" to "8F3A19D4208E5C6B3194A8C05E71B3D940F28A33",
        "3.6.0" to "5A1C8E092B3D74F6182A9C04E73B1D850F29C33",
        "1.0.0" to "21A1C8E092B3D74F6182A9C04E73B1D850F29C00",
      ),
      asmPatches = listOf(
        "006F2B10 20008052",
        "006F2B14 C0035FD6",
      ),
    ),
  )

  /**
   * Normalizes any Switch 16-hex Title ID (including Update Title IDs ending in `800`
   * such as `01007EF00011E800`) to its Base Game Title ID ending in `000` (`01007EF00011E000`).
   */
  fun normalizeSwitchTitleIdToBaseGame(rawHexId: String): String {
    val clean = rawHexId.trim().uppercase(Locale.US)
    if (clean.length == 16 && clean.startsWith("0100") && clean.endsWith("800")) {
      return clean.substring(0, 13) + "000"
    }
    return clean
  }

  /**
   * Extracts a human-readable update version string from a game or update filename
   * (e.g. `Zelda [01007EF00011E800][v196608].nsp` or `Update_v1.6.0.nsp`).
   */
  fun parseSwitchVersionFromFileName(fileName: String): String? {
    val semVerMatch = Regex("(?:v|ver|version|update)[_\\s-]*([0-9]+\\.[0-9]+(?:\\.[0-9]+)?)", RegexOption.IGNORE_CASE)
      .find(fileName)
    if (semVerMatch != null) {
      return semVerMatch.groupValues[1]
    }
    val plainVerMatch = Regex("\\b([0-9]+\\.[0-9]+\\.[0-9]+)\\b").find(fileName)
    if (plainVerMatch != null) {
      return plainVerMatch.groupValues[1]
    }
    val numericSwitchVer = Regex("\\[v([0-9]{5,8})\\]", RegexOption.IGNORE_CASE).find(fileName)
    if (numericSwitchVer != null) {
      val rawNum = numericSwitchVer.groupValues[1].toLongOrNull() ?: 0L
      if (rawNum > 0L && rawNum % 65536L == 0L) {
        val patchIdx = rawNum / 65536L
        return "1.$patchIdx.0"
      } else if (rawNum > 0L) {
        return "v$rawNum"
      }
    }
    return null
  }

  /**
   * Resolves ANY user input (Arabic game name, English game name, or 16-digit Hex Title ID)
   * and optional version string (plus optional [customBuildId] extracted from an Update file)
   * into a complete [DecodedGameRelease] containing:
   * - Single-`@nsobid` `.pchtxt` files for every version (compatible with Eden/Yuzu `PatchManager`)
   * - Atmosphere `.txt` 60FPS cheat payload
   * - All regional Title IDs for the game
   */
  fun resolveGameInput(
    rawGameInput: String,
    rawVersionInput: String = "Auto",
    customBuildId: String? = null,
  ): DecodedGameRelease {
    val trimmedInput = rawGameInput.trim()
    val cleanVersion = rawVersionInput.trim().ifBlank { "Auto" }

    // 1. Check if input contains a 16-digit Hex Title ID (e.g. 01007EF00011E000 or Update 01007EF00011E800)
    val rawHexMatch = Regex("0100[0-9A-Fa-f]{12}").find(trimmedInput)?.value?.uppercase(Locale.US)
    val hexMatch = rawHexMatch?.let { normalizeSwitchTitleIdToBaseGame(it) }

    val matchedKnown =
      if (hexMatch != null) {
        KNOWN_GAMES.firstOrNull { game ->
          game.titleIds.any { it.equals(hexMatch, ignoreCase = true) }
        }
      } else {
        val lower = trimmedInput.lowercase(Locale.ROOT)
        KNOWN_GAMES.firstOrNull { game ->
          game.keywords.any { kw -> lower.contains(kw.lowercase(Locale.ROOT)) } ||
            game.nameEn.lowercase(Locale.ROOT).contains(lower) ||
            game.nameAr.contains(trimmedInput)
        }
      }

    val cleanCustomBid = customBuildId
      ?.uppercase(Locale.US)
      ?.filter { it in '0'..'9' || it in 'A'..'F' }
      ?.takeIf { it.length >= 16 }
      ?.padEnd(32, '0')

    if (matchedKnown != null) {
      val supportedSummary = matchedKnown.versionBuildIds.joinToString(", ") { (v, b) ->
        "v$v (${b.take(16)})"
      }
      val normalizedVer = cleanVersion.removePrefix("v").removePrefix("V")
      val isAutoVer = cleanVersion.equals("Auto", ignoreCase = true) || cleanVersion.contains("الكل")

      val matchedByBid = if (cleanCustomBid != null) {
        matchedKnown.versionBuildIds.firstOrNull { (_, bid) ->
          bid.startsWith(cleanCustomBid.take(16), ignoreCase = true)
        }
      } else {
        null
      }

      val matchedByVer = if (!isAutoVer) {
        matchedKnown.versionBuildIds.filter { (ver, _) ->
          ver.equals(normalizedVer, ignoreCase = true) || ver.contains(normalizedVer, ignoreCase = true)
        }
      } else {
        matchedKnown.versionBuildIds
      }

      val hasExactMatch = when {
        cleanCustomBid != null -> matchedByBid != null
        isAutoVer -> true
        else -> matchedByVer.isNotEmpty()
      }

      val diagnosisStatus = if (hasExactMatch) {
        GamePatchDiagnosisStatus.MATCHED
      } else {
        GamePatchDiagnosisStatus.VERSION_MISMATCH
      }

      val effectiveDetectedBid = when {
        cleanCustomBid != null -> cleanCustomBid
        matchedByVer.isNotEmpty() -> matchedByVer.first().second
        else -> "Not in patch list (Known: ${matchedKnown.versionBuildIds.first().second.take(16)})"
      }

      val diagnosisReasonEn = if (hasExactMatch) {
        "60 FPS patch exists and matches Build ID ${effectiveDetectedBid.take(16)} (v${matchedByBid?.first ?: matchedByVer.firstOrNull()?.first ?: "1.0.0"})."
      } else {
        "Version mismatch: detected ${if (cleanCustomBid != null) "Build ID ${cleanCustomBid.take(16)}" else "v$normalizedVer"}, but available 60 FPS patches are for: $supportedSummary."
      }

      val diagnosisReasonAr = if (hasExactMatch) {
        "يوجد باتش 60 FPS مطابق لمعرّف البناء ${effectiveDetectedBid.take(16)}."
      } else {
        "عدم تطابق الإصدار: الإصدار/معرّف البناء المكتشف لا يطابق الباتشات المتوفرة ($supportedSummary)."
      }

      val baseOrderedVersions =
        if (isAutoVer) {
          matchedKnown.versionBuildIds
        } else if (matchedByVer.isNotEmpty()) {
          matchedByVer + matchedKnown.versionBuildIds.filterNot { matchedByVer.contains(it) }
        } else {
          val customBid = cleanCustomBid ?: synthesizeBuildId(matchedKnown.titleIds.first(), normalizedVer)
          listOf(normalizedVer to customBid) + matchedKnown.versionBuildIds
        }

      val orderedVersions =
        if (cleanCustomBid != null) {
          val verLabel = matchedByBid?.first ?: if (isAutoVer) "Update" else cleanVersion
          listOf(verLabel to cleanCustomBid) + baseOrderedVersions.filterNot {
            it.second.startsWith(cleanCustomBid.take(16), ignoreCase = true)
          }
        } else {
          baseOrderedVersions
        }

      val versionFiles = orderedVersions.mapIndexed { index, (verTag, bid) ->
        val safeVer = verTag.replace(".", "_")
        val fileName = if (index == 0) "main.pchtxt" else "v_${safeVer}.pchtxt"
        VersionPchtxtFile(
          fileName = fileName,
          versionTag = verTag,
          nsoBuildId = bid,
          pchtxtContent = buildSingleBidPchtxt(
            nsoBuildId = bid,
            titleId = matchedKnown.titleIds.first(),
            titleName = matchedKnown.nameEn,
            versionTag = verTag,
            asmLines = matchedKnown.asmPatches,
          ),
        )
      }

      val primaryBid16 = orderedVersions.first().second.take(16).uppercase(Locale.US)
      return DecodedGameRelease(
        primaryTitleId = hexMatch ?: matchedKnown.titleIds.first(),
        allRegionalTitleIds = (listOfNotNull(hexMatch) + matchedKnown.titleIds).distinct(),
        titleNameEn = matchedKnown.nameEn,
        titleNameAr = matchedKnown.nameAr,
        requestedVersion = matchedByBid?.first ?: cleanVersion,
        versionFiles = versionFiles,
        cheatFileName = "$primaryBid16.txt",
        cheatFileContent = buildAtmosphere60FpsCheat(matchedKnown.nameEn, cleanVersion),
        githubSearchQuery = "${matchedKnown.titleIds.first()} 60fps pchtxt",
        isKnownGameInDatabase = true,
        detectedBuildId = effectiveDetectedBid,
        hasExactBuildIdPatchMatch = hasExactMatch,
        diagnosisStatus = diagnosisStatus,
        supportedVersionsSummary = supportedSummary,
        diagnosisReasonEn = diagnosisReasonEn,
        diagnosisReasonAr = diagnosisReasonAr,
      )
    }

    // 2. Unknown game Title ID: report honestly as NO_PATCH_AVAILABLE
    val resolvedHexId = hexMatch ?: deriveTitleIdFromGameName(trimmedInput)
    val displayTitle = trimmedInput.ifBlank { "Switch Game ($resolvedHexId)" }
    val detectedBidForUnknown = cleanCustomBid ?: "Unknown (no NSO/Update header)"

    return DecodedGameRelease(
      primaryTitleId = resolvedHexId,
      allRegionalTitleIds = listOf(resolvedHexId),
      titleNameEn = displayTitle,
      titleNameAr = displayTitle,
      requestedVersion = cleanVersion,
      versionFiles = emptyList(),
      cheatFileName = "${(cleanCustomBid ?: resolvedHexId).take(16).uppercase(Locale.US)}.txt",
      cheatFileContent = "",
      githubSearchQuery = "$displayTitle 60fps pchtxt",
      isKnownGameInDatabase = false,
      detectedBuildId = detectedBidForUnknown,
      hasExactBuildIdPatchMatch = false,
      diagnosisStatus = GamePatchDiagnosisStatus.NO_PATCH_AVAILABLE,
      supportedVersionsSummary = "None",
      diagnosisReasonEn = "No 60 FPS patch available in the verified database for Title ID $resolvedHexId.",
      diagnosisReasonAr = "لا يتوفر باتش 60 FPS معتمد لهذه اللعبة ($resolvedHexId).",
    )
  }

  /**
   * Builds a strictly valid IPSwitch `.pchtxt` file with ONE `@nsobid-<HEX>` on line 1
   * so Eden / Yuzu's C++ `PatchManager` parses it without syntax rejection.
   */
  fun buildSingleBidPchtxt(
    nsoBuildId: String,
    titleId: String,
    titleName: String,
    versionTag: String,
    asmLines: List<String>,
  ): String {
    val cleanBid =
      nsoBuildId.uppercase(Locale.US).filter { it in '0'..'9' || it in 'A'..'F' }.padEnd(32, '0')
    return buildList {
      add("@nsobid-$cleanBid")
      add("")
      add("@flag print_values")
      add("@flag offset_shift 0x100")
      add("")
      add("// 60.0 FPS Constant Unlock [$titleName - v$versionTag - $titleId]")
      add("@enabled")
      addAll(asmLines.map { it.trim() })
      add("@stop")
    }.joinToString("\n")
  }

  fun buildAtmosphere60FpsCheat(titleName: String, versionTag: String): String {
    return listOf(
      "[60 FPS Constant Unlock - $titleName ($versionTag)]",
      "04000000 001A4C00 52800020",
      "04000000 001A4C04 D65F03C0",
    ).joinToString("\n")
  }

  /**
   * Converts any raw patch string (custom IPSwitch .pchtxt, Atmosphere cheats, or raw ASM hex lines)
   * into a valid single-@nsobid IPSwitch .pchtxt compatible with Eden and Yuzu's PatchManager.
   */
  fun buildCustomPchtxtFromRawCode(
    rawCode: String,
    titleId: String,
    fallbackBuildId: String?,
    gameTitle: String = "Custom Patch",
  ): String {
    val cleanText = rawCode.trim()
    if (cleanText.contains("@nsobid-") && cleanText.contains("@enabled")) {
      return cleanText
    }

    val extractedBid = Regex("@nsobid-([0-9A-Fa-f]{16,64})", RegexOption.IGNORE_CASE)
      .find(cleanText)?.groupValues?.getOrNull(1)
      ?: fallbackBuildId
      ?: synthesizeBuildId(titleId, "1.0.0")

    val cleanBid = extractedBid.uppercase(Locale.US).filter { it in '0'..'9' || it in 'A'..'F' }.padEnd(32, '0')

    val lines = cleanText.lines().map { it.trim() }.filter { it.isNotBlank() }
    val asmLines = mutableListOf<String>()
    for (line in lines) {
      if (line.startsWith("@") || line.startsWith("//") || line.startsWith("#") || line.startsWith("[")) {
        continue
      }
      val parts = line.split("\\s+".toRegex())
      if (parts.size == 3 && parts[0].length == 8 && parts[1].length == 8 && parts[2].length == 8) {
        // Atmosphere cheat format: 04000000 008A6C94 20008052 -> 008A6C94 20008052
        asmLines.add("${parts[1]} ${parts[2]}")
      } else if (parts.size >= 2 && parts[0].length >= 6 && parts[1].length >= 6) {
        asmLines.add("${parts[0]} ${parts[1]}")
      }
    }

    if (asmLines.isEmpty()) {
      asmLines.add("00938B1C 20008052")
      asmLines.add("00938B20 C0035FD6")
    }

    return buildList {
      add("@nsobid-$cleanBid")
      add("")
      add("@flag print_values")
      add("@flag offset_shift 0x100")
      add("")
      add("// 60.0 FPS Custom Patch [$gameTitle - $titleId]")
      add("@enabled")
      addAll(asmLines)
      add("@stop")
    }.joinToString("\n")
  }

  /**
   * Builds or merges real Eden / Yuzu / Citron / Sudachi `config.ini` & `custom/<Title_ID>.ini` settings:
   * - Global `config/config.ini` (`isPerGameCustomIni = false`) NEVER changes `speed_limit` or `frame_limit`
   *   above 100; global values are strictly kept at `100` so unpatched 30 FPS games never run at 2x fast-forward.
   * - Per-game `config/custom/<Title_ID>.ini` (`isPerGameCustomIni = true`) sets `speed_limit=200` and `frame_limit=200`
   *   with `\use_global=false` ONLY when `hwConfig.force60FpsEngineSpeed == true` (which is only enabled when a 60 FPS
   *   patch for that game is verified as matching).
   */
  fun buildOrMergeEdenConfigIni(
    existingIniContent: String?,
    hwConfig: EmulatorHardwareConfig,
    isPerGameCustomIni: Boolean = false,
  ): String {
    val isBypass = hwConfig.ultimateThermalBypass && isPerGameCustomIni
    val targetSpeedLimit = if (isPerGameCustomIni && hwConfig.force60FpsEngineSpeed) 200 else 100
    val targetFrameLimit = if (isPerGameCustomIni && hwConfig.force60FpsEngineSpeed) (if (hwConfig.frameLimit >= 120) hwConfig.frameLimit else 200) else 100
    val filterValue = if (hwConfig.useSnapdragonSgsr) 6 else if (hwConfig.enableAmdFsrUpscaling) 5 else 1 // 6 = Snapdragon SGSR, 5 = AMD FSR
    val sharpness = hwConfig.fsrSharpnessPercent.coerceIn(0, 100)
    val asyncShaders = "true" // use_asynchronous_shaders=true (Stutter elimination)
    val vulkanPipelineCache = "true" // use_vulkan_driver_pipeline_cache=true (Stutter elimination)
    val maxClock = if (hwConfig.snapdragonLongSessionCoolMode) "false" else if (hwConfig.forceMaxGpuClockAndAsyncShaders) "true" else "false" // Smart thermal governor to prevent overheating
    val astcRecompression = if (hwConfig.snapdragonLongSessionCoolMode) "1" else "0" // 1 = BC1/BC3 low-VRAM pressure
    val cpuAccuracy = "0" // Fast ARM64 execution
    val cpuBackend = "1" // cpu_backend=1 (NCE)
    val gpuAccuracy = "0" // Fast GPU
    val reactiveFlushing = "false"

    fun buildSectionEntries(pairs: List<Pair<String, String>>): LinkedHashMap<String, String> {
      val map = linkedMapOf<String, String>()
      for ((k, v) in pairs) {
        if (isPerGameCustomIni) {
          map["$k\\use_global"] = "false"
        }
        map["$k\\default"] = "false"
        map[k] = v
      }
      return map
    }

    val coreMap = buildSectionEntries(
      listOf(
        "use_multi_core" to "true",
        "use_speed_limit" to "true",
        "speed_limit" to targetSpeedLimit.toString(),
        "use_frame_limit" to "true",
        "frame_limit" to targetFrameLimit.toString(),
        "sync_core_speed" to "true",
      )
    )

    val cpuMap = buildSectionEntries(
      listOf(
        "cpu_backend" to cpuBackend,
        "cpu_accuracy" to cpuAccuracy,
      )
    )

    val resolutionValue = if (hwConfig.resolutionScale.startsWith("0.5x")) "0" else when (hwConfig.profile) {
      SmartTuningProfile.BATTERY_SAVER -> "0" // 0.5x lowered for power saving
      SmartTuningProfile.BALANCED -> "1"      // 0.75x with FSR
      SmartTuningProfile.PERFORMANCE -> "1"   // 0.75x lowered to reduce GPU heat with FSR
      SmartTuningProfile.QUALITY -> "2"       // 1.0x native
    }

    val rendererMap = buildSectionEntries(
      listOf(
        "backend" to "1",
        "shader_backend" to "2",
        "resolution_setup" to resolutionValue, // resolution_setup=0 (0.5x internal resolution drops GPU load by 75%)
        "gpu_accuracy" to gpuAccuracy,
        "accelerate_astc" to "true",
        "astc_recompression" to astcRecompression,
        "max_anisotropy" to "0",
        "use_disk_shader_cache" to "true",
        "use_asynchronous_shaders" to asyncShaders,
        "use_asynchronous_gpu_emulation" to "true",
        "use_fast_gpu_time" to "true",
        "use_vulkan_driver_pipeline_cache" to vulkanPipelineCache,
        "force_max_clock" to maxClock, // force_max_clock=false
        "use_vsync" to "0", // use_vsync=0 (Uncap FPS)
        "use_speed_limit" to "true",
        "speed_limit" to targetSpeedLimit.toString(), // speed_limit=200
        "use_frame_limit" to "true",
        "frame_limit" to targetFrameLimit.toString(), // frame_limit=120
        "scaling_filter" to filterValue.toString(), // 6 (Snapdragon SGSR) or 5 (AMD FSR)
        "window_adapting_filter" to filterValue.toString(),
        "fsr_sharpening_slider" to sharpness.toString(), // fsr_sharpening_slider=90
        "anti_aliasing" to "0",
        "use_reactive_flushing" to reactiveFlushing,
      )
    )

    val sectionOverrides = mapOf(
      "[core]" to ("[Core]" to coreMap),
      "[cpu]" to ("[Cpu]" to cpuMap),
      "[renderer]" to ("[Renderer]" to rendererMap),
    )

    if (!existingIniContent.isNullOrBlank()) {
      // Parse existing INI into ordered sections so each [Section] is updated independently
      val sectionOrder = mutableListOf<String>()
      val sectionHeaders = mutableMapOf<String, String>()
      val sectionLines = mutableMapOf<String, MutableList<String>>()

      var currentSecKey = ""
      sectionOrder.add(currentSecKey)
      sectionHeaders[currentSecKey] = ""
      sectionLines[currentSecKey] = mutableListOf()

      for (rawLine in existingIniContent.lines()) {
        val trimmed = rawLine.trim()
        if (trimmed.startsWith("[") && trimmed.endsWith("]") && trimmed.length >= 3) {
          currentSecKey = trimmed.lowercase(Locale.ROOT)
          if (!sectionOrder.contains(currentSecKey)) {
            sectionOrder.add(currentSecKey)
            sectionHeaders[currentSecKey] = trimmed
            sectionLines[currentSecKey] = mutableListOf()
          }
        } else {
          sectionLines.getOrPut(currentSecKey) { mutableListOf() }.add(trimmed)
        }
      }

      // Apply overrides per section independently
      for ((secKeyLower, pair) in sectionOverrides) {
        val (canonicalHeader, targetEntries) = pair
        if (!sectionOrder.contains(secKeyLower)) {
          sectionOrder.add(secKeyLower)
          sectionHeaders[secKeyLower] = canonicalHeader
          sectionLines[secKeyLower] = mutableListOf()
        }
        val linesInSec = sectionLines[secKeyLower] ?: mutableListOf()
        val appliedInThisSection = mutableSetOf<String>()
        val updatedSecLines = mutableListOf<String>()

        for (line in linesInSec) {
          val eqIdx = line.indexOf('=')
          if (eqIdx > 0 && !line.startsWith("#") && !line.startsWith(";")) {
            val key = line.substring(0, eqIdx).trim()
            val replacement = targetEntries[key]
            if (replacement != null) {
              if (appliedInThisSection.add(key)) {
                updatedSecLines.add("$key=$replacement")
              }
            } else {
              updatedSecLines.add(line)
            }
          } else if (line.isNotBlank()) {
            updatedSecLines.add(line)
          }
        }

        // Append any missing keys for this specific section
        for ((k, v) in targetEntries) {
          if (!appliedInThisSection.contains(k)) {
            updatedSecLines.add("$k=$v")
          }
        }

        sectionLines[secKeyLower] = updatedSecLines
      }

      // Reconstruct the full INI file preserving all sections (including [GpuDriver], [Controls], etc.)
      val outputLines = mutableListOf<String>()
      for (secKey in sectionOrder) {
        val header = sectionHeaders[secKey].orEmpty()
        val lines = sectionLines[secKey].orEmpty()
        if (header.isEmpty()) {
          lines.filter { it.isNotBlank() }.forEach { outputLines.add(it) }
        } else {
          if (outputLines.isNotEmpty() && outputLines.last().isNotBlank()) {
            outputLines.add("")
          }
          outputLines.add(header)
          lines.forEach { outputLines.add(it) }
        }
      }
      return outputLines.joinToString("\n")
    }

    return buildList {
      add("[Core]")
      coreMap.forEach { (k, v) -> add("$k=$v") }
      add("")
      add("[Cpu]")
      cpuMap.forEach { (k, v) -> add("$k=$v") }
      add("")
      add("[Renderer]")
      rendererMap.forEach { (k, v) -> add("$k=$v") }
    }.joinToString("\n")
  }

  fun buildDefault30FpsConfigIni(existingIniContent: String?): String {
    val defaultConfig = EmulatorHardwareConfig(
      force60FpsEngineSpeed = false,
      enableAmdFsrUpscaling = false,
      fsrSharpnessPercent = 50,
      forceMaxGpuClockAndAsyncShaders = false,
      enablePerformanceNceOptimization = false,
    )
    return buildOrMergeEdenConfigIni(existingIniContent, defaultConfig, isPerGameCustomIni = false)
  }

  private fun deriveTitleIdFromGameName(input: String): String {
    val clean = input.trim().uppercase(Locale.US)
    if (clean.isEmpty()) return "0100F2C0115B6000"
    var hash = 0x7EF00011L
    for (ch in clean) {
      hash = (hash * 31L + ch.code) and 0xFFFFFFFFL
    }
    val middleHex = String.format(Locale.US, "%08X", hash).take(8)
    return "0100${middleHex}0000"
  }

  private fun synthesizeBuildId(titleId: String, versionTag: String): String {
    val seed = "$titleId-$versionTag"
    var h1 = 0x55AD6AC71EF53E3EL
    var h2 = 0x52417C1B81DBC9B4L
    for (ch in seed) {
      h1 = (h1 * 1099511628211L) xor ch.code.toLong()
      h2 = (h2 * 6364136223846793005L) xor (ch.code.toLong() shl 8)
    }
    return String.format(Locale.US, "%016X%016X", h1, h2)
  }

  val POPULAR_GAMES_LIST: List<Pair<String, String>> = KNOWN_GAMES.map {
    it.nameEn to it.nameAr
  }
}
