package com.example

import android.app.Activity
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings as SettingsIcon
import androidx.compose.runtime.DisposableEffect
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.ConfigDiffItem
import com.example.data.DecodedGameRelease
import com.example.data.DeviceHardwareInfo
import com.example.data.EmulatorProfile
import com.example.data.EmulatorRegistry
import com.example.data.GamePatchDiagnosisStatus
import com.example.data.InstalledAppInfo
import com.example.data.InstalledGameItem
import com.example.data.ModInjectorRepository
import com.example.data.RealInjectionResult
import com.example.data.SelectedGameOrUpdateFileInfo
import com.example.data.SmartTuningProfile
import com.example.network.DirectPhoneTelemetry
import com.example.network.NetworkConnectionState
import com.example.ai.AiOptimizationPlan
import com.example.ai.AiOptimizationUiState
import com.example.ai.DirectFrameAndHardwareMetrics
import com.example.ai.LocalNpuUpscalerStatus
import com.example.thermal.DeviceThermalStatus
import com.example.ui.AiOptimizationSystemCard
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.MyApplicationTheme

data class AppStrings(
  val appTitle: String,
  val heroSubtitle: String,
  val mainTunerTabLabel: String,
  val diagnosisTabLabel: String,
  val smartProfileTabLabel: String,
  val openDiagnosisScreenBtn: String,
  val diagnosisScreenTitle: String,
  val diagnosisScreenSub: String,
  val openSmartProfileScreenBtn: String,
  val backToMainScreenBtn: String,
  val smartProfileScreenTitle: String,
  val smartProfileScreenSub: String,
  val deviceClassSectionTitle: String,
  val preselectedBadgeText: String,
  val switchRecommendedLighterBtn: String,
  val verifiedSettingsHeader: String,
  val liveDiffSectionTitle: String,
  val hardwareDetectedBadge: String,
  val performanceTelemetryBadge: String,
  val step0SelectAppTitle: String,
  val step0SelectAppSub: String,
  val installedOnDeviceBadge: String,
  val openAppChooserBtn: String,
  val selectedAppLabel: String,
  val noEmulatorsInstalledHint: String,
  val appChooserDialogTitle: String,
  val appChooserSearchHint: String,
  val appChooserEmptyText: String,
  val emulatorProtocolLabel: String,
  val launchSelectedAppBtn: String,
  val step1SafTitle: String,
  val safConnectedDesc: String,
  val safRequiredDesc: String,
  val safNotAppRootWarning: String,
  val connectSafBtn: String,
  val changeSafBtn: String,
  val rescanSafBtn: String,
  val dualFilesSectionTitle: String,
  val dualFilesSectionSub: String,
  val gameFileBoxTitle: String,
  val pickGameFileBtn: String,
  val pickGameFolderBtn: String,
  val updateFileBoxTitle: String,
  val pickUpdateFileBtn: String,
  val pickUpdateFolderBtn: String,
  val installedGamesHeader: String,
  val installedGamesSub: String,
  val noGamesFoundInFolderHint: String,
  val unlockAllGamesBtn: String,
  val gameNameInputLabel: String,
  val gameVersionInputLabel: String,
  val step3PerformanceTitle: String,
  val step3PerformanceSub: String,
  val profilesSectionTitle: String,
  val fps60WarningNote: String,
  val previewChangesBtn: String,
  val restoreOriginalConfigBtn: String,
  val thermalSectionTitle: String,
  val thermalStatusLabel: String,
  val thermalHeadroomLabel: String,
  val thermalDisclaimer: String,
  val autoAdaptThermalLabel: String,
  val diffPreviewTitle: String,
  val diffPreviewDesc: String,
  val diffEmptyMessage: String,
  val closePreviewBtn: String,
  val advancedSettingsToggleLabel: String,
  val performanceNceTitle: String,
  val performanceNceDesc: String,
  val force60EngineTitle: String,
  val force60EngineDesc: String,
  val amdFsrTitle: String,
  val amdFsrDesc: String,
  val fsrSharpnessLabel: String,
  val vulkanMaxClockTitle: String,
  val vulkanMaxClockDesc: String,
  val injectNowBtn: String,
  val restore30FpsBtn: String,
  val step4ResultTitle: String,
  val restartEmulatorNotice: String,
  val inspectPchtxtBtn: String,
  val inspectConfigIniBtn: String,
  val logsHeader: String,
  val customPatchSectionBtn: String,
  val customPatchDialogTitle: String,
  val customPatchDialogSub: String,
  val customPatchCodeLabel: String,
  val customPatchBuildIdLabel: String,
  val customPatchApplyBtn: String,
  val cancelBtn: String,
  val patchTroubleshootGuideTitle: String,
  val patchTroubleshootGuideBody: String,
)

private val ArabicAppStrings = AppStrings(
  appTitle = "مُحسّن الأداء وفك 60FPS",
  heroSubtitle = "ضبط ذكي للمحاكيات • نسخ احتياطي آمن • 60 FPS",
  mainTunerTabLabel = "الرئيسية",
  diagnosisTabLabel = "فحص الألعاب (Diagnosis)",
  smartProfileTabLabel = "الأنماط الذكية",
  openDiagnosisScreenBtn = "🔍 فحص تطابق الألعاب والباتشات (Diagnosis)",
  diagnosisScreenTitle = "فحص تطابق الألعاب والباتشات (Per-Game Diagnosis)",
  diagnosisScreenSub = "يعرض لكل لعبة: معرف اللعبة (Title ID)، الإصدار المكتشف، معرف البناء (Build ID من ترويسة NSO أو ملف التحديث)، وهل يتوفر باتش 60 FPS مطابق تماماً لهذا الـ Build ID.",
  openSmartProfileScreenBtn = "الأنماط الذكية ومعاينة التغييرات",
  backToMainScreenBtn = "رجوع",
  smartProfileScreenTitle = "الأنماط الذكية (Smart Profile)",
  smartProfileScreenSub = "يتم اختيار النمط تلقائياً حسب فئة جهازك (المعالج، الرام، ومعدل التحديث)، مع قراءة الحرارة لحظياً ومعاينة كل تغيير قبل تطبيقه.",
  deviceClassSectionTitle = "معلومات عتاد الجهاز وفئة الأداء:",
  preselectedBadgeText = "مُوصى به لجهازك",
  switchRecommendedLighterBtn = "تطبيق النمط الأخف الموصى به للحرارة الآن",
  verifiedSettingsHeader = "الإعدادات المعتمدة التي يغيرها هذا النمط (Eden):",
  liveDiffSectionTitle = "معاينة كل تغيير قبل التطبيق:",
  hardwareDetectedBadge = "المعالج:",
  performanceTelemetryBadge = "تطبيق الإعدادات المعتمدة مباشرة في ملفات ضبط المحاكي.",
  step0SelectAppTitle = "1. آخر تطبيق تم دخوله واختيار مجلده وملفاته",
  step0SelectAppSub = "يكتشف تلقائياً آخر تطبيق/محاكي دخلت إليه لتتمكن من اختيار مجلده وملفاته فوراً (أو اختر أي تطبيق آخر):",
  installedOnDeviceBadge = "آخر تطبيق تم دخوله ✓",
  openAppChooserBtn = "تغيير التطبيق / كل التطبيقات",
  selectedAppLabel = "آخر تطبيق تم دخوله:",
  noEmulatorsInstalledHint = "اختر التطبيق أو المحاكي واضغط على اختيار مجلده أو ملفاته",
  appChooserDialogTitle = "اختر التطبيق أو المحاكي",
  appChooserSearchHint = "ابحث عن أي تطبيق أو محاكي...",
  appChooserEmptyText = "لا توجد تطبيقات مطابقة",
  emulatorProtocolLabel = "النظام:",
  launchSelectedAppBtn = "فتح التطبيق",
  step1SafTitle = "وصول مجلد التطبيق وملفاته",
  safConnectedDesc = "✅ متصل بمجلد التطبيق",
  safRequiredDesc = "اضغط على زر «اختر مجلد التطبيق» أدناه لفتح المجلد مباشرة، أو اختر ملفات اللعبة/الباتش مباشرة:",
  safNotAppRootWarning = "📁 المجلد متصل وجاهز لحقن الباتشات والإعدادات",
  connectSafBtn = "اضغط لاختيار مجلده",
  changeSafBtn = "تغيير مجلد التطبيق",
  rescanSafBtn = "تحديث",
  dualFilesSectionTitle = "2. اختر اللعبة والتحديث",
  dualFilesSectionSub = "اختر ملف اللعبة وملف التحديث (أو اختر من ألعاب المجلد) لتطبيق 60 FPS:",
  gameFileBoxTitle = "ملف اللعبة الأساسي",
  pickGameFileBtn = "📄 ملف اللعبة",
  pickGameFolderBtn = "📁 مجلد الألعاب",
  updateFileBoxTitle = "ملف تحديث اللعبة (Update)",
  pickUpdateFileBtn = "🔄 ملف التحديث",
  pickUpdateFolderBtn = "📂 مجلد التحديثات",
  installedGamesHeader = "الألعاب المكتشفة:",
  installedGamesSub = "الألعاب الحقيقية الموجودة في مجلدك:",
  noGamesFoundInFolderHint = "اختر «ملف اللعبة» و«ملف التحديث» بالأعلى أو اربط مجلد المحاكي لظهور ألعابك هنا.",
  unlockAllGamesBtn = "⚡ تفعيل 60FPS لجميع ألعاب المجلد",
  gameNameInputLabel = "اللعبة المحددة (Title ID / الاسم)",
  gameVersionInputLabel = "إصدار التحديث (Version)",
  step3PerformanceTitle = "3. نمط الأداء وتفعيل 60 FPS",
  step3PerformanceSub = "يتم حفظ نسخة احتياطية مؤرخة تلقائياً قبل أي تعديل.",
  profilesSectionTitle = "اختر نمط الأداء الذكي:",
  fps60WarningNote = "60 FPS uses more GPU power and heat. (تفعيل 60 FPS يستهلك طاقة GPU أعلى ويزيد الحرارة)",
  previewChangesBtn = "معاينة التغييرات",
  restoreOriginalConfigBtn = "استعادة إعداداتي الأصلية",
  thermalSectionTitle = "حالة الحرارة",
  thermalStatusLabel = "حرارة الجهاز:",
  thermalHeadroomLabel = "مؤشر الحرارة:",
  thermalDisclaimer = "الألعاب تولد حرارة طبيعياً؛ يقوم التطبيق بتخفيف عبء المحاكي عند السخونة.",
  autoAdaptThermalLabel = "تبديل تلقائي لنمط أخف عند السخونة",
  diffPreviewTitle = "معاينة التغييرات قبل التطبيق",
  diffPreviewDesc = "مقارنة الإعدادات الحالية مع الإعدادات الجديدة:",
  diffEmptyMessage = "الإعدادات الحالية مطابقة للنمط المختار.",
  closePreviewBtn = "إغلاق",
  advancedSettingsToggleLabel = "خيارات الضبط المتقدمة وسجل النظام (NCE / FSR / Logs)",
  performanceNceTitle = "تفعيل NCE (cpu_backend=1)",
  performanceNceDesc = "تشغيل كود ARM64 مباشرة على المعالج لتقليل الحمل.",
  force60EngineTitle = "فك قفل 60 FPS (speed_limit=200)",
  force60EngineDesc = "تفعيل speed_limit=200 وكتابة باتش 60FPS المطابق للتحديث.",
  amdFsrTitle = "فلتر وضوح الصورة AMD FSR (scaling_filter=5)",
  amdFsrDesc = "رفع جودة الصورة مع خفض دقة الرندرة الداخلية لتخفيف حمل الـ GPU.",
  fsrSharpnessLabel = "درجة حدة وتفاصيل AMD FSR",
  vulkanMaxClockTitle = "الشيدر اللاتزامني (Async Shaders)",
  vulkanMaxClockDesc = "منع التقطيع أثناء اللعب عبر تجميع الشيدر اللاتزامني.",
  injectNowBtn = "🚀 تفعيل 60 FPS وتطبيق الإعدادات",
  restore30FpsBtn = "استعادة إعداداتي الأصلية",
  step4ResultTitle = "تم تفعيل 60 FPS وتحديث الإعدادات بنجاح ✓",
  restartEmulatorNotice = "⚠️ إذا كان المحاكي مفتوحاً في الخلفية، أغلقه وأعد فتحه لتسري الإعدادات الجديدة.",
  inspectPchtxtBtn = "عرض الباتش",
  inspectConfigIniBtn = "عرض الإعدادات",
  logsHeader = "سجل النظام",
  customPatchSectionBtn = "📝 لصق أو استيراد باتش يدوي (Custom Patch)",
  customPatchDialogTitle = "استيراد أو لصق باتش 60 FPS يدوي",
  customPatchDialogSub = "إذا لم يتوفر باتش تلقائي للعبتك أو إصدارك، الصق كود الباتش (.pchtxt أو كود الغش من GBAtemp أو مستودع NX-Cheats) وسيقوم التطبيق بتهيئته وحقنه فوراً.",
  customPatchCodeLabel = "كود الباتش أو الغش (.pchtxt / Cheats):",
  customPatchBuildIdLabel = "معرف البناء NSO Build ID (اختياري، يملأ تلقائياً إذا كان موجوداً بالكود):",
  customPatchApplyBtn = "حقن الباتش واعتماده للعبة ✓",
  cancelBtn = "إلغاء",
  patchTroubleshootGuideTitle = "حل مشكلة 'لا يتوفر باتش 60 FPS' أو 'عدم تطابق الإصدار':",
  patchTroubleshootGuideBody = "1. اختر ملف التحديث المناسب (.nsp) للعبتك عبر زر 'ملف التحديث'.\n2. افتح شاشة 'فحص الألعاب' لمعرفة الإصدارات والـ Build ID المدعومة.\n3. أو استخدم زر 'لصق باتش يدوي' للصق أي كود 60 FPS خارجي للعبتك مباشرة.",
)

private val EnglishAppStrings = AppStrings(
  appTitle = "MOD INJECTOR • 60FPS",
  heroSubtitle = "Smart Emulator Tuning • Safe Backups • 60 FPS",
  mainTunerTabLabel = "Main Tuner",
  diagnosisTabLabel = "Game Diagnosis",
  smartProfileTabLabel = "Smart Profile",
  openDiagnosisScreenBtn = "🔍 Per-Game Patch Diagnosis",
  diagnosisScreenTitle = "Per-Game Patch Diagnosis",
  diagnosisScreenSub = "Shows Title ID, detected version, NSO Build ID, whether an exact 60 FPS patch exists, and status (Matched, Version mismatch, No patch available, or Written but not verified).",
  openSmartProfileScreenBtn = "Smart Profiles & Preview Changes",
  backToMainScreenBtn = "Back",
  smartProfileScreenTitle = "Smart Profile",
  smartProfileScreenSub = "Preselected from your device class (Build.SOC_MODEL, RAM, refresh rate). Reads PowerManager thermal status live and previews every change before applying.",
  deviceClassSectionTitle = "Device Class & Hardware Info:",
  preselectedBadgeText = "Recommended for device",
  switchRecommendedLighterBtn = "Apply Recommended Lighter Profile Now",
  verifiedSettingsHeader = "Verified Emulator Settings Modified (Eden):",
  liveDiffSectionTitle = "Preview of Every Change Before Applying:",
  hardwareDetectedBadge = "SoC:",
  performanceTelemetryBadge = "Verified parameters applied directly into emulator config.",
  step0SelectAppTitle = "1. Last Opened App & Folder/Files Access",
  step0SelectAppSub = "Automatically detects the last played app/emulator so you can select its folder and files directly (or switch to any app):",
  installedOnDeviceBadge = "Last Played ✓",
  openAppChooserBtn = "Change App / All Apps",
  selectedAppLabel = "Detected last played:",
  noEmulatorsInstalledHint = "Select your app or emulator below to access its folder and files",
  appChooserDialogTitle = "Select App or Emulator",
  appChooserSearchHint = "Search any app or emulator...",
  appChooserEmptyText = "No matching apps found",
  emulatorProtocolLabel = "Engine:",
  launchSelectedAppBtn = "Open App",
  step1SafTitle = "Direct App Folder & Files Access",
  safConnectedDesc = "✅ Connected to app data folder",
  safRequiredDesc = "Click the button below to open the detected app's folder directly, or pick its files/games folder:",
  safNotAppRootWarning = "📁 Folder connected and ready for 60FPS patch & config.ini injection",
  connectSafBtn = "Click to grant access",
  changeSafBtn = "Change App Folder",
  rescanSafBtn = "Refresh",
  dualFilesSectionTitle = "2. Select Game & Update",
  dualFilesSectionSub = "Pick your Base Game and Update file (or select a discovered game) to unlock 60 FPS:",
  gameFileBoxTitle = "Base Game File",
  pickGameFileBtn = "📄 Game File",
  pickGameFolderBtn = "📁 Games Folder",
  updateFileBoxTitle = "Game Update File",
  pickUpdateFileBtn = "🔄 Update File",
  pickUpdateFolderBtn = "📂 Updates Folder",
  installedGamesHeader = "Discovered Games:",
  installedGamesSub = "Real games detected in your folder:",
  noGamesFoundInFolderHint = "Pick your Game File and Update File above (or connect emulator folder) to list your games.",
  unlockAllGamesBtn = "⚡ Unlock 60FPS for All Folder Games",
  gameNameInputLabel = "Selected Game (Title ID / Name)",
  gameVersionInputLabel = "Update Version",
  step3PerformanceTitle = "3. Smart Profile & 60 FPS Unlock",
  step3PerformanceSub = "A timestamped backup is automatically saved before modifying any files.",
  profilesSectionTitle = "Choose Smart Profile:",
  fps60WarningNote = "60 FPS uses more GPU power and heat.",
  previewChangesBtn = "Preview Changes",
  restoreOriginalConfigBtn = "Restore my original config",
  thermalSectionTitle = "Thermal Status",
  thermalStatusLabel = "Thermal State:",
  thermalHeadroomLabel = "Headroom:",
  thermalDisclaimer = "Gaming naturally generates heat; ModInjector adjusts emulator workload when warm.",
  autoAdaptThermalLabel = "Auto-switch to lighter profile when warm",
  diffPreviewTitle = "Preview Config Changes",
  diffPreviewDesc = "Current vs proposed emulator settings before applying:",
  diffEmptyMessage = "Current settings already match the selected profile.",
  closePreviewBtn = "Close",
  advancedSettingsToggleLabel = "Advanced Tuning & System Log (NCE / FSR / Logs)",
  performanceNceTitle = "Enable NCE (cpu_backend=1)",
  performanceNceDesc = "Executes ARM64 instructions natively on CPU.",
  force60EngineTitle = "Unlock 60.0 FPS (speed_limit=200)",
  force60EngineDesc = "Sets speed_limit=200 & writes verified Update 60FPS patch.",
  amdFsrTitle = "AMD FSR Upscaling (scaling_filter=5)",
  amdFsrDesc = "Spatial upscaling to maintain crisp visuals at lower GPU load.",
  fsrSharpnessLabel = "AMD FSR Sharpening",
  vulkanMaxClockTitle = "Async Shaders (use_asynchronous_shaders)",
  vulkanMaxClockDesc = "Prevents shader compilation stutter during gameplay.",
  injectNowBtn = "🚀 Apply Settings & Unlock 60 FPS",
  restore30FpsBtn = "Restore my original config",
  step4ResultTitle = "60 FPS & Performance Settings Applied ✓",
  restartEmulatorNotice = "⚠️ If the emulator was open in the background, close and reopen it so the new settings take effect.",
  inspectPchtxtBtn = "View Patch",
  inspectConfigIniBtn = "View Config",
  logsHeader = "System Log",
  customPatchSectionBtn = "📝 Paste / Import Custom Patch",
  customPatchDialogTitle = "Import / Paste Custom 60 FPS Patch",
  customPatchDialogSub = "If no patch was automatically found for your game version, paste your patch (.pchtxt or cheat code from GBAtemp / NX-Cheats) and the app will format and inject it safely.",
  customPatchCodeLabel = "Patch / Cheat Code (.pchtxt or Atmosphere Cheats):",
  customPatchBuildIdLabel = "NSO Build ID (optional, auto-detected if present in code):",
  customPatchApplyBtn = "Link & Verify Custom Patch ✓",
  cancelBtn = "Cancel",
  patchTroubleshootGuideTitle = "How to solve 'No 60 FPS patch available' or 'Version mismatch':",
  patchTroubleshootGuideBody = "1. Pick the matching Update file (.nsp) via 'Update File' button.\n2. Open 'Game Diagnosis' to see supported versions & Build IDs.\n3. Or tap 'Paste Custom Patch' to inject any external 60 FPS cheat directly.",
)

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      val context = LocalContext.current
      val repository = remember { ModInjectorRepository(context.applicationContext) }
      val viewModel: ModInjectorViewModel = viewModel(
        factory = object : ViewModelProvider.Factory {
          @Suppress("UNCHECKED_CAST")
          override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return ModInjectorViewModel(
              repository = repository,
              appContext = context.applicationContext,
            ) as T
          }
        }
      )
      val uiState by viewModel.uiState.collectAsStateWithLifecycle()
      val layoutDirection = if (uiState.isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr

      CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
        MyApplicationTheme(isArabic = uiState.isArabic) {
          SmartModInjectorScreen(
            viewModel = viewModel,
            repository = repository,
          )
        }
      }
    }
  }
}

@Composable
fun SmartModInjectorScreen(
  viewModel: ModInjectorViewModel,
  repository: ModInjectorRepository,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()
  val strings = if (uiState.isArabic) ArabicAppStrings else EnglishAppStrings
  var showAppChooserSheet by rememberSaveable { mutableStateOf(false) }

  val safTreeLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.StartActivityForResult()
  ) { result ->
    if (result.resultCode == Activity.RESULT_OK) {
      viewModel.onSafTreeGranted(result.data?.data)
    } else {
      viewModel.onSafTreeGranted(null)
    }
    viewModel.checkAndUpdatePermissions(context)
  }

  val pickGameFileLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.StartActivityForResult()
  ) { result ->
    if (result.resultCode == Activity.RESULT_OK) {
      viewModel.onGameFilePicked(result.data?.data)
    }
  }

  val pickGamesFolderLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.StartActivityForResult()
  ) { result ->
    if (result.resultCode == Activity.RESULT_OK) {
      viewModel.onGamesFolderPicked(result.data?.data)
    }
  }

  val pickUpdateFileLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.StartActivityForResult()
  ) { result ->
    if (result.resultCode == Activity.RESULT_OK) {
      viewModel.onUpdateFilePicked(result.data?.data)
    }
  }

  val pickUpdatesFolderLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.StartActivityForResult()
  ) { result ->
    if (result.resultCode == Activity.RESULT_OK) {
      viewModel.onUpdatesFolderPicked(result.data?.data)
    }
  }

  val notificationPermissionLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestPermission()
  ) { _ ->
    viewModel.checkAndUpdatePermissions(context)
  }

  val batteryOptimizationLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.StartActivityForResult()
  ) {
    viewModel.checkAndUpdatePermissions(context)
  }

  val usageStatsPermissionLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.StartActivityForResult()
  ) {
    viewModel.checkAndUpdatePermissions(context)
    viewModel.refreshInstalledPhoneApps(context)
  }

  val requestUsageStatsPermission: () -> Unit = {
    try {
      val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
        data = Uri.parse("package:${context.packageName}")
      }
      usageStatsPermissionLauncher.launch(intent)
    } catch (_: Exception) {
      try {
        usageStatsPermissionLauncher.launch(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
      } catch (_: Exception) {
        viewModel.checkAndUpdatePermissions(context)
      }
    }
  }

  val requestBatteryOptimization: () -> Unit = {
    try {
      val intent = Intent(
        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS
      ).apply {
        data = Uri.parse("package:${context.packageName}")
      }
      batteryOptimizationLauncher.launch(intent)
    } catch (_: Exception) {
      try {
        val fallback = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
        batteryOptimizationLauncher.launch(fallback)
      } catch (_: Exception) {
        viewModel.checkAndUpdatePermissions(context)
      }
    }
  }

  val requestNotificationPermission: () -> Unit = {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
    } else {
      viewModel.checkAndUpdatePermissions(context)
    }
  }

  val lifecycleOwner = LocalLifecycleOwner.current
  DisposableEffect(lifecycleOwner) {
    val observer = LifecycleEventObserver { _, event ->
      if (event == Lifecycle.Event.ON_RESUME) {
        viewModel.checkAndUpdatePermissions(context)
        viewModel.refreshInstalledPhoneApps(context)
      }
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose {
      lifecycleOwner.lifecycle.removeObserver(observer)
    }
  }

  val handleToggleBackgroundGovernor: (Boolean) -> Unit = { enabled ->
    if (enabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      val hasPerm = androidx.core.content.ContextCompat.checkSelfPermission(
        context,
        android.Manifest.permission.POST_NOTIFICATIONS,
      ) == android.content.pm.PackageManager.PERMISSION_GRANTED
      if (!hasPerm) {
        notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
      } else {
        viewModel.onToggleBackgroundGovernorService(true)
      }
    } else {
      viewModel.onToggleBackgroundGovernorService(enabled)
    }
  }

  val launchSafPicker = {
    safTreeLauncher.launch(repository.createEmulatorFolderPickerIntent(uiState.selectedEmulator))
  }

  if (showAppChooserSheet) {
    InstalledEmulatorChooserDialog(
      strings = strings,
      isArabic = uiState.isArabic,
      lastOpenedApp = uiState.lastOpenedApp,
      installedEmulators = uiState.installedPhoneApps,
      fallbackProfiles = uiState.emulatorProfiles,
      selectedPackage = uiState.selectedEmulator.packageName,
      onSelectInstalledEmulator = { appInfo ->
        viewModel.onPickInstalledPhoneApp(appInfo)
        showAppChooserSheet = false
      },
      onSelectProfile = { profile ->
        viewModel.onSelectEmulatorProfile(profile)
        showAppChooserSheet = false
      },
      onRefresh = { viewModel.refreshInstalledPhoneApps(context) },
      onDismiss = { showAppChooserSheet = false },
    )
  }

  if (uiState.isDiffDialogVisible) {
    ConfigDiffPreviewDialog(
      strings = strings,
      diffItems = uiState.previewDiffList,
      onDismiss = viewModel::onDismissDiffPreview,
    )
  }

  if (uiState.isCustomPatchDialogOpen) {
    CustomPatchInputDialog(
      strings = strings,
      isArabic = uiState.isArabic,
      targetGame = uiState.selectedGame,
      code = uiState.customPatchTextInput,
      buildId = uiState.customPatchBuildIdInput,
      onCodeChange = viewModel::onCustomPatchTextChanged,
      onBuildIdChange = viewModel::onCustomPatchBuildIdChanged,
      onApply = { code, bid -> viewModel.applyCustomPastedPatch(code, bid) },
      onDismiss = viewModel::onCloseCustomPatchDialog,
    )
  }

  if (uiState.showOnboardingDialog) {
    PermissionsOnboardingDialog(
      isArabic = uiState.isArabic,
      onboardingState = uiState.onboardingState,
      onRequestNotification = requestNotificationPermission,
      onRequestBatteryOptimization = requestBatteryOptimization,
      onRequestUsageStats = requestUsageStatsPermission,
      onRequestSaf = launchSafPicker,
      onComplete = viewModel::onCompleteOnboarding,
      onDismiss = viewModel::onDismissOnboarding,
    )
  }

  Scaffold(
    modifier = modifier.fillMaxSize(),
    contentWindowInsets = WindowInsets.safeDrawing,
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(MaterialTheme.colorScheme.background)
        .padding(innerPadding),
      contentAlignment = Alignment.TopCenter,
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .widthIn(max = 680.dp)
      ) {
        TopBarHeader(
          strings = strings,
          isArabic = uiState.isArabic,
          isSmartProfileScreenOpen = uiState.isSmartProfileScreenOpen,
          isDiagnosisScreenOpen = uiState.isDiagnosisScreenOpen,
          statusMessage = uiState.statusMessage,
          isRunning = uiState.isRunning,
          allPermissionsGranted = uiState.onboardingState.allGranted,
          onOpenPermissionsOnboarding = viewModel::onReopenOnboarding,
          onToggleLanguage = viewModel::toggleLanguage,
          onSelectMainTab = {
            viewModel.onCloseSmartProfileScreen()
            viewModel.onCloseDiagnosisScreen()
          },
          onSelectDiagnosisTab = viewModel::onOpenDiagnosisScreen,
          onSelectSmartProfileTab = viewModel::onOpenSmartProfileScreen,
        )

        if (uiState.isDiagnosisScreenOpen) {
          PerGameDiagnosisScreen(
            strings = strings,
            isArabic = uiState.isArabic,
            installedGames = uiState.installedGames,
            resolvedPreview = uiState.resolvedPreview,
            selectedGame = uiState.selectedGame,
            onBack = viewModel::onCloseDiagnosisScreen,
            onSelectGame = { game ->
              viewModel.onSelectInstalledGame(game)
              viewModel.onCloseDiagnosisScreen()
            },
            onPickGameFile = {
              pickGameFileLauncher.launch(repository.createPickSingleFileIntent())
            },
            onPickUpdateFile = {
              pickUpdateFileLauncher.launch(repository.createPickSingleFileIntent())
            },
            onOpenCustomPatchDialog = { game ->
              viewModel.onOpenCustomPatchDialog(game)
            },
          )
        } else if (uiState.isSmartProfileScreenOpen) {
          SmartProfileDedicatedScreen(
            strings = strings,
            isArabic = uiState.isArabic,
            hardwareInfo = uiState.deviceHardwareInfo,
            thermalStatus = uiState.thermalStatus,
            autoAdaptThermal = uiState.autoAdaptThermalProfile,
            selectedProfile = uiState.selectedProfile,
            selectedEmulator = uiState.selectedEmulator,
            diffItems = uiState.previewDiffList,
            isRunning = uiState.isRunning,
            hasSaf = uiState.grantedTreeUri != null,
            localNpuEnabled = uiState.localNpuAiUpscalingEnabled,
            localNpuStatus = uiState.localNpuStatus,
            isBackgroundGovernorActive = uiState.isBackgroundGovernorActive,
            aiState = uiState.aiOptimizationState,
            latestFrameMetrics = uiState.latestFrameMetrics,
            networkState = uiState.networkState,
            directTelemetry = uiState.directTelemetry,
            isCloudSyncing = uiState.isCloudSyncing,
            onBack = viewModel::onCloseSmartProfileScreen,
            onSelectProfile = viewModel::onSelectProfile,
            onToggleAutoAdaptThermal = viewModel::onToggleAutoAdaptThermal,
            onToggleLocalNpuUpscaling = viewModel::onToggleLocalNpuAiUpscaling,
            onToggleBackgroundGovernor = handleToggleBackgroundGovernor,
            onApplyProfileAndInject = { viewModel.executeSingleGameUnlock(launchSafPicker) },
            onRestoreOriginalConfig = viewModel::restoreOriginalConfig,
            onRunAiOptimization = viewModel::runAiOptimizationSystem,
            onApplyAiPlan = { plan -> viewModel.applyAiOptimizationPlan(plan, launchSafPicker) },
            onSyncViaNetwork = viewModel::syncCloudOverMobileDataOrWifi,
          )
        } else {
          LazyColumn(
            modifier = Modifier
              .fillMaxSize()
              .testTag("main_lazy_column"),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            item {
              CalmDeviceAndThermalSummaryCard(
                strings = strings,
                hardwareInfo = uiState.deviceHardwareInfo,
                thermalStatus = uiState.thermalStatus,
                autoAdaptThermal = uiState.autoAdaptThermalProfile,
                snapdragonLongSessionCoolMode = uiState.snapdragonLongSessionCoolMode,
                networkState = uiState.networkState,
                directTelemetry = uiState.directTelemetry,
                isCloudSyncing = uiState.isCloudSyncing,
                onToggleAutoAdaptThermal = viewModel::onToggleAutoAdaptThermal,
                onToggleSnapdragonLongSessionCoolMode = viewModel::onToggleSnapdragonLongSessionCoolMode,
                onSyncViaNetworkWithoutShizuku = viewModel::syncCloudOverMobileDataOrWifi,
                onOpenSmartProfileScreen = viewModel::onOpenSmartProfileScreen,
                isArabic = uiState.isArabic,
              )
            }

            if (uiState.lastInjectionResult != null) {
              item {
                Step4VerificationReportCard(
                  strings = strings,
                  isArabic = uiState.isArabic,
                  result = uiState.lastInjectionResult!!,
                  onLaunchEmulator = {
                    val edenProfile = uiState.emulatorProfiles.firstOrNull {
                      it.packageName == "dev.eden.eden_emulator"
                    } ?: uiState.selectedEmulator
                    val launchIntent = EmulatorRegistry.getLaunchIntentForEmulator(context, uiState.selectedEmulator)
                      ?: EmulatorRegistry.getLaunchIntentForEmulator(context, edenProfile)
                    launchIntent?.let { intent ->
                      context.startActivity(intent)
                    }
                  },
                )
              }
            }

            item {
              Step1InstalledEmulatorsAndFolderCard(
                strings = strings,
                isArabic = uiState.isArabic,
                lastOpenedApp = uiState.lastOpenedApp,
                hasUsageStatsPermission = uiState.onboardingState.hasUsageStatsPermission,
                installedEmulators = uiState.installedPhoneApps,
                emulatorProfiles = uiState.emulatorProfiles,
                selectedEmulator = uiState.selectedEmulator,
                grantedUri = uiState.grantedTreeUri,
                isVerifiedEmulatorRoot = uiState.isVerifiedEmulatorRoot,
                gamesCount = uiState.installedGames.size,
                onSelectInstalledEmulator = viewModel::onPickInstalledPhoneApp,
                onSelectEmulatorProfile = viewModel::onSelectEmulatorProfile,
                onOpenEmulatorChooser = {
                  viewModel.refreshInstalledPhoneApps(context)
                  showAppChooserSheet = true
                },
                onRequestUsageStatsPermission = requestUsageStatsPermission,
                onRefreshEmulators = { viewModel.refreshInstalledPhoneApps(context) },
                onConnectSaf = launchSafPicker,
                onPickGameFile = {
                  pickGameFileLauncher.launch(repository.createPickSingleFileIntent())
                },
                onPickGamesFolder = {
                  pickGamesFolderLauncher.launch(repository.createGenericFolderPickerIntent())
                },
                onRescanGames = viewModel::rescanInstalledGames,
                onLaunchApp = {
                  EmulatorRegistry.getLaunchIntentForEmulator(context, uiState.selectedEmulator)?.let { intent ->
                    context.startActivity(intent)
                  }
                },
              )
            }

            item {
              Step2FolderGamesOnlyCard(
                strings = strings,
                isArabic = uiState.isArabic,
                installedGames = uiState.installedGames,
                selectedGame = uiState.selectedGame,
                selectedGameFileInfo = uiState.selectedGameFileInfo,
                selectedUpdateFileInfo = uiState.selectedUpdateFileInfo,
                discoveredUpdateFiles = uiState.discoveredUpdateFiles,
                onSelectGame = viewModel::onSelectInstalledGame,
                onOpenDiagnosisScreen = viewModel::onOpenDiagnosisScreen,
                onPickGameFile = {
                  pickGameFileLauncher.launch(repository.createPickSingleFileIntent())
                },
                onPickGamesFolder = {
                  pickGamesFolderLauncher.launch(repository.createGenericFolderPickerIntent())
                },
                onPickUpdateFile = {
                  pickUpdateFileLauncher.launch(repository.createPickSingleFileIntent())
                },
                onPickUpdatesFolder = {
                  pickUpdatesFolderLauncher.launch(repository.createGenericFolderPickerIntent())
                },
                onSelectDiscoveredUpdate = viewModel::onSelectDiscoveredUpdate,
                onUnlockAll = { viewModel.executeUnlockAllGames(launchSafPicker) },
                onOpenCustomPatchDialog = { viewModel.onOpenCustomPatchDialog(null) },
              )
            }

            item {
              Step3SelectedGameAndPerformanceTuningCard(
                strings = strings,
                isArabic = uiState.isArabic,
                gameNameInput = uiState.gameNameInput,
                gameVersionInput = uiState.gameVersionInput,
                resolvedPreview = uiState.resolvedPreview,
                selectedProfile = uiState.selectedProfile,
                recommendedProfile = uiState.deviceHardwareInfo.recommendedProfile,
                performanceNce = uiState.enablePerformanceNce,
                force60Engine = uiState.force60FpsEngineSpeed,
                enableAmdFsr = uiState.enableAmdFsrUpscaling,
                fsrSharpness = uiState.fsrSharpnessPercent,
                forceMaxClock = uiState.forceMaxGpuClock,
                isRunning = uiState.isRunning,
                hasSaf = uiState.grantedTreeUri != null,
                logs = uiState.logs,
                onSelectProfile = viewModel::onSelectProfile,
                onOpenSmartProfileScreen = viewModel::onOpenSmartProfileScreen,
                onGameNameChange = viewModel::onGameNameChanged,
                onGameVersionChange = viewModel::onGameVersionChanged,
                onTogglePerformanceNce = viewModel::onTogglePerformanceNce,
                onToggleForce60 = viewModel::onToggleForce60Engine,
                onToggleAmdFsr = viewModel::onToggleAmdFsr,
                onFsrSharpnessChange = viewModel::onFsrSharpnessChanged,
                onToggleMaxClock = viewModel::onToggleMaxGpuClock,
                onOpenDiffPreview = viewModel::onOpenDiffPreview,
                onInject = { viewModel.executeSingleGameUnlock(launchSafPicker) },
                onRestoreOriginalConfig = viewModel::restoreOriginalConfig,
              )
            }

            item {
              AiOptimizationSystemCard(
                isArabic = uiState.isArabic,
                localNpuEnabled = uiState.localNpuAiUpscalingEnabled,
                localNpuStatus = uiState.localNpuStatus,
                isBackgroundGovernorActive = uiState.isBackgroundGovernorActive,
                aiState = uiState.aiOptimizationState,
                latestMetrics = uiState.latestFrameMetrics,
                networkState = uiState.networkState,
                directTelemetry = uiState.directTelemetry,
                isRunning = uiState.isRunning,
                isCloudSyncing = uiState.isCloudSyncing,
                onToggleLocalNpuUpscaling = viewModel::onToggleLocalNpuAiUpscaling,
                onToggleBackgroundGovernor = handleToggleBackgroundGovernor,
                onRunAiOptimization = viewModel::runAiOptimizationSystem,
                onApplyAiPlan = { plan -> viewModel.applyAiOptimizationPlan(plan, launchSafPicker) },
                onSyncNetwork = viewModel::syncCloudOverMobileDataOrWifi,
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun TopBarHeader(
  strings: AppStrings,
  isArabic: Boolean,
  isSmartProfileScreenOpen: Boolean,
  isDiagnosisScreenOpen: Boolean,
  statusMessage: String,
  isRunning: Boolean,
  allPermissionsGranted: Boolean,
  onOpenPermissionsOnboarding: () -> Unit,
  onToggleLanguage: () -> Unit,
  onSelectMainTab: () -> Unit,
  onSelectDiagnosisTab: () -> Unit,
  onSelectSmartProfileTab: () -> Unit,
) {
  Surface(
    color = MaterialTheme.colorScheme.surface,
    tonalElevation = 1.dp,
    modifier = Modifier.fillMaxWidth(),
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 10.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f),
        ) {
          Image(
            painter = painterResource(id = R.drawable.app_chip_logo),
            contentDescription = "App Icon Logo",
            modifier = Modifier
              .size(32.dp)
              .clip(RoundedCornerShape(8.dp)),
            contentScale = ContentScale.Crop,
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = strings.appTitle,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }

        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          FilledTonalButton(
            onClick = onOpenPermissionsOnboarding,
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
            shape = RoundedCornerShape(50),
            modifier = Modifier
              .height(36.dp)
              .testTag("onboarding_status_button"),
            colors = ButtonDefaults.filledTonalButtonColors(
              containerColor = if (allPermissionsGranted) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.errorContainer,
              contentColor = if (allPermissionsGranted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onErrorContainer,
            ),
          ) {
            Icon(
              imageVector = if (allPermissionsGranted) Icons.Filled.Security else Icons.Filled.BatteryChargingFull,
              contentDescription = "Permissions Status",
              modifier = Modifier.size(15.dp),
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = if (isArabic) {
                if (allPermissionsGranted) "الأذونات ✓" else "الأذونات !"
              } else {
                if (allPermissionsGranted) "Perms ✓" else "Perms !"
              },
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
            )
          }

          FilledTonalButton(
            onClick = onToggleLanguage,
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
            shape = RoundedCornerShape(50),
            modifier = Modifier
              .height(36.dp)
              .testTag("language_toggle_button"),
          ) {
            Icon(
              imageVector = Icons.Filled.Language,
              contentDescription = "Switch Language Arabic / English",
              modifier = Modifier.size(15.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = if (isArabic) "EN" else "عربي",
              style = MaterialTheme.typography.labelLarge,
            )
          }
        }
      }

      // Clean 3-Tab Segmented Switcher: Main | Diagnosis | Smart Profile
      val isMainActive = !isSmartProfileScreenOpen && !isDiagnosisScreenOpen
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        FilledTonalButton(
          onClick = onSelectMainTab,
          modifier = Modifier
            .weight(1f)
            .height(40.dp)
            .testTag("tab_main_tuner"),
          shape = RoundedCornerShape(10.dp),
          contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
          colors = ButtonDefaults.filledTonalButtonColors(
            containerColor = if (isMainActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
            contentColor = if (isMainActive) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
          ),
        ) {
          Icon(imageVector = Icons.Filled.Bolt, contentDescription = null, modifier = Modifier.size(15.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = strings.mainTunerTabLabel,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }

        FilledTonalButton(
          onClick = onSelectDiagnosisTab,
          modifier = Modifier
            .weight(1f)
            .height(40.dp)
            .testTag("tab_game_diagnosis"),
          shape = RoundedCornerShape(10.dp),
          contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
          colors = ButtonDefaults.filledTonalButtonColors(
            containerColor = if (isDiagnosisScreenOpen) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
            contentColor = if (isDiagnosisScreenOpen) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
          ),
        ) {
          Icon(imageVector = Icons.Filled.Verified, contentDescription = null, modifier = Modifier.size(15.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = strings.diagnosisTabLabel,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }

        FilledTonalButton(
          onClick = onSelectSmartProfileTab,
          modifier = Modifier
            .weight(1f)
            .height(40.dp)
            .testTag("tab_smart_profile"),
          shape = RoundedCornerShape(10.dp),
          contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
          colors = ButtonDefaults.filledTonalButtonColors(
            containerColor = if (isSmartProfileScreenOpen) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
            contentColor = if (isSmartProfileScreenOpen) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
          ),
        ) {
          Icon(imageVector = Icons.Filled.Tune, contentDescription = null, modifier = Modifier.size(15.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = strings.smartProfileTabLabel,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }

      // Subtle Status Strip
      Surface(
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Box(
            modifier = Modifier
              .size(8.dp)
              .clip(CircleShape)
              .background(
                if (isRunning) MaterialTheme.colorScheme.tertiary
                else MaterialTheme.colorScheme.secondary
              )
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = statusMessage,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.testTag("status_message_text"),
          )
        }
      }
    }
  }
}

@Composable
private fun CalmDeviceAndThermalSummaryCard(
  strings: AppStrings,
  hardwareInfo: DeviceHardwareInfo,
  thermalStatus: DeviceThermalStatus,
  autoAdaptThermal: Boolean,
  snapdragonLongSessionCoolMode: Boolean,
  networkState: NetworkConnectionState,
  directTelemetry: DirectPhoneTelemetry,
  isCloudSyncing: Boolean,
  onToggleAutoAdaptThermal: (Boolean) -> Unit,
  onToggleSnapdragonLongSessionCoolMode: (Boolean) -> Unit,
  onSyncViaNetworkWithoutShizuku: () -> Unit,
  onOpenSmartProfileScreen: () -> Unit,
  isArabic: Boolean,
) {
  var showDetails by rememberSaveable { mutableStateOf(false) }

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("snapdragon_device_summary_card"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
  ) {
    Column(
      modifier = Modifier.padding(14.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f),
        ) {
          Image(
            painter = painterResource(id = R.drawable.app_chip_logo),
            contentDescription = "Mod Injector Chip Logo",
            modifier = Modifier
              .size(44.dp)
              .clip(RoundedCornerShape(10.dp)),
            contentScale = ContentScale.Crop,
          )
          Spacer(modifier = Modifier.width(12.dp))
          Column {
            Text(
              text = "${hardwareInfo.socBrand} (${hardwareInfo.socModelCode})",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
            Text(
              text = if (isArabic) hardwareInfo.snapdragonSeries.badgeAr else hardwareInfo.snapdragonSeries.badgeEn,
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.primary,
              modifier = Modifier.testTag("snapdragon_series_badge"),
            )
            Text(
              text = "${hardwareInfo.totalRamGb}GB RAM • ${hardwareInfo.refreshRateHz}Hz • ${directTelemetry.batteryTempCelsius ?: 33.0}°C • ${if (isArabic) thermalStatus.statusNameAr else thermalStatus.statusNameEn}",
              style = MaterialTheme.typography.labelSmall,
              color = if (thermalStatus.isSevere) MaterialTheme.colorScheme.error
              else if (thermalStatus.isHot) MaterialTheme.colorScheme.tertiary
              else MaterialTheme.colorScheme.secondary,
            )
          }
        }

        IconButton(onClick = { showDetails = !showDetails }) {
          Icon(
            imageVector = if (showDetails) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
            contentDescription = "Toggle Hardware Details",
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }

      // Dedicated Snapdragon 7 & 8 Series Zero-Pressure Long-Session Cool Mode Banner + Switch
      Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Column(
          modifier = Modifier.padding(10.dp),
          verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = if (isArabic) {
                  "❄️ وضع اللعب الطويل بدون حرارة أو ضغط (Snapdragon 7 & 8 Cool Mode)"
                } else {
                  "❄️ Snapdragon 7 & 8 Long-Session Cool Mode (Zero Phone Pressure)"
                },
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
              )
              Text(
                text = if (isArabic) {
                  hardwareInfo.snapdragonSeries.sustainedPlaySummaryAr
                } else {
                  hardwareInfo.snapdragonSeries.sustainedPlaySummaryEn
                },
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Switch(
              checked = snapdragonLongSessionCoolMode,
              onCheckedChange = onToggleSnapdragonLongSessionCoolMode,
              modifier = Modifier.testTag("snapdragon_long_session_cool_switch"),
            )
          }

          HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))

          // Shizuku-Free Mobile Data (4G/5G) & Connected Wi-Fi Network Status Row
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = if (isArabic) {
                  "🌐 الشبكة الذكية نشطة: ${networkState.badgeAr}"
                } else {
                  "🌐 Smart Network Active: ${networkState.badgeEn}"
                },
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.secondary,
              )
              Text(
                text = if (isArabic) {
                  "يستخدم إنترنت الهاتف (4G/5G) تلقائياً بدون الحاجة لتشغيل Wi-Fi لتشغيل نظام الذكاء الاصطناعي"
                } else {
                  "Uses Phone Internet (4G/5G) automatically if Wi-Fi is off to power the AI Optimization System"
                },
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
            Spacer(modifier = Modifier.width(8.dp))
            FilledTonalButton(
              onClick = onSyncViaNetworkWithoutShizuku,
              enabled = !isCloudSyncing,
              shape = RoundedCornerShape(8.dp),
              contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
              modifier = Modifier
                .height(36.dp)
                .testTag("header_network_sync_button"),
            ) {
              Icon(
                imageVector = Icons.Filled.CloudDownload,
                contentDescription = null,
                modifier = Modifier.size(14.dp),
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = if (isArabic) "مزامنة الشبكة" else "Network Sync",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
              )
            }
          }
        }
      }

      AnimatedVisibility(visible = showDetails) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
          Text(
            text = if (isArabic) thermalStatus.recommendationAr else thermalStatus.recommendationEn,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(
              text = strings.autoAdaptThermalLabel,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurface,
              modifier = Modifier.weight(1f),
            )
            Switch(
              checked = autoAdaptThermal,
              onCheckedChange = onToggleAutoAdaptThermal,
              modifier = Modifier.testTag("switch_auto_adapt_thermal"),
            )
          }
        }
      }
    }
  }
}

@Composable
private fun Step1InstalledEmulatorsAndFolderCard(
  strings: AppStrings,
  isArabic: Boolean,
  lastOpenedApp: InstalledAppInfo?,
  hasUsageStatsPermission: Boolean,
  installedEmulators: List<InstalledAppInfo>,
  emulatorProfiles: List<EmulatorProfile>,
  selectedEmulator: EmulatorProfile,
  grantedUri: Uri?,
  isVerifiedEmulatorRoot: Boolean,
  gamesCount: Int,
  onSelectInstalledEmulator: (InstalledAppInfo) -> Unit,
  onSelectEmulatorProfile: (EmulatorProfile) -> Unit,
  onOpenEmulatorChooser: () -> Unit,
  onRequestUsageStatsPermission: () -> Unit,
  onRefreshEmulators: () -> Unit,
  onConnectSaf: () -> Unit,
  onPickGameFile: () -> Unit,
  onPickGamesFolder: () -> Unit,
  onRescanGames: () -> Unit,
  onLaunchApp: () -> Unit,
) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("emulator_selector_card"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f),
        ) {
          Icon(
            imageVector = Icons.Filled.SportsEsports,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(22.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = strings.step0SelectAppTitle,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
          )
        }

        IconButton(
          onClick = onRefreshEmulators,
          modifier = Modifier.size(36.dp),
        ) {
          Icon(
            imageVector = Icons.Filled.Refresh,
            contentDescription = strings.rescanSafBtn,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(18.dp),
          )
        }
      }

      Text(
        text = strings.step0SelectAppSub,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )

      // Prominent Banner for Last Entered App & Quick App Switcher
      Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.28f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("active_emulator_protocol_box"),
      ) {
        Column(
          modifier = Modifier.padding(14.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.weight(1f),
            ) {
              Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.18f),
                modifier = Modifier.size(42.dp),
              ) {
                Icon(
                  imageVector = Icons.Filled.SportsEsports,
                  contentDescription = null,
                  tint = MaterialTheme.colorScheme.primary,
                  modifier = Modifier
                    .padding(9.dp)
                    .fillMaxSize(),
                )
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = if (isArabic) {
                    "آخر تطبيق تم دخوله: ${selectedEmulator.nameAr}"
                  } else {
                    "Detected last played: ${selectedEmulator.nameEn}"
                  },
                  style = MaterialTheme.typography.titleSmall,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.onSurface,
                )
                Text(
                  text = "Android/data/${selectedEmulator.packageName}/files",
                  fontFamily = JetBrainsMonoFontFamily,
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
              }
            }

            OutlinedButton(
              onClick = onOpenEmulatorChooser,
              shape = RoundedCornerShape(10.dp),
              contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
              modifier = Modifier
                .height(38.dp)
                .testTag("open_app_chooser_button"),
            ) {
              Text(
                text = strings.openAppChooserBtn,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
              )
            }
          }

          if (!hasUsageStatsPermission) {
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.35f),
              modifier = Modifier
                .fillMaxWidth()
                .clickable { onRequestUsageStatsPermission() }
                .testTag("enable_usage_stats_banner"),
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
              ) {
                Text(
                  text = if (isArabic) {
                    "🔍 فعّل إذن (Usage Access) لكشف آخر تطبيق دخلته تلقائياً فور خروجك منه"
                  } else {
                    "🔍 Enable Usage Access to auto-detect the exact last app you opened"
                  },
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurface,
                  modifier = Modifier.weight(1f),
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = if (isArabic) "تفعيل ←" else "Enable →",
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.primary,
                )
              }
            }
          }

          // Quick horizontal chips for Last Opened App + Emulators
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            if (lastOpenedApp != null) {
              val isSelected = lastOpenedApp.packageName == selectedEmulator.packageName
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = if (isSelected) {
                  MaterialTheme.colorScheme.primary.copy(alpha = 0.22f)
                } else {
                  MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)
                },
                border = BorderStroke(
                  width = if (isSelected) 1.5.dp else 0.5.dp,
                  color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                ),
                modifier = Modifier
                  .clickable { onSelectInstalledEmulator(lastOpenedApp) }
                  .testTag("last_opened_app_chip"),
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Icon(
                    imageVector = Icons.Filled.CheckCircle,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp),
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = if (isArabic) "آخر تطبيق: ${lastOpenedApp.appLabel}" else "Last: ${lastOpenedApp.appLabel}",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                  )
                }
              }
            }

            emulatorProfiles.take(10).forEach { profile ->
              if (profile.packageName != lastOpenedApp?.packageName) {
                val isSelected = profile.packageName == selectedEmulator.packageName
                Surface(
                  shape = RoundedCornerShape(10.dp),
                  color = if (isSelected) {
                    MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)
                  } else {
                    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                  },
                  border = BorderStroke(
                    width = if (isSelected) 1.5.dp else 0.5.dp,
                    color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                  ),
                  modifier = Modifier.clickable { onSelectEmulatorProfile(profile) },
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                  ) {
                    Text(
                      text = profile.nameEn,
                      style = MaterialTheme.typography.labelMedium,
                      fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                      color = MaterialTheme.colorScheme.onSurface,
                    )
                  }
                }
              }
            }
          }

          HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

          // Folder Connection Status
          Text(
            text = if (grantedUri != null && isVerifiedEmulatorRoot) {
              "${strings.safConnectedDesc} ($gamesCount) • ${selectedEmulator.nameEn}"
            } else if (grantedUri != null) {
              "${strings.safNotAppRootWarning} ($gamesCount)"
            } else {
              strings.safRequiredDesc
            },
            style = MaterialTheme.typography.bodySmall,
            color = if (grantedUri != null) {
              MaterialTheme.colorScheme.secondary
            } else {
              MaterialTheme.colorScheme.onSurfaceVariant
            },
          )

          if (grantedUri != null) {
            Text(
              text = Uri.decode(grantedUri.toString()),
              fontFamily = JetBrainsMonoFontFamily,
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              maxLines = 2,
              overflow = TextOverflow.Ellipsis,
            )
          }

          // Primary Button: Open the detected app's folder directly via EXTRA_INITIAL_URI
          Button(
            onClick = onConnectSaf,
            modifier = Modifier
              .fillMaxWidth()
              .height(50.dp)
              .testTag("grant_saf_button"),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(
              containerColor = MaterialTheme.colorScheme.primary,
              contentColor = MaterialTheme.colorScheme.onPrimary,
            ),
          ) {
            Icon(
              imageVector = Icons.Filled.FolderOpen,
              contentDescription = null,
              modifier = Modifier.size(20.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = if (isArabic) {
                "📂 تم كشف: ${selectedEmulator.nameAr} — اضغط لاختيار مجلده"
              } else {
                "📂 Detected last played: ${selectedEmulator.nameEn}. Click to grant access"
              },
              style = MaterialTheme.typography.labelLarge,
              fontWeight = FontWeight.Bold,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }

          // Secondary Direct File & Folder Pickers so user can select both its folder and its files directly
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            FilledTonalButton(
              onClick = onPickGameFile,
              modifier = Modifier
                .weight(1f)
                .height(44.dp)
                .testTag("step1_pick_files_button"),
              shape = RoundedCornerShape(10.dp),
              contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
            ) {
              Text(
                text = if (isArabic) "📄 اختيار ملفاته" else "📄 Select Files",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }

            OutlinedButton(
              onClick = onPickGamesFolder,
              modifier = Modifier
                .weight(1f)
                .height(44.dp)
                .testTag("step1_pick_games_folder_button"),
              shape = RoundedCornerShape(10.dp),
              contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
            ) {
              Text(
                text = if (isArabic) "📁 مجلد الألعاب" else "📁 Games Folder",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }

            if (grantedUri != null) {
              OutlinedButton(
                onClick = onRescanGames,
                modifier = Modifier
                  .height(44.dp)
                  .testTag("scan_titles_button"),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
              ) {
                Icon(
                  imageVector = Icons.Filled.Refresh,
                  contentDescription = strings.rescanSafBtn,
                  modifier = Modifier.size(16.dp),
                )
              }
            } else {
              OutlinedButton(
                onClick = onLaunchApp,
                modifier = Modifier.height(44.dp),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
              ) {
                Icon(
                  imageVector = Icons.Filled.PlayArrow,
                  contentDescription = strings.launchSelectedAppBtn,
                  modifier = Modifier.size(16.dp),
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun InstalledEmulatorChooserDialog(
  strings: AppStrings,
  isArabic: Boolean,
  lastOpenedApp: InstalledAppInfo?,
  installedEmulators: List<InstalledAppInfo>,
  fallbackProfiles: List<EmulatorProfile>,
  selectedPackage: String,
  onSelectInstalledEmulator: (InstalledAppInfo) -> Unit,
  onSelectProfile: (EmulatorProfile) -> Unit,
  onRefresh: () -> Unit,
  onDismiss: () -> Unit,
) {
  var searchQuery by rememberSaveable { mutableStateOf("") }
  val combinedApps = remember(lastOpenedApp, installedEmulators) {
    val list = mutableListOf<InstalledAppInfo>()
    if (lastOpenedApp != null) list.add(lastOpenedApp)
    for (app in installedEmulators) {
      if (list.none { it.packageName.equals(app.packageName, ignoreCase = true) }) {
        list.add(app)
      }
    }
    list
  }

  val filteredInstalled = remember(combinedApps, searchQuery) {
    if (searchQuery.isBlank()) {
      combinedApps
    } else {
      val q = searchQuery.trim().lowercase()
      combinedApps.filter {
        it.appLabel.lowercase().contains(q) || it.packageName.lowercase().contains(q)
      }
    }
  }

  val filteredProfiles = remember(fallbackProfiles, searchQuery) {
    if (searchQuery.isBlank()) {
      fallbackProfiles
    } else {
      val q = searchQuery.trim().lowercase()
      fallbackProfiles.filter {
        it.nameEn.lowercase().contains(q) || it.packageName.lowercase().contains(q)
      }
    }
  }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false),
  ) {
    Surface(
      modifier = Modifier
        .fillMaxWidth(0.94f)
        .heightIn(min = 320.dp, max = 600.dp),
      shape = RoundedCornerShape(20.dp),
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 4.dp,
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Filled.SportsEsports,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary,
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = strings.appChooserDialogTitle,
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface,
            )
          }
          Row {
            IconButton(onClick = onRefresh) {
              Icon(
                imageVector = Icons.Filled.Refresh,
                contentDescription = "Refresh",
              )
            }
            IconButton(onClick = onDismiss) {
              Icon(
                imageVector = Icons.Filled.Close,
                contentDescription = "Close",
              )
            }
          }
        }

        OutlinedTextField(
          value = searchQuery,
          onValueChange = { searchQuery = it },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("app_chooser_search_input"),
          placeholder = { Text(strings.appChooserSearchHint) },
          leadingIcon = { Icon(imageVector = Icons.Filled.Search, contentDescription = null) },
          singleLine = true,
          shape = RoundedCornerShape(12.dp),
        )

        LazyColumn(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          if (filteredInstalled.isNotEmpty()) {
            items(filteredInstalled, key = { "inst_${it.packageName}" }) { app ->
              val isSelected = app.packageName == selectedPackage
              val isLastOpened = app.packageName == lastOpenedApp?.packageName
              Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (isSelected) {
                  MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
                } else {
                  MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                },
                border = BorderStroke(
                  width = if (isSelected || isLastOpened) 1.5.dp else 0.5.dp,
                  color = if (isSelected) MaterialTheme.colorScheme.primary
                  else if (isLastOpened) MaterialTheme.colorScheme.secondary
                  else Color.Transparent,
                ),
                modifier = Modifier
                  .fillMaxWidth()
                  .clickable { onSelectInstalledEmulator(app) }
                  .testTag("chooser_app_${app.packageName}"),
              ) {
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f),
                  ) {
                    Surface(
                      shape = CircleShape,
                      color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.18f),
                      modifier = Modifier.size(40.dp),
                    ) {
                      Icon(
                        imageVector = Icons.Filled.SportsEsports,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier
                          .padding(9.dp)
                          .fillMaxSize(),
                      )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                      Text(
                        text = app.appLabel,
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Bold,
                      )
                      Text(
                        text = app.packageName,
                        fontFamily = JetBrainsMonoFontFamily,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                      )
                    }
                  }

                  Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isLastOpened) {
                      MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)
                    } else {
                      MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f)
                    },
                  ) {
                    Text(
                      text = if (isLastOpened) {
                        strings.installedOnDeviceBadge
                      } else if (isArabic) {
                        "مثبت ✓"
                      } else {
                        "Installed ✓"
                      },
                      style = MaterialTheme.typography.labelSmall,
                      color = if (isLastOpened) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary,
                      fontWeight = FontWeight.Bold,
                      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    )
                  }
                }
              }
            }
          }

          items(
            filteredProfiles.filter { p -> filteredInstalled.none { it.packageName.equals(p.packageName, ignoreCase = true) } },
            key = { "prof_${it.packageName}" },
          ) { profile ->
            val isSelected = profile.packageName == selectedPackage
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = if (isSelected) {
                MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)
              } else {
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
              },
              border = BorderStroke(
                width = if (isSelected) 1.5.dp else 0.5.dp,
                color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
              ),
              modifier = Modifier
                .fillMaxWidth()
                .clickable { onSelectProfile(profile) }
                .testTag("chooser_app_${profile.packageName}"),
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = profile.nameEn,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                  )
                  Text(
                    text = profile.packageName,
                    fontFamily = JetBrainsMonoFontFamily,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                  )
                }
                Text(
                  text = if (isArabic) profile.platformBadgeAr else profile.platformBadgeEn,
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.primary,
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun Step2FolderGamesOnlyCard(
  strings: AppStrings,
  isArabic: Boolean,
  installedGames: List<InstalledGameItem>,
  selectedGame: InstalledGameItem?,
  selectedGameFileInfo: SelectedGameOrUpdateFileInfo?,
  selectedUpdateFileInfo: SelectedGameOrUpdateFileInfo?,
  discoveredUpdateFiles: List<SelectedGameOrUpdateFileInfo>,
  onSelectGame: (InstalledGameItem) -> Unit,
  onOpenDiagnosisScreen: () -> Unit,
  onPickGameFile: () -> Unit,
  onPickGamesFolder: () -> Unit,
  onPickUpdateFile: () -> Unit,
  onPickUpdatesFolder: () -> Unit,
  onSelectDiscoveredUpdate: (SelectedGameOrUpdateFileInfo) -> Unit,
  onUnlockAll: () -> Unit,
  onOpenCustomPatchDialog: () -> Unit,
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f),
        ) {
          Icon(
            imageVector = Icons.Filled.FolderOpen,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(20.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = strings.dualFilesSectionTitle,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
          )
        }

        OutlinedButton(
          onClick = onOpenDiagnosisScreen,
          shape = RoundedCornerShape(10.dp),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
          modifier = Modifier
            .height(34.dp)
            .testTag("open_diagnosis_screen_button"),
        ) {
          Text(
            text = strings.diagnosisTabLabel,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.SemiBold,
          )
        }
      }

      // Clean 2-Column Action Grid for Game + Update selection
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Button(
          onClick = onPickGameFile,
          modifier = Modifier
            .weight(1f)
            .height(46.dp)
            .testTag("pick_game_file_button"),
          shape = RoundedCornerShape(10.dp),
        ) {
          Text(
            text = strings.pickGameFileBtn,
            style = MaterialTheme.typography.labelMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }

        Button(
          onClick = onPickUpdateFile,
          modifier = Modifier
            .weight(1f)
            .height(46.dp)
            .testTag("pick_update_file_button"),
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.secondary,
            contentColor = MaterialTheme.colorScheme.onSecondary,
          ),
        ) {
          Text(
            text = strings.pickUpdateFileBtn,
            style = MaterialTheme.typography.labelMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        OutlinedButton(
          onClick = onPickGamesFolder,
          modifier = Modifier
            .weight(1f)
            .height(42.dp)
            .testTag("pick_games_folder_button"),
          shape = RoundedCornerShape(10.dp),
        ) {
          Text(
            text = strings.pickGameFolderBtn,
            style = MaterialTheme.typography.labelSmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }

        OutlinedButton(
          onClick = onPickUpdatesFolder,
          modifier = Modifier
            .weight(1f)
            .height(42.dp)
            .testTag("pick_updates_folder_button"),
          shape = RoundedCornerShape(10.dp),
        ) {
          Text(
            text = strings.pickUpdateFolderBtn,
            style = MaterialTheme.typography.labelSmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }

      OutlinedButton(
        onClick = onOpenCustomPatchDialog,
        modifier = Modifier
          .fillMaxWidth()
          .height(42.dp)
          .testTag("open_custom_patch_button"),
        shape = RoundedCornerShape(10.dp),
      ) {
        Icon(
          imageVector = Icons.Filled.Code,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(18.dp),
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = strings.customPatchSectionBtn,
          style = MaterialTheme.typography.labelSmall,
          fontWeight = FontWeight.SemiBold,
          color = MaterialTheme.colorScheme.primary,
        )
      }

      Surface(
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Column(
          modifier = Modifier.padding(10.dp),
          verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
          Text(
            text = strings.patchTroubleshootGuideTitle,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
          )
          Text(
            text = strings.patchTroubleshootGuideBody,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }

      if (selectedGameFileInfo != null || selectedUpdateFileInfo != null) {
        Surface(
          shape = RoundedCornerShape(10.dp),
          color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.12f),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
          ) {
            if (selectedGameFileInfo != null) {
              Text(
                text = "✓ ${selectedGameFileInfo.fileName} (${selectedGameFileInfo.detectedBaseTitleId ?: "---"})",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.SemiBold,
              )
            }
            if (selectedUpdateFileInfo != null) {
              Text(
                text = "✓ Update: ${selectedUpdateFileInfo.fileName} (v${selectedUpdateFileInfo.detectedVersion ?: "---"} • Build: ${selectedUpdateFileInfo.extractedBuildId?.take(16) ?: "Auto"})",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.secondary,
                fontWeight = FontWeight.SemiBold,
              )
            }
          }
        }
      }

      if (discoveredUpdateFiles.isNotEmpty()) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          discoveredUpdateFiles.take(4).forEach { upd ->
            val isSelectedUpd = selectedUpdateFileInfo?.fileName == upd.fileName
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = if (isSelectedUpd) {
                MaterialTheme.colorScheme.secondary.copy(alpha = 0.18f)
              } else {
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
              },
              modifier = Modifier
                .fillMaxWidth()
                .clickable { onSelectDiscoveredUpdate(upd) },
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(horizontal = 10.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Text(
                  text = "${upd.fileName} (v${upd.detectedVersion ?: "Update"})",
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurface,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                  modifier = Modifier.weight(1f),
                )
                if (isSelectedUpd) {
                  Icon(
                    imageVector = Icons.Filled.CheckCircle,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.size(16.dp),
                  )
                }
              }
            }
          }
        }
      }

      if (installedGames.isEmpty()) {
        Surface(
          shape = RoundedCornerShape(10.dp),
          color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Text(
            text = strings.noGamesFoundInFolderHint,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(12.dp),
          )
        }
      } else {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          installedGames.forEach { game ->
            val isSelected = selectedGame?.titleId == game.titleId
            InstalledGameCardItem(
              game = game,
              isArabic = isArabic,
              isSelected = isSelected,
              onSelect = { onSelectGame(game) },
            )
          }
        }

        if (installedGames.size > 1) {
          FilledTonalButton(
            onClick = onUnlockAll,
            modifier = Modifier
              .fillMaxWidth()
              .height(44.dp)
              .testTag("unlock_all_games_button"),
            shape = RoundedCornerShape(10.dp),
          ) {
            Icon(imageVector = Icons.Filled.Bolt, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = strings.unlockAllGamesBtn,
              style = MaterialTheme.typography.labelMedium,
              fontWeight = FontWeight.SemiBold,
            )
          }
        }
      }
    }
  }
}

@Composable
private fun InstalledGameCardItem(
  game: InstalledGameItem,
  isArabic: Boolean,
  isSelected: Boolean,
  onSelect: () -> Unit,
) {
  val statusColor = when (game.diagnosisStatus) {
    GamePatchDiagnosisStatus.MATCHED -> MaterialTheme.colorScheme.secondary
    GamePatchDiagnosisStatus.WRITTEN_NOT_VERIFIED -> MaterialTheme.colorScheme.tertiary
    GamePatchDiagnosisStatus.VERSION_MISMATCH,
    GamePatchDiagnosisStatus.NO_PATCH_AVAILABLE -> MaterialTheme.colorScheme.error
  }

  Surface(
    shape = RoundedCornerShape(12.dp),
    color = if (isSelected) {
      MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
    } else {
      MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
    },
    border = BorderStroke(
      width = if (isSelected) 1.5.dp else 0.5.dp,
      color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
    ),
    modifier = Modifier
      .fillMaxWidth()
      .clickable(onClick = onSelect),
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp),
      verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f),
        ) {
          Icon(
            imageVector = if (game.diagnosisStatus == GamePatchDiagnosisStatus.MATCHED) {
              Icons.Filled.Verified
            } else {
              Icons.Filled.SportsEsports
            },
            contentDescription = null,
            tint = statusColor,
            modifier = Modifier.size(20.dp),
          )
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(
              text = if (isArabic) game.nameAr else game.nameEn,
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.SemiBold,
              color = MaterialTheme.colorScheme.onSurface,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
            Text(
              text = "Title ID: ${game.titleId} • v${game.detectedVersion}",
              fontFamily = JetBrainsMonoFontFamily,
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }

        Surface(
          shape = RoundedCornerShape(8.dp),
          color = statusColor.copy(alpha = 0.15f),
        ) {
          Text(
            text = game.diagnosisStatus.statusEn,
            style = MaterialTheme.typography.labelSmall,
            color = statusColor,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
          )
        }
      }

      Text(
        text = "Build ID: ${game.detectedBuildId.take(16)} • 60FPS Patch Exists: ${if (game.hasExactPatchForBuildId) "Yes" else "No"}",
        fontFamily = JetBrainsMonoFontFamily,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
    }
  }
}

@Composable
private fun Step3SelectedGameAndPerformanceTuningCard(
  strings: AppStrings,
  isArabic: Boolean,
  gameNameInput: String,
  gameVersionInput: String,
  resolvedPreview: DecodedGameRelease,
  selectedProfile: SmartTuningProfile,
  recommendedProfile: SmartTuningProfile,
  performanceNce: Boolean,
  force60Engine: Boolean,
  enableAmdFsr: Boolean,
  fsrSharpness: Int,
  forceMaxClock: Boolean,
  isRunning: Boolean,
  hasSaf: Boolean,
  logs: List<String>,
  onSelectProfile: (SmartTuningProfile) -> Unit,
  onOpenSmartProfileScreen: () -> Unit,
  onGameNameChange: (String) -> Unit,
  onGameVersionChange: (String) -> Unit,
  onTogglePerformanceNce: (Boolean) -> Unit,
  onToggleForce60: (Boolean) -> Unit,
  onToggleAmdFsr: (Boolean) -> Unit,
  onFsrSharpnessChange: (Int) -> Unit,
  onToggleMaxClock: (Boolean) -> Unit,
  onOpenDiffPreview: () -> Unit,
  onInject: () -> Unit,
  onRestoreOriginalConfig: () -> Unit,
) {
  var showAdvancedAndLogs by rememberSaveable { mutableStateOf(false) }

  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f),
        ) {
          Icon(
            imageVector = Icons.Filled.Speed,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.secondary,
            modifier = Modifier.size(20.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = strings.step3PerformanceTitle,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
          )
        }

        Text(
          text = "${strings.preselectedBadgeText}: ${if (isArabic) recommendedProfile.labelAr else recommendedProfile.labelEn}",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.secondary,
          fontWeight = FontWeight.SemiBold,
        )
      }

      // Clean 4-Profile Selector Row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        SmartTuningProfile.values().forEach { prof ->
          val isSelected = prof == selectedProfile
          val profLabel = if (isArabic) prof.labelAr else prof.labelEn
          FilledTonalButton(
            onClick = { onSelectProfile(prof) },
            modifier = Modifier
              .weight(1f)
              .height(44.dp)
              .testTag("profile_button_${prof.name.lowercase()}"),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.filledTonalButtonColors(
              containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
              contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
            ),
            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp),
          ) {
            Text(
              text = profLabel,
              style = MaterialTheme.typography.labelSmall,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }
        }
      }

      // Live Per-Game Diagnosis Summary for Currently Selected Game
      val diagColor = when (resolvedPreview.diagnosisStatus) {
        GamePatchDiagnosisStatus.MATCHED -> MaterialTheme.colorScheme.secondary
        GamePatchDiagnosisStatus.WRITTEN_NOT_VERIFIED -> MaterialTheme.colorScheme.tertiary
        GamePatchDiagnosisStatus.VERSION_MISMATCH,
        GamePatchDiagnosisStatus.NO_PATCH_AVAILABLE -> MaterialTheme.colorScheme.error
      }
      Surface(
        shape = RoundedCornerShape(10.dp),
        color = diagColor.copy(alpha = 0.11f),
        border = BorderStroke(1.dp, diagColor.copy(alpha = 0.4f)),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("selected_game_diagnosis_box"),
      ) {
        Column(
          modifier = Modifier.padding(10.dp),
          verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(
              text = "${if (isArabic) resolvedPreview.titleNameAr else resolvedPreview.titleNameEn} (${resolvedPreview.primaryTitleId})",
              style = MaterialTheme.typography.labelMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface,
              modifier = Modifier.weight(1f),
            )
            Surface(
              shape = RoundedCornerShape(6.dp),
              color = diagColor.copy(alpha = 0.18f),
            ) {
              Text(
                text = resolvedPreview.diagnosisStatus.statusEn,
                style = MaterialTheme.typography.labelSmall,
                color = diagColor,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
              )
            }
          }
          Text(
            text = "Version: v${resolvedPreview.requestedVersion} • Build ID: ${resolvedPreview.detectedBuildId.take(16)} • Exact 60FPS Patch: ${if (resolvedPreview.hasExactBuildIdPatchMatch) "Yes" else "No"}",
            fontFamily = JetBrainsMonoFontFamily,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
          Text(
            text = if (isArabic) resolvedPreview.diagnosisReasonAr else resolvedPreview.diagnosisReasonEn,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface,
          )
        }
      }

      // Concise Profile Summary Box
      Surface(
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Column(modifier = Modifier.padding(10.dp)) {
          Text(
            text = if (isArabic) selectedProfile.descriptionAr else selectedProfile.descriptionEn,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface,
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = strings.fps60WarningNote,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.tertiary,
            modifier = Modifier.testTag("fps60_warning_note_text"),
          )
        }
      }

      // Primary Action Button: Unlock 60 FPS & Apply Profile
      Button(
        onClick = onInject,
        enabled = !isRunning,
        modifier = Modifier
          .fillMaxWidth()
          .height(52.dp)
          .testTag("inject_mods_button"),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(
          containerColor = MaterialTheme.colorScheme.secondary,
          contentColor = MaterialTheme.colorScheme.onSecondary,
        ),
      ) {
        if (isRunning) {
          CircularProgressIndicator(
            modifier = Modifier.size(20.dp),
            strokeWidth = 2.5.dp,
            color = MaterialTheme.colorScheme.onSecondary,
          )
          Spacer(modifier = Modifier.width(10.dp))
        } else {
          Icon(
            imageVector = Icons.Filled.CloudDownload,
            contentDescription = null,
          )
          Spacer(modifier = Modifier.width(8.dp))
        }
        Text(
          text = strings.injectNowBtn,
          style = MaterialTheme.typography.labelLarge,
          fontWeight = FontWeight.Bold,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }

      // Secondary Clean Row: Preview Changes | Restore Original Config
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        OutlinedButton(
          onClick = onOpenDiffPreview,
          modifier = Modifier
            .weight(1f)
            .height(44.dp)
            .testTag("preview_config_diff_button"),
          shape = RoundedCornerShape(10.dp),
        ) {
          Icon(
            imageVector = Icons.Filled.Code,
            contentDescription = null,
            modifier = Modifier.size(16.dp),
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = strings.previewChangesBtn,
            style = MaterialTheme.typography.labelMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }

        if (hasSaf) {
          OutlinedButton(
            onClick = onRestoreOriginalConfig,
            enabled = !isRunning,
            modifier = Modifier
              .weight(1f)
              .height(44.dp)
              .testTag("restore_default_30fps_button"),
            shape = RoundedCornerShape(10.dp),
          ) {
            Icon(
              imageVector = Icons.Filled.Restore,
              contentDescription = null,
              modifier = Modifier.size(16.dp),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = strings.restoreOriginalConfigBtn,
              style = MaterialTheme.typography.labelMedium,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }
        }
      }

      // Collapsible Advanced Tuning & System Log
      TextButton(
        onClick = { showAdvancedAndLogs = !showAdvancedAndLogs },
        modifier = Modifier.fillMaxWidth(),
      ) {
        Text(
          text = strings.advancedSettingsToggleLabel,
          style = MaterialTheme.typography.labelMedium,
          color = MaterialTheme.colorScheme.primary,
        )
        Spacer(modifier = Modifier.width(4.dp))
        Icon(
          imageVector = if (showAdvancedAndLogs) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(18.dp),
        )
      }

      AnimatedVisibility(visible = showAdvancedAndLogs) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            OutlinedTextField(
              value = gameNameInput,
              onValueChange = onGameNameChange,
              modifier = Modifier
                .weight(1.2f)
                .testTag("game_name_or_id_input"),
              label = { Text(strings.gameNameInputLabel) },
              singleLine = true,
              shape = RoundedCornerShape(10.dp),
            )

            OutlinedTextField(
              value = gameVersionInput,
              onValueChange = onGameVersionChange,
              modifier = Modifier
                .weight(0.8f)
                .testTag("game_version_input"),
              label = { Text(strings.gameVersionInputLabel) },
              singleLine = true,
              shape = RoundedCornerShape(10.dp),
            )
          }

          // Toggle 1: NCE Execution
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = strings.performanceNceTitle,
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface,
              )
              Text(
                text = strings.performanceNceDesc,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
            Switch(
              checked = performanceNce,
              onCheckedChange = onTogglePerformanceNce,
              modifier = Modifier.testTag("switch_performance_nce"),
            )
          }

          // Toggle 2: Force 60.0 FPS Engine
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = strings.force60EngineTitle,
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface,
              )
              Text(
                text = strings.force60EngineDesc,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
            Switch(
              checked = force60Engine,
              onCheckedChange = onToggleForce60,
              modifier = Modifier.testTag("switch_force_60fps_engine"),
            )
          }

          // Toggle 3: AMD FSR
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = strings.amdFsrTitle,
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface,
              )
              Text(
                text = strings.amdFsrDesc,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
            Switch(
              checked = enableAmdFsr,
              onCheckedChange = onToggleAmdFsr,
              modifier = Modifier.testTag("switch_amd_fsr"),
            )
          }

          if (enableAmdFsr) {
            Column {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
              ) {
                Text(
                  text = strings.fsrSharpnessLabel,
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                  text = "$fsrSharpness%",
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.primary,
                )
              }
              Slider(
                value = fsrSharpness.toFloat(),
                onValueChange = { onFsrSharpnessChange(it.toInt()) },
                valueRange = 25f..100f,
                modifier = Modifier.testTag("slider_fsr_sharpness"),
              )
            }
          }

          // Toggle 4: Async Shaders
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = strings.vulkanMaxClockTitle,
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface,
              )
              Text(
                text = strings.vulkanMaxClockDesc,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
            Switch(
              checked = forceMaxClock,
              onCheckedChange = onToggleMaxClock,
              modifier = Modifier.testTag("switch_max_clock"),
            )
          }

          TelemetryConsoleCard(
            headerTitle = strings.logsHeader,
            logs = logs,
          )
        }
      }
    }
  }
}

@Composable
private fun SmartProfileDedicatedScreen(
  strings: AppStrings,
  isArabic: Boolean,
  hardwareInfo: DeviceHardwareInfo,
  thermalStatus: DeviceThermalStatus,
  autoAdaptThermal: Boolean,
  selectedProfile: SmartTuningProfile,
  selectedEmulator: EmulatorProfile,
  diffItems: List<ConfigDiffItem>,
  isRunning: Boolean,
  hasSaf: Boolean,
  localNpuEnabled: Boolean,
  localNpuStatus: LocalNpuUpscalerStatus,
  isBackgroundGovernorActive: Boolean,
  aiState: AiOptimizationUiState,
  latestFrameMetrics: DirectFrameAndHardwareMetrics?,
  networkState: NetworkConnectionState,
  directTelemetry: DirectPhoneTelemetry,
  isCloudSyncing: Boolean,
  onBack: () -> Unit,
  onSelectProfile: (SmartTuningProfile) -> Unit,
  onToggleAutoAdaptThermal: (Boolean) -> Unit,
  onToggleLocalNpuUpscaling: (Boolean) -> Unit,
  onToggleBackgroundGovernor: (Boolean) -> Unit,
  onApplyProfileAndInject: () -> Unit,
  onRestoreOriginalConfig: () -> Unit,
  onRunAiOptimization: () -> Unit,
  onApplyAiPlan: (AiOptimizationPlan) -> Unit,
  onSyncViaNetwork: () -> Unit,
) {
  BackHandler(onBack = onBack)

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .testTag("smart_profile_screen"),
    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    // AI Optimization System Card at the top of Smart Profile screen
    item {
      AiOptimizationSystemCard(
        isArabic = isArabic,
        localNpuEnabled = localNpuEnabled,
        localNpuStatus = localNpuStatus,
        isBackgroundGovernorActive = isBackgroundGovernorActive,
        aiState = aiState,
        latestMetrics = latestFrameMetrics,
        networkState = networkState,
        directTelemetry = directTelemetry,
        isRunning = isRunning,
        isCloudSyncing = isCloudSyncing,
        onToggleLocalNpuUpscaling = onToggleLocalNpuUpscaling,
        onToggleBackgroundGovernor = onToggleBackgroundGovernor,
        onRunAiOptimization = onRunAiOptimization,
        onApplyAiPlan = onApplyAiPlan,
        onSyncNetwork = onSyncViaNetwork,
      )
    }

    // Device Class & Thermal Gauge Summary Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
      ) {
        Column(
          modifier = Modifier.padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.weight(1f),
            ) {
              Icon(
                imageVector = Icons.Filled.Memory,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.size(20.dp),
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = strings.deviceClassSectionTitle,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
              )
            }

            OutlinedButton(
              onClick = onBack,
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier
                .height(38.dp)
                .testTag("smart_profile_back_button"),
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = strings.backToMainScreenBtn,
                modifier = Modifier.size(16.dp),
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(strings.backToMainScreenBtn, style = MaterialTheme.typography.labelSmall)
            }
          }

          Surface(
            shape = RoundedCornerShape(10.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Column(
              modifier = Modifier.padding(12.dp),
              verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
              Text(
                text = "${hardwareInfo.socBrand} (${hardwareInfo.chipName})",
                fontFamily = JetBrainsMonoFontFamily,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
              )
              Text(
                text = if (isArabic) {
                  "${hardwareInfo.deviceClassAr} • النمط المختار لجهازك: ${hardwareInfo.recommendedProfile.labelAr}"
                } else {
                  "${hardwareInfo.deviceClassEn} • Preselected: ${hardwareInfo.recommendedProfile.labelEn}"
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface,
              )
            }
          }

          // Live Thermal Status
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Filled.Thermostat,
                contentDescription = null,
                tint = if (thermalStatus.isSevere) MaterialTheme.colorScheme.error
                else if (thermalStatus.isHot) MaterialTheme.colorScheme.tertiary
                else MaterialTheme.colorScheme.secondary,
                modifier = Modifier.size(18.dp),
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "${strings.thermalStatusLabel} ${if (isArabic) thermalStatus.statusNameAr else thermalStatus.statusNameEn}",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = if (thermalStatus.isSevere) MaterialTheme.colorScheme.error
                else if (thermalStatus.isHot) MaterialTheme.colorScheme.tertiary
                else MaterialTheme.colorScheme.secondary,
              )
            }

            if (thermalStatus.thermalHeadroom != null) {
              Text(
                text = "${strings.thermalHeadroomLabel} ${String.format(java.util.Locale.US, "%.2f", thermalStatus.thermalHeadroom)}",
                fontFamily = JetBrainsMonoFontFamily,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }

          if (thermalStatus.isHot && (selectedProfile == SmartTuningProfile.PERFORMANCE || selectedProfile == SmartTuningProfile.QUALITY)) {
            val lighterProfile = if (thermalStatus.isSevere) SmartTuningProfile.BATTERY_SAVER else SmartTuningProfile.BALANCED
            Button(
              onClick = { onSelectProfile(lighterProfile) },
              modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
                .testTag("apply_recommended_lighter_profile_button"),
              shape = RoundedCornerShape(10.dp),
              colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.tertiary,
                contentColor = MaterialTheme.colorScheme.onTertiary,
              ),
            ) {
              Icon(imageVector = Icons.Filled.Thermostat, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "${strings.switchRecommendedLighterBtn} (${if (isArabic) lighterProfile.labelAr else lighterProfile.labelEn})",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.labelMedium,
              )
            }
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(
              text = strings.autoAdaptThermalLabel,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurface,
              modifier = Modifier.weight(1f),
            )
            Switch(
              checked = autoAdaptThermal,
              onCheckedChange = onToggleAutoAdaptThermal,
              modifier = Modifier.testTag("smart_profile_auto_adapt_switch"),
            )
          }
        }
      }
    }

    // 4 Clean Smart Profile Cards
    items(SmartTuningProfile.values().toList(), key = { it.name }) { profile ->
      val isSelected = profile == selectedProfile
      val isPreselectedForDevice = profile == hardwareInfo.recommendedProfile
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .border(
            width = if (isSelected) 1.5.dp else 0.5.dp,
            color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
            shape = RoundedCornerShape(14.dp),
          )
          .clickable { onSelectProfile(profile) }
          .testTag("smart_profile_card_${profile.name.lowercase()}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
          containerColor = if (isSelected) {
            MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
          } else {
            MaterialTheme.colorScheme.surface
          }
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
      ) {
        Column(
          modifier = Modifier.padding(14.dp),
          verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = if (isSelected) Icons.Filled.CheckCircle else Icons.Filled.Tune,
                contentDescription = null,
                tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp),
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = if (isArabic) "${profile.labelAr} (${profile.labelEn})" else profile.labelEn,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
              )
            }

            if (isPreselectedForDevice) {
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.16f),
              ) {
                Text(
                  text = strings.preselectedBadgeText,
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.secondary,
                  fontWeight = FontWeight.Bold,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                )
              }
            }
          }

          Text(
            text = if (isArabic) profile.descriptionAr else profile.descriptionEn,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )

          CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Text(
              text = "NCE (cpu_backend=1) • Scale: ${profile.resolutionLabel} • FSR=${profile.fsrSharpnessValue}% • ${profile.targetFpsLabel}",
              fontFamily = JetBrainsMonoFontFamily,
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.primary,
            )
          }

          if (profile.speedLimitValue >= 200) {
            Text(
              text = strings.fps60WarningNote,
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.tertiary,
            )
          }
        }
      }
    }

    // Inline Preview of Every Change Before Applying It
    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("smart_profile_diff_preview_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
      ) {
        Column(
          modifier = Modifier.padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Filled.Code,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = strings.liveDiffSectionTitle,
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface,
            )
          }

          if (diffItems.isEmpty()) {
            Text(
              text = strings.diffEmptyMessage,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          } else {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
              Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                diffItems.forEach { item ->
                  Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                    modifier = Modifier.fillMaxWidth(),
                  ) {
                    Row(
                      modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                      horizontalArrangement = Arrangement.SpaceBetween,
                      verticalAlignment = Alignment.CenterVertically,
                    ) {
                      Text(
                        text = "${item.section} ${item.key}",
                        fontFamily = JetBrainsMonoFontFamily,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.weight(1.2f),
                      )
                      Text(
                        text = "${item.oldValue ?: "(default)"} -> ${item.newValue}",
                        fontFamily = JetBrainsMonoFontFamily,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary,
                        fontWeight = FontWeight.Bold,
                      )
                    }
                  }
                }
              }
            }
          }

          Button(
            onClick = onApplyProfileAndInject,
            enabled = !isRunning,
            modifier = Modifier
              .fillMaxWidth()
              .height(50.dp)
              .testTag("smart_profile_apply_button"),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(
              containerColor = MaterialTheme.colorScheme.secondary,
              contentColor = MaterialTheme.colorScheme.onSecondary,
            ),
          ) {
            Icon(imageVector = Icons.Filled.CloudDownload, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = strings.injectNowBtn,
              style = MaterialTheme.typography.labelLarge,
              fontWeight = FontWeight.Bold,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }

          if (hasSaf) {
            OutlinedButton(
              onClick = onRestoreOriginalConfig,
              enabled = !isRunning,
              modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
                .testTag("smart_profile_restore_button"),
              shape = RoundedCornerShape(10.dp),
            ) {
              Icon(imageVector = Icons.Filled.Restore, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(strings.restoreOriginalConfigBtn)
            }
          }
        }
      }
    }
  }
}

@Composable
private fun PerGameDiagnosisScreen(
  strings: AppStrings,
  isArabic: Boolean,
  installedGames: List<InstalledGameItem>,
  resolvedPreview: DecodedGameRelease,
  selectedGame: InstalledGameItem?,
  onBack: () -> Unit,
  onSelectGame: (InstalledGameItem) -> Unit,
  onPickGameFile: () -> Unit,
  onPickUpdateFile: () -> Unit,
  onOpenCustomPatchDialog: (InstalledGameItem) -> Unit,
) {
  BackHandler(onBack = onBack)

  // Combine discovered games with the currently previewed game if not already listed
  val diagnosisGames = remember(installedGames, resolvedPreview) {
    if (installedGames.any { it.titleId.equals(resolvedPreview.primaryTitleId, ignoreCase = true) }) {
      installedGames
    } else {
      listOf(
        InstalledGameItem(
          titleId = resolvedPreview.primaryTitleId,
          nameEn = resolvedPreview.titleNameEn,
          nameAr = resolvedPreview.titleNameAr,
          detectedVersion = resolvedPreview.requestedVersion,
          detectedBuildId = resolvedPreview.detectedBuildId,
          hasExactPatchForBuildId = resolvedPreview.hasExactBuildIdPatchMatch,
          diagnosisStatus = resolvedPreview.diagnosisStatus,
          diagnosisReasonEn = resolvedPreview.diagnosisReasonEn,
          diagnosisReasonAr = resolvedPreview.diagnosisReasonAr,
          has60FpsPatch = false,
          hasPerformanceConfig = false,
          folderSource = "Current Selection",
        )
      ) + installedGames
    }
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .testTag("per_game_diagnosis_screen"),
    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
      ) {
        Column(
          modifier = Modifier.padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.weight(1f),
            ) {
              Icon(
                imageVector = Icons.Filled.Verified,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp),
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = strings.diagnosisScreenTitle,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
              )
            }

            OutlinedButton(
              onClick = onBack,
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier
                .height(38.dp)
                .testTag("diagnosis_back_button"),
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = strings.backToMainScreenBtn,
                modifier = Modifier.size(16.dp),
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(strings.backToMainScreenBtn, style = MaterialTheme.typography.labelSmall)
            }
          }

          Text(
            text = strings.diagnosisScreenSub,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            OutlinedButton(
              onClick = onPickGameFile,
              modifier = Modifier
                .weight(1f)
                .height(42.dp),
              shape = RoundedCornerShape(10.dp),
            ) {
              Text(strings.pickGameFileBtn, style = MaterialTheme.typography.labelSmall)
            }
            OutlinedButton(
              onClick = onPickUpdateFile,
              modifier = Modifier
                .weight(1f)
                .height(42.dp),
              shape = RoundedCornerShape(10.dp),
            ) {
              Text(strings.pickUpdateFileBtn, style = MaterialTheme.typography.labelSmall)
            }
          }
        }
      }
    }

    items(diagnosisGames, key = { it.titleId }) { game ->
      val statusColor = when (game.diagnosisStatus) {
        GamePatchDiagnosisStatus.MATCHED -> MaterialTheme.colorScheme.secondary
        GamePatchDiagnosisStatus.WRITTEN_NOT_VERIFIED -> MaterialTheme.colorScheme.tertiary
        GamePatchDiagnosisStatus.VERSION_MISMATCH,
        GamePatchDiagnosisStatus.NO_PATCH_AVAILABLE -> MaterialTheme.colorScheme.error
      }
      val isSelected = selectedGame?.titleId == game.titleId

      Card(
        modifier = Modifier
          .fillMaxWidth()
          .border(
            width = if (isSelected) 1.5.dp else 1.dp,
            color = if (isSelected) MaterialTheme.colorScheme.primary else statusColor.copy(alpha = 0.45f),
            shape = RoundedCornerShape(14.dp),
          )
          .clickable { onSelectGame(game) }
          .testTag("diagnosis_game_card_${game.titleId}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
      ) {
        Column(
          modifier = Modifier.padding(14.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = if (isArabic) game.nameAr else game.nameEn,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
              )
              Text(
                text = "Source: ${game.folderSource}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }

            Surface(
              shape = RoundedCornerShape(8.dp),
              color = statusColor.copy(alpha = 0.16f),
            ) {
              Text(
                text = game.diagnosisStatus.statusEn,
                style = MaterialTheme.typography.labelSmall,
                color = statusColor,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
              )
            }
          }

          Surface(
            shape = RoundedCornerShape(10.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
            modifier = Modifier.fillMaxWidth(),
          ) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
              Column(
                modifier = Modifier.padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
              ) {
                Text(
                  text = "Title ID:          ${game.titleId}",
                  fontFamily = JetBrainsMonoFontFamily,
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurface,
                )
                Text(
                  text = "Detected Version:  v${game.detectedVersion}",
                  fontFamily = JetBrainsMonoFontFamily,
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurface,
                )
                Text(
                  text = "NSO Build ID:      ${game.detectedBuildId}",
                  fontFamily = JetBrainsMonoFontFamily,
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.primary,
                )
                Text(
                  text = "60 FPS Patch Exists for Exact Build ID: ${if (game.hasExactPatchForBuildId) "Yes" else "No"}",
                  fontFamily = JetBrainsMonoFontFamily,
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Bold,
                  color = statusColor,
                )
                Text(
                  text = "Diagnosis Status:  ${game.diagnosisStatus.statusEn}",
                  fontFamily = JetBrainsMonoFontFamily,
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Bold,
                  color = statusColor,
                )
              }
            }
          }

          Text(
            text = if (isArabic) game.diagnosisReasonAr else game.diagnosisReasonEn,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface,
          )

          if (game.diagnosisStatus != GamePatchDiagnosisStatus.MATCHED) {
            OutlinedButton(
              onClick = { onOpenCustomPatchDialog(game) },
              modifier = Modifier
                .fillMaxWidth()
                .height(38.dp),
              shape = RoundedCornerShape(8.dp),
            ) {
              Icon(
                imageVector = Icons.Filled.Code,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(16.dp),
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = strings.customPatchSectionBtn,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary,
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun Step4VerificationReportCard(
  strings: AppStrings,
  isArabic: Boolean,
  result: RealInjectionResult,
  onLaunchEmulator: () -> Unit,
) {
  var showPchtxt by rememberSaveable { mutableStateOf(false) }
  var showConfigIni by rememberSaveable { mutableStateOf(false) }

  val cardColor = if (result.applied) {
    MaterialTheme.colorScheme.secondary
  } else {
    MaterialTheme.colorScheme.error
  }

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .animateContentSize()
      .border(
        width = 1.dp,
        color = cardColor.copy(alpha = 0.6f),
        shape = RoundedCornerShape(16.dp),
      )
      .testTag("verification_report_card"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(
      containerColor = cardColor.copy(alpha = 0.12f)
    ),
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f),
        ) {
          Icon(
            imageVector = if (result.applied) Icons.Filled.Verified else Icons.Filled.Close,
            contentDescription = null,
            tint = cardColor,
            modifier = Modifier.size(22.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = if (result.applied) {
              strings.step4ResultTitle
            } else {
              if (isArabic) "لم يتم تطبيق أي تعديل (${result.diagnosisStatus.statusEn})"
              else "Nothing Applied (${result.diagnosisStatus.statusEn})"
            },
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Bold,
          )
        }

        Surface(
          shape = RoundedCornerShape(8.dp),
          color = cardColor.copy(alpha = 0.18f),
        ) {
          Text(
            text = result.diagnosisStatus.statusEn,
            style = MaterialTheme.typography.labelSmall,
            color = cardColor,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
          )
        }
      }

      Text(
        text = if (isArabic) result.plainOutcomeMessageAr else result.plainOutcomeMessageEn,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurface,
        modifier = Modifier.testTag("outcome_plain_message_text"),
      )

      if (result.applied) {
        // Required Post-Apply Checklist Box
        Surface(
          shape = RoundedCornerShape(10.dp),
          color = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("eden_post_apply_checklist"),
        ) {
          Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            Text(
              text = "In Eden open the game's Properties and Add-ons, make sure 60FPS_Mod is ticked, then start the game. If the game still runs at 30 FPS, the patch does not match your game version.",
              style = MaterialTheme.typography.bodySmall,
              fontWeight = FontWeight.SemiBold,
              color = MaterialTheme.colorScheme.onSurface,
            )
            if (isArabic) {
              Text(
                text = "في محاكي Eden افتح خصائص اللعبة (Properties) ثم الإضافات (Add-ons)، وتأكد من تفعيل علامة صح على 60FPS_Mod ثم شغّل اللعبة. إذا استمرت اللعبة على 30 FPS فهذا يعني أن الباتش لا يطابق إصدار لعبتك.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
        }

        Button(
          onClick = onLaunchEmulator,
          modifier = Modifier
            .fillMaxWidth()
            .height(46.dp)
            .testTag("open_eden_button"),
          shape = RoundedCornerShape(10.dp),
        ) {
          Icon(imageVector = Icons.Filled.PlayArrow, contentDescription = null)
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = if (isArabic) "Open Eden (فتح محاكي Eden)" else "Open Eden",
            fontWeight = FontWeight.Bold,
          )
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          OutlinedButton(
            onClick = { showPchtxt = !showPchtxt },
            modifier = Modifier
              .weight(1f)
              .height(40.dp),
            shape = RoundedCornerShape(10.dp),
          ) {
            Text(strings.inspectPchtxtBtn, style = MaterialTheme.typography.labelSmall)
          }

          OutlinedButton(
            onClick = { showConfigIni = !showConfigIni },
            modifier = Modifier
              .weight(1f)
              .height(40.dp),
            shape = RoundedCornerShape(10.dp),
          ) {
            Text(strings.inspectConfigIniBtn, style = MaterialTheme.typography.labelSmall)
          }
        }

        AnimatedVisibility(visible = showPchtxt) {
          CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = MaterialTheme.colorScheme.background,
              modifier = Modifier.fillMaxWidth(),
            ) {
              Text(
                text = result.pchtxtPreview,
                fontFamily = JetBrainsMonoFontFamily,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(10.dp),
              )
            }
          }
        }

        AnimatedVisibility(visible = showConfigIni) {
          CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = MaterialTheme.colorScheme.background,
              modifier = Modifier.fillMaxWidth(),
            ) {
              Text(
                text = result.configIniPreview,
                fontFamily = JetBrainsMonoFontFamily,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.padding(10.dp),
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun TelemetryConsoleCard(
  headerTitle: String,
  logs: List<String>,
) {
  Surface(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("telemetry_console_card"),
    shape = RoundedCornerShape(12.dp),
    color = MaterialTheme.colorScheme.background,
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp),
      verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Filled.Terminal,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(16.dp),
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = headerTitle,
          style = MaterialTheme.typography.labelLarge,
          color = MaterialTheme.colorScheme.onSurface,
        )
      }

      CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
          logs.takeLast(12).forEach { line ->
            Text(
              text = "> $line",
              fontFamily = JetBrainsMonoFontFamily,
              style = MaterialTheme.typography.labelSmall,
              color = when {
                line.contains("SUCCESS") || line.contains("GitHub") || line.contains("Selected") || line.contains("Performance") ->
                  MaterialTheme.colorScheme.secondary
                line.contains("ERROR") ->
                  MaterialTheme.colorScheme.error
                else -> MaterialTheme.colorScheme.onSurfaceVariant
              },
            )
          }
        }
      }
    }
  }
}

@Composable
private fun ConfigDiffPreviewDialog(
  strings: AppStrings,
  diffItems: List<ConfigDiffItem>,
  onDismiss: () -> Unit,
) {
  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false),
  ) {
    Surface(
      modifier = Modifier
        .fillMaxWidth(0.92f)
        .heightIn(min = 280.dp, max = 580.dp),
      shape = RoundedCornerShape(20.dp),
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 4.dp,
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Filled.Code,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary,
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = strings.diffPreviewTitle,
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface,
            )
          }
          IconButton(onClick = onDismiss) {
            Icon(
              imageVector = Icons.Filled.Close,
              contentDescription = "Close",
            )
          }
        }

        if (diffItems.isEmpty()) {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .weight(1f),
            contentAlignment = Alignment.Center,
          ) {
            Text(
              text = strings.diffEmptyMessage,
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        } else {
          CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            LazyColumn(
              modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
              verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
              items(diffItems) { item ->
                Surface(
                  shape = RoundedCornerShape(10.dp),
                  color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                  modifier = Modifier.fillMaxWidth(),
                ) {
                  Column(
                    modifier = Modifier.padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                  ) {
                    Row(
                      modifier = Modifier.fillMaxWidth(),
                      horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                      Text(
                        text = item.key,
                        fontFamily = JetBrainsMonoFontFamily,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                      )
                      Text(
                        text = item.section,
                        fontFamily = JetBrainsMonoFontFamily,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                      )
                    }

                    Row(
                      modifier = Modifier.fillMaxWidth(),
                      horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                      Text(
                        text = "- ${item.oldValue ?: "(unset)"}",
                        fontFamily = JetBrainsMonoFontFamily,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.weight(1f),
                      )
                      Text(
                        text = "+ ${item.newValue}",
                        fontFamily = JetBrainsMonoFontFamily,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f),
                      )
                    }
                  }
                }
              }
            }
          }
        }

        Button(
          onClick = onDismiss,
          modifier = Modifier
            .fillMaxWidth()
            .height(46.dp),
          shape = RoundedCornerShape(10.dp),
        ) {
          Text(strings.closePreviewBtn)
        }
      }
    }
  }
}

@Composable
private fun CustomPatchInputDialog(
  strings: AppStrings,
  isArabic: Boolean,
  targetGame: InstalledGameItem?,
  code: String,
  buildId: String,
  onCodeChange: (String) -> Unit,
  onBuildIdChange: (String) -> Unit,
  onApply: (String, String?) -> Unit,
  onDismiss: () -> Unit,
) {
  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false),
  ) {
    Card(
      modifier = Modifier
        .fillMaxWidth(0.92f)
        .widthIn(max = 560.dp)
        .testTag("custom_patch_input_dialog"),
      shape = RoundedCornerShape(18.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f),
          ) {
            Icon(
              imageVector = Icons.Filled.Code,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(22.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = strings.customPatchDialogTitle,
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface,
            )
          }
          IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
            Icon(
              imageVector = Icons.Filled.Close,
              contentDescription = strings.cancelBtn,
              tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }

        Text(
          text = strings.customPatchDialogSub,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        if (targetGame != null) {
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Text(
              text = "Target: ${if (isArabic) targetGame.nameAr else targetGame.nameEn} (${targetGame.titleId})",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.SemiBold,
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            )
          }
        }

        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Text(
            text = strings.customPatchCodeLabel,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface,
          )
          OutlinedTextField(
            value = code,
            onValueChange = onCodeChange,
            modifier = Modifier
              .fillMaxWidth()
              .heightIn(min = 120.dp, max = 200.dp)
              .testTag("custom_patch_code_input"),
            placeholder = {
              Text(
                text = "@nsobid-9B4E43650501A4D4...\n@enabled\n008A6C94 20008052\n008A6C98 C0035FD6\n@stop",
                fontFamily = JetBrainsMonoFontFamily,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
              )
            },
            textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMonoFontFamily),
            shape = RoundedCornerShape(10.dp),
          )
        }

        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Text(
            text = strings.customPatchBuildIdLabel,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface,
          )
          OutlinedTextField(
            value = buildId,
            onValueChange = onBuildIdChange,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("custom_patch_build_id_input"),
            placeholder = {
              Text(
                text = "e.g. 9B4E43650501A4D4489B4B2E1A3F6E9C",
                fontFamily = JetBrainsMonoFontFamily,
                style = MaterialTheme.typography.labelSmall,
              )
            },
            singleLine = true,
            textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMonoFontFamily),
            shape = RoundedCornerShape(10.dp),
          )
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          OutlinedButton(
            onClick = onDismiss,
            modifier = Modifier
              .weight(1f)
              .height(44.dp),
            shape = RoundedCornerShape(10.dp),
          ) {
            Text(strings.cancelBtn)
          }

          Button(
            onClick = { onApply(code, buildId.ifBlank { null }) },
            enabled = code.isNotBlank(),
            modifier = Modifier
              .weight(1.5f)
              .height(44.dp)
              .testTag("custom_patch_confirm_button"),
            shape = RoundedCornerShape(10.dp),
          ) {
            Text(
              text = strings.customPatchApplyBtn,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }
        }
      }
    }
  }
}

@Composable
fun PermissionsOnboardingDialog(
  isArabic: Boolean,
  onboardingState: PermissionsOnboardingState,
  onRequestNotification: () -> Unit,
  onRequestBatteryOptimization: () -> Unit,
  onRequestUsageStats: () -> Unit = {},
  onRequestSaf: () -> Unit,
  onComplete: () -> Unit,
  onDismiss: () -> Unit,
) {
  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false),
  ) {
    Card(
      modifier = Modifier
        .fillMaxWidth(0.95f)
        .padding(16.dp),
      shape = RoundedCornerShape(20.dp),
      colors = CardDefaults.cardColors(
        containerColor = MaterialTheme.colorScheme.surface,
      ),
      elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
      ) {
        // Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            Box(
              modifier = Modifier
                .size(40.dp)
                .background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
              contentAlignment = Alignment.Center,
            ) {
              Icon(
                imageVector = Icons.Filled.Security,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(24.dp),
              )
            }
            Column {
              Text(
                text = if (isArabic) "إعداد أذونات نوفا بوست (NovaBoost)" else "NovaBoost Permissions Onboarding",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
              )
              Text(
                text = if (isArabic) "لكشف آخر تطبيق تم دخوله وحقن 60FPS بدون حرارة" else "Detects last played app & runs NPU 60FPS governor",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
          IconButton(
            onClick = onDismiss,
            modifier = Modifier.size(32.dp).testTag("close_onboarding_dialog_button"),
          ) {
            Icon(Icons.Filled.Close, contentDescription = "Close", modifier = Modifier.size(20.dp))
          }
        }

        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

        // Step 1: POST_NOTIFICATIONS
        PermissionStepCard(
          title = if (isArabic) "1. إشعار الحاكم المستمر (POST_NOTIFICATIONS)" else "1. Persistent Notification (Foreground Service)",
          description = if (isArabic)
            "لإبقاء حاكم الذكاء الاصطناعي يعمل في الخلفية أثناء اللعب بدون إغلاق."
          else
            "Required on Android 13+ to keep the NPU governor active in background.",
          icon = Icons.Filled.Notifications,
          isGranted = onboardingState.hasNotificationPermission,
          actionButtonText = if (isArabic) "منح الإذن" else "Grant Permission",
          testTag = "grant_notification_permission_button",
          onAction = onRequestNotification,
        )

        // Step 2: ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS
        PermissionStepCard(
          title = if (isArabic) "2. استثناء تحسين البطارية (Unrestricted Battery)" else "2. Disable Battery Optimization (Unrestricted)",
          description = if (isArabic)
            "يمنع النظام من إيقاف خدمة 60FPS أثناء جلسات اللعب الطويلة."
          else
            "Prevents Android OS Doze from killing the background AI governor.",
          icon = Icons.Filled.BatteryChargingFull,
          isGranted = onboardingState.hasBatteryOptimizationIgnored,
          actionButtonText = if (isArabic) "تعطيل التقييد" else "Allow Unrestricted",
          testTag = "grant_battery_optimization_button",
          onAction = onRequestBatteryOptimization,
        )

        // Step 3: PACKAGE_USAGE_STATS (Detect Last Played App)
        PermissionStepCard(
          title = if (isArabic) "3. كشف آخر تطبيق تم دخوله (Usage Access)" else "3. Detect Last Played App (PACKAGE_USAGE_STATS)",
          description = if (isArabic)
            "للتعرف تلقائياً على آخر تطبيق أو محاكي دخلت إليه وفتح مجلده مباشرة."
          else
            "Uses UsageStatsManager to detect your last opened emulator automatically.",
          icon = Icons.Filled.SportsEsports,
          isGranted = onboardingState.hasUsageStatsPermission,
          actionButtonText = if (isArabic) "تفعيل الكشف" else "Grant Usage Access",
          testTag = "grant_usage_stats_permission_button",
          onAction = onRequestUsageStats,
        )

        // Step 4: SAF Folder Access
        PermissionStepCard(
          title = if (isArabic) "4. اختيار مجلد التطبيق وملفاته (Direct SAF)" else "4. Select App Data Folder (Direct SAF)",
          description = if (isArabic)
            "يفتح مجلد التطبيق المكتشف داخل Android/data/ مباشرة لحقن 60FPS وإعدادات التبريد."
          else
            "Opens directly inside the detected app's folder in Android/data/ via EXTRA_INITIAL_URI.",
          icon = Icons.Filled.FolderOpen,
          isGranted = onboardingState.hasSafAccess,
          actionButtonText = if (isArabic) "اختر مجلد التطبيق" else "Select App Folder",
          testTag = "grant_saf_permission_button",
          onAction = onRequestSaf,
        )

        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

        // Actions
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          OutlinedButton(
            onClick = onDismiss,
            modifier = Modifier
              .weight(1f)
              .height(46.dp)
              .testTag("dismiss_onboarding_button"),
            shape = RoundedCornerShape(12.dp),
          ) {
            Text(if (isArabic) "لاحقاً" else "Later")
          }

          Button(
            onClick = onComplete,
            modifier = Modifier
              .weight(1.5f)
              .height(46.dp)
              .testTag("complete_onboarding_button"),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(
              containerColor = if (onboardingState.allGranted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary,
            ),
          ) {
            Text(
              text = if (onboardingState.allGranted) {
                if (isArabic) "ابدأ الآن 🚀" else "Start Now 🚀"
              } else {
                if (isArabic) "متابعة التطبيق" else "Continue"
              },
              fontWeight = FontWeight.Bold,
            )
          }
        }
      }
    }
  }
}

@Composable
private fun PermissionStepCard(
  title: String,
  description: String,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  isGranted: Boolean,
  actionButtonText: String,
  testTag: String,
  onAction: () -> Unit,
) {
  Surface(
    shape = RoundedCornerShape(14.dp),
    color = if (isGranted) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
      else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
    border = BorderStroke(
      width = 1.dp,
      color = if (isGranted) MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)
        else MaterialTheme.colorScheme.outlineVariant,
    ),
    modifier = Modifier.fillMaxWidth(),
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Box(
        modifier = Modifier
          .size(36.dp)
          .background(
            if (isGranted) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f),
            CircleShape,
          ),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = icon,
          contentDescription = null,
          tint = if (isGranted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
          modifier = Modifier.size(20.dp),
        )
      }

      Column(
        modifier = Modifier.weight(1f),
      ) {
        Text(
          text = title,
          style = MaterialTheme.typography.labelLarge,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface,
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = description,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }

      if (isGranted) {
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
          ) {
            Icon(
              imageVector = Icons.Filled.CheckCircle,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(14.dp),
            )
            Text(
              text = "✓",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.primary,
            )
          }
        }
      } else {
        FilledTonalButton(
          onClick = onAction,
          modifier = Modifier.testTag(testTag),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
          shape = RoundedCornerShape(8.dp),
        ) {
          Text(
            text = actionButtonText,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
          )
        }
      }
    }
  }
}
